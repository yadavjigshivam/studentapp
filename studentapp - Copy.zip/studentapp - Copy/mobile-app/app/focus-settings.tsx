import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Switch,
    ActivityIndicator,
    Alert,
    Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { api, getApiErrorMessage } from '../src/services/api';
import { Colors, Gradients, Shadows } from '../src/theme/colors';

const POPULAR_APPS: Array<{
    pkg: string;
    name: string;
    icon: keyof typeof Ionicons.glyphMap;
    color: string;
}> = [
        { pkg: 'com.whatsapp', name: 'WhatsApp', icon: 'logo-whatsapp', color: '#16A34A' },
        { pkg: 'com.instagram.android', name: 'Instagram', icon: 'logo-instagram', color: '#E1306C' },
        { pkg: 'com.google.android.youtube', name: 'YouTube', icon: 'logo-youtube', color: '#DC2626' },
        { pkg: 'com.facebook.katana', name: 'Facebook', icon: 'logo-facebook', color: '#2563EB' },
        { pkg: 'org.telegram.messenger', name: 'Telegram', icon: 'paper-plane', color: '#0284C7' },
        { pkg: 'com.snapchat.android', name: 'Snapchat', icon: 'logo-snapchat', color: '#CA8A04' },
    ];

const FOCUS_DURATIONS = [25, 45, 60, 90];
const BREAK_DURATIONS = [5, 10, 15];

export default function FocusSettingsScreen() {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [blockedApps, setBlockedApps] = useState<string[]>([]);
    const [focusDurationMinutes, setFocusDurationMinutes] = useState(25);
    const [breakDurationMinutes, setBreakDurationMinutes] = useState(5);
    const [enableDnd, setEnableDnd] = useState(true);
    const [enableAppOverlay, setEnableAppOverlay] = useState(true);
    const [emergencyExitEnabled, setEmergencyExitEnabled] = useState(true);

    useEffect(() => {
        const load = async () => {
            try {
                const res = await api.get('/focus-mode/settings');
                const cfg = res.data.data;
                if (cfg) {
                    setBlockedApps(Array.isArray(cfg.blockedApps) ? cfg.blockedApps : []);
                    setFocusDurationMinutes(cfg.focusDurationMinutes || 25);
                    setBreakDurationMinutes(cfg.breakDurationMinutes || 5);
                    setEnableDnd(cfg.enableDnd !== false);
                    setEnableAppOverlay(cfg.enableAppOverlay !== false);
                    setEmergencyExitEnabled(cfg.emergencyExitEnabled !== false);
                }
            } catch (err) {
                Alert.alert('Error', getApiErrorMessage(err));
            } finally {
                setLoading(false);
            }
        };
        load();
    }, []);

    const toggleApp = (pkg: string) => {
        setBlockedApps((prev) =>
            prev.includes(pkg) ? prev.filter((p) => p !== pkg) : [...prev, pkg]
        );
    };

    const handleSave = async () => {
        setSaving(true);
        try {
            await api.put('/focus-mode/settings', {
                blockedApps,
                focusDurationMinutes,
                breakDurationMinutes,
                enableDnd,
                enableAppOverlay,
                emergencyExitEnabled,
            });
            Alert.alert('Saved', 'Focus Mode settings successfully save ho gayi hain!');
            router.back();
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setSaving(false);
        }
    };

    return (
        <View style={styles.root}>
            <LinearGradient colors={Gradients.focus} style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={22} color={Colors.white} />
                </TouchableOpacity>
                <View style={{ flex: 1 }}>
                    <Text style={styles.headerTitle}>Focus Mode Settings</Text>
                    <Text style={styles.headerSub}>Distraction awareness &amp; study focus goals</Text>
                </View>
            </LinearGradient>

            {loading ? (
                <View style={styles.center}>
                    <ActivityIndicator size="large" color={Colors.secondary} />
                </View>
            ) : (
                <ScrollView contentContainerStyle={styles.body}>
                    {/* Honest Play Store Compliant Disclosure */}
                    <View style={styles.disclosureCard}>
                        <Ionicons name="shield-checkmark" size={22} color={Colors.secondary} />
                        <View style={{ flex: 1 }}>
                            <Text style={styles.disclosureTitle}>How Focus Mode Works</Text>
                            <Text style={styles.disclosureText}>
                                Focus Mode Android ki safe awareness permissions use karta hai: distraction apps kholne par reminder deta hai, distractions count karta hai aur study ke waqt emergency exit hamesha available rakhta hai. Ye kabhi aapke private messages ya data nahi padhta.
                            </Text>
                        </View>
                    </View>

                    {/* Distracting Apps Selector */}
                    <View style={styles.card}>
                        <Text style={styles.cardTitle}>Select Distracting Apps ({blockedApps.length})</Text>
                        <View style={styles.appsGrid}>
                            {POPULAR_APPS.map((app) => {
                                const selected = blockedApps.includes(app.pkg);
                                return (
                                    <TouchableOpacity
                                        key={app.pkg}
                                        onPress={() => toggleApp(app.pkg)}
                                        style={[styles.appTile, selected && styles.appTileActive]}
                                    >
                                        <Ionicons name={app.icon} size={24} color={app.color} />
                                        <Text style={styles.appName}>{app.name}</Text>
                                        <Ionicons
                                            name={selected ? 'checkmark-circle' : 'ellipse-outline'}
                                            size={18}
                                            color={selected ? Colors.secondary : Colors.textMuted}
                                        />
                                    </TouchableOpacity>
                                );
                            })}
                        </View>
                    </View>

                    {/* Focus & Break Durations */}
                    <View style={styles.card}>
                        <Text style={styles.cardTitle}>Focus Session Duration (Minutes)</Text>
                        <View style={styles.chipRow}>
                            {FOCUS_DURATIONS.map((m) => (
                                <TouchableOpacity
                                    key={m}
                                    onPress={() => setFocusDurationMinutes(m)}
                                    style={[styles.durChip, focusDurationMinutes === m && styles.durChipActive]}
                                >
                                    <Text
                                        style={[
                                            styles.durText,
                                            focusDurationMinutes === m && { color: Colors.white },
                                        ]}
                                    >
                                        {m}m
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>

                        <Text style={[styles.cardTitle, { marginTop: 10 }]}>Break Duration (Minutes)</Text>
                        <View style={styles.chipRow}>
                            {BREAK_DURATIONS.map((m) => (
                                <TouchableOpacity
                                    key={m}
                                    onPress={() => setBreakDurationMinutes(m)}
                                    style={[styles.durChip, breakDurationMinutes === m && styles.durChipActive]}
                                >
                                    <Text
                                        style={[
                                            styles.durText,
                                            breakDurationMinutes === m && { color: Colors.white },
                                        ]}
                                    >
                                        {m}m
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>

                    {/* Preferences */}
                    <View style={styles.card}>
                        <Text style={styles.cardTitle}>Focus Preferences &amp; Permissions</Text>

                        <View style={styles.toggleRow}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.toggleTitle}>Distraction Reminder Alert</Text>
                                <Text style={styles.toggleSub}>
                                    App switch hone par wapas padhai par aane ka reminder dikhayega
                                </Text>
                            </View>
                            <Switch
                                value={enableAppOverlay}
                                onValueChange={setEnableAppOverlay}
                                trackColor={{ false: Colors.border, true: Colors.secondary }}
                            />
                        </View>

                        <View style={styles.toggleRow}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.toggleTitle}>Do Not Disturb (DND)</Text>
                                <Text style={styles.toggleSub}>
                                    Study session ke dauran notifications silence karne ke liye
                                </Text>
                            </View>
                            <Switch
                                value={enableDnd}
                                onValueChange={setEnableDnd}
                                trackColor={{ false: Colors.border, true: Colors.secondary }}
                            />
                        </View>

                        <View style={styles.toggleRow}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.toggleTitle}>Emergency Exit Option</Text>
                                <Text style={styles.toggleSub}>
                                    Always allow instant exit with saved study time
                                </Text>
                            </View>
                            <Switch
                                value={emergencyExitEnabled}
                                onValueChange={setEmergencyExitEnabled}
                                trackColor={{ false: Colors.border, true: Colors.secondary }}
                            />
                        </View>

                        <TouchableOpacity
                            onPress={() => Linking.openSettings()}
                            style={styles.settingsLinkBtn}
                        >
                            <Ionicons name="settings-outline" size={16} color={Colors.primary} />
                            <Text style={styles.settingsLinkText}>Open Android App Permissions</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Save Button */}
                    <TouchableOpacity
                        disabled={saving}
                        onPress={handleSave}
                        style={styles.saveWrap}
                    >
                        <LinearGradient colors={Gradients.focus} style={styles.saveBtn}>
                            {saving ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <Text style={styles.saveText}>Save Focus Mode Settings</Text>
                            )}
                        </LinearGradient>
                    </TouchableOpacity>
                </ScrollView>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingTop: 54,
        paddingBottom: 20,
        paddingHorizontal: 16,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
    },
    backBtn: {
        width: 38,
        height: 38,
        borderRadius: 12,
        backgroundColor: 'rgba(255,255,255,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    headerTitle: { fontSize: 20, fontWeight: '800', color: Colors.white },
    headerSub: { fontSize: 12, color: '#FCE7F3', marginTop: 2 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    body: { padding: 16, gap: 16, paddingBottom: 36 },
    disclosureCard: {
        flexDirection: 'row',
        gap: 12,
        backgroundColor: '#FAF5FF',
        borderWidth: 1,
        borderColor: '#E9D5FF',
        borderRadius: 16,
        padding: 14,
    },
    disclosureTitle: { fontSize: 13, fontWeight: '800', color: Colors.secondary },
    disclosureText: { fontSize: 12, color: Colors.textSecondary, marginTop: 3, lineHeight: 18 },
    card: { backgroundColor: Colors.surface, borderRadius: 20, padding: 16, gap: 12, ...Shadows.card },
    cardTitle: { fontSize: 15, fontWeight: '800', color: Colors.text },
    appsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
    appTile: {
        width: '48%',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        padding: 12,
        borderRadius: 14,
        backgroundColor: Colors.surfaceAlt,
        borderWidth: 1.5,
        borderColor: Colors.border,
    },
    appTileActive: { backgroundColor: '#FAF5FF', borderColor: Colors.secondary },
    appName: { flex: 1, fontSize: 13, fontWeight: '700', color: Colors.text },
    chipRow: { flexDirection: 'row', gap: 10 },
    durChip: {
        flex: 1,
        paddingVertical: 10,
        borderRadius: 12,
        backgroundColor: Colors.surfaceAlt,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.border,
    },
    durChipActive: { backgroundColor: Colors.secondary, borderColor: Colors.secondary },
    durText: { fontSize: 14, fontWeight: '800', color: Colors.text },
    toggleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingVertical: 6,
    },
    toggleTitle: { fontSize: 14, fontWeight: '700', color: Colors.text },
    toggleSub: { fontSize: 11, color: Colors.textSecondary, marginTop: 2 },
    settingsLinkBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        paddingVertical: 10,
        borderRadius: 12,
        backgroundColor: Colors.primaryLight,
        marginTop: 4,
    },
    settingsLinkText: { fontSize: 13, fontWeight: '700', color: Colors.primary },
    saveWrap: { borderRadius: 16, overflow: 'hidden', ...Shadows.button },
    saveBtn: { height: 52, alignItems: 'center', justifyContent: 'center' },
    saveText: { color: Colors.white, fontSize: 15, fontWeight: '800' },
});