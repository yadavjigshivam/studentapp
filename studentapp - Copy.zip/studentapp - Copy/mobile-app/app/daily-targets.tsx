import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    TextInput,
    StyleSheet,
    ActivityIndicator,
    Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { api, createIdempotencyKey, getApiErrorMessage } from '../src/services/api';
import { Colors, Gradients, Shadows } from '../src/theme/colors';

type TaskType = 'study_time' | 'question_practice' | 'topic_completion' | 'revision';

interface TargetTask {
    id: string;
    taskType: TaskType;
    title: string;
    targetValue: number;
    currentValue: number;
    unit: string;
    isCompleted: boolean;
    isAutoTracked: boolean;
}

interface DailyTargetResponse {
    targetDate: string;
    isCompleted: boolean;
    completionPercentage: number;
    tasks: TargetTask[];
}

const TASK_TYPES: Array<{ key: TaskType; label: string; unit: string; color: string }> = [
    { key: 'study_time', label: 'Study Time', unit: 'min', color: Colors.primary },
    { key: 'question_practice', label: 'Questions', unit: 'Qs', color: Colors.success },
    { key: 'topic_completion', label: 'Topics', unit: 'topics', color: Colors.secondary },
    { key: 'revision', label: 'Revision', unit: 'items', color: Colors.warning },
];

export default function DailyTargetsScreen() {
    const router = useRouter();
    const [data, setData] = useState<DailyTargetResponse | null>(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [taskType, setTaskType] = useState<TaskType>('study_time');
    const [title, setTitle] = useState('');
    const [targetValue, setTargetValue] = useState('60');

    const loadTargets = async () => {
        try {
            const res = await api.get('/daily-targets');
            setData(res.data.data);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadTargets();
    }, []);

    const handleAddTask = async () => {
        const val = Number(targetValue);
        if (!title.trim() || !val || val <= 0) {
            Alert.alert('Invalid Target', 'Title aur valid number (jaise 60) daalein.');
            return;
        }
        setSaving(true);
        try {
            await api.post(
                '/daily-targets',
                {
                    tasks: [
                        {
                            taskType,
                            title: title.trim(),
                            targetValue: val,
                            isAutoTracked: taskType !== 'revision',
                        },
                    ],
                },
                { headers: { 'Idempotency-Key': createIdempotencyKey() } }
            );
            setTitle('');
            await loadTargets();
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setSaving(false);
        }
    };

    const toggleComplete = async (task: TargetTask) => {
        try {
            await api.patch(`/daily-targets/tasks/${task.id}/complete`, {
                isCompleted: !task.isCompleted,
            });
            await loadTargets();
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        }
    };

    const deleteTask = async (taskId: string) => {
        try {
            await api.delete(`/daily-targets/tasks/${taskId}`);
            await loadTargets();
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        }
    };

    return (
        <View style={styles.root}>
            <LinearGradient colors={Gradients.hero} style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={22} color={Colors.white} />
                </TouchableOpacity>
                <View style={{ flex: 1 }}>
                    <Text style={styles.headerTitle}>Daily Study Targets</Text>
                    <Text style={styles.headerSub}>
                        {data?.targetDate || 'Today'} • {Math.round(data?.completionPercentage ?? 0)}% Completed
                    </Text>
                </View>
            </LinearGradient>

            <ScrollView contentContainerStyle={styles.body}>
                {/* Add New Target Form */}
                <View style={styles.card}>
                    <Text style={styles.cardTitle}>Add New Goal for Today</Text>

                    <View style={styles.typeRow}>
                        {TASK_TYPES.map((t) => {
                            const active = taskType === t.key;
                            return (
                                <TouchableOpacity
                                    key={t.key}
                                    onPress={() => setTaskType(t.key)}
                                    style={[
                                        styles.typeChip,
                                        active && { backgroundColor: t.color, borderColor: t.color },
                                    ]}
                                >
                                    <Text style={[styles.typeText, active && { color: Colors.white }]}>
                                        {t.label}
                                    </Text>
                                </TouchableOpacity>
                            );
                        })}
                    </View>

                    <TextInput
                        style={styles.input}
                        placeholder="e.g. Study Hindi Grammar for 60 min"
                        value={title}
                        onChangeText={setTitle}
                    />

                    <View style={styles.row}>
                        <TextInput
                            style={[styles.input, { flex: 1 }]}
                            placeholder="Target Value (e.g. 60)"
                            keyboardType="numeric"
                            value={targetValue}
                            onChangeText={setTargetValue}
                        />
                        <TouchableOpacity
                            disabled={saving}
                            onPress={handleAddTask}
                            style={styles.addBtn}
                        >
                            {saving ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <>
                                    <Ionicons name="add" size={20} color={Colors.white} />
                                    <Text style={styles.addBtnText}>Add Goal</Text>
                                </>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Tasks List */}
                {loading ? (
                    <ActivityIndicator style={{ marginTop: 32 }} size="large" color={Colors.primary} />
                ) : !data || data.tasks.length === 0 ? (
                    <View style={styles.emptyBox}>
                        <Ionicons name="flag-outline" size={44} color={Colors.textMuted} />
                        <Text style={styles.emptyTitle}>No targets set for today</Text>
                        <Text style={styles.emptySub}>
                            Upar se apna pehla daily goal banayein. Study Timer aur Practice se progress apne aap update hogi!
                        </Text>
                    </View>
                ) : (
                    <View style={{ gap: 12 }}>
                        {data.tasks.map((task) => {
                            const pct = Math.min(
                                100,
                                Math.round((task.currentValue / Math.max(1, task.targetValue)) * 100)
                            );
                            return (
                                <View key={task.id} style={styles.taskCard}>
                                    <TouchableOpacity onPress={() => toggleComplete(task)}>
                                        <Ionicons
                                            name={task.isCompleted ? 'checkmark-circle' : 'ellipse-outline'}
                                            size={26}
                                            color={task.isCompleted ? Colors.success : Colors.textMuted}
                                        />
                                    </TouchableOpacity>

                                    <View style={{ flex: 1 }}>
                                        <Text
                                            style={[
                                                styles.taskTitle,
                                                task.isCompleted && { textDecorationLine: 'line-through', color: Colors.textMuted },
                                            ]}
                                        >
                                            {task.title}
                                        </Text>
                                        <View style={styles.taskMetaRow}>
                                            <Text style={styles.taskCount}>
                                                {task.currentValue} / {task.targetValue} {task.unit} ({pct}%)
                                            </Text>
                                            {task.isAutoTracked && (
                                                <View style={styles.autoPill}>
                                                    <Text style={styles.autoPillText}>Auto-tracked</Text>
                                                </View>
                                            )}
                                        </View>
                                        <View style={styles.barBg}>
                                            <View
                                                style={[
                                                    styles.barFill,
                                                    {
                                                        width: `${pct}%`,
                                                        backgroundColor: task.isCompleted ? Colors.success : Colors.primary,
                                                    },
                                                ]}
                                            />
                                        </View>
                                    </View>

                                    <TouchableOpacity onPress={() => deleteTask(task.id)} style={{ padding: 4 }}>
                                        <Ionicons name="trash-outline" size={20} color={Colors.danger} />
                                    </TouchableOpacity>
                                </View>
                            );
                        })}
                    </View>
                )}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingTop: 56,
        paddingBottom: 22,
        paddingHorizontal: 18,
        borderBottomLeftRadius: 24,
        borderBottomRightRadius: 24,
    },
    backBtn: {
        width: 38,
        height: 38,
        borderRadius: 12,
        backgroundColor: 'rgba(255,255,255,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    headerTitle: { fontSize: 20, fontWeight: '800', color: Colors.white },
    headerSub: { fontSize: 12, color: '#E0E7FF', marginTop: 2 },
    body: { padding: 18, gap: 18, paddingBottom: 40 },
    card: { backgroundColor: Colors.surface, borderRadius: 20, padding: 16, gap: 12, ...Shadows.card },
    cardTitle: { fontSize: 15, fontWeight: '700', color: Colors.text },
    typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    typeChip: {
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: Colors.border,
        backgroundColor: Colors.surfaceAlt,
    },
    typeText: { fontSize: 12, fontWeight: '700', color: Colors.textSecondary },
    input: {
        backgroundColor: Colors.surfaceAlt,
        borderWidth: 1,
        borderColor: Colors.border,
        borderRadius: 12,
        paddingHorizontal: 14,
        height: 46,
        fontSize: 14,
        color: Colors.text,
    },
    row: { flexDirection: 'row', gap: 10 },
    addBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 4,
        backgroundColor: Colors.primary,
        paddingHorizontal: 18,
        borderRadius: 12,
        height: 46,
    },
    addBtnText: { color: Colors.white, fontWeight: '700', fontSize: 14 },
    emptyBox: { alignItems: 'center', padding: 32 },
    emptyTitle: { fontSize: 16, fontWeight: '700', color: Colors.text, marginTop: 12 },
    emptySub: { fontSize: 13, color: Colors.textSecondary, textAlign: 'center', marginTop: 6 },
    taskCard: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        backgroundColor: Colors.surface,
        borderRadius: 16,
        padding: 14,
        ...Shadows.card,
    },
    taskTitle: { fontSize: 15, fontWeight: '700', color: Colors.text },
    taskMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
    taskCount: { fontSize: 12, fontWeight: '600', color: Colors.textSecondary },
    autoPill: { backgroundColor: Colors.primaryLight, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10 },
    autoPillText: { fontSize: 10, fontWeight: '700', color: Colors.primary },
    barBg: { height: 6, backgroundColor: Colors.surfaceAlt, borderRadius: 6, marginTop: 8, overflow: 'hidden' },
    barFill: { height: '100%', borderRadius: 6 },
});