import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    ActivityIndicator,
    RefreshControl,
    Modal,
    Alert,
    Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useRouter } from 'expo-router';
import { api, getApiErrorMessage } from '../../src/services/api';
import { useAuthStore } from '../../src/store/authStore';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

type ProgressStatus = 'not_started' | 'in_progress' | 'completed';

interface TopicItem {
    id: string;
    name: string;
    slug: string;
    description: string | null;
    estimatedStudyTimeMinutes: number | null;
    progress: {
        status: ProgressStatus;
        studyTimeSeconds: number;
        questionsAttempted: number;
        accuracy: number | null;
        completedAt: string | null;
    };
}

interface ChapterItem {
    id: string;
    name: string;
    slug: string;
    description: string | null;
    topics: TopicItem[];
}

interface SubjectItem {
    id: string;
    name: string;
    slug: string;
    description: string | null;
    progress: {
        status: ProgressStatus;
        completedTopics: number;
        totalTopics: number;
        remainingTopics: number;
        completionPercentage: number;
        totalStudySeconds: number;
    };
    chapters: ChapterItem[];
}

interface SyllabusData {
    examination: {
        id: string;
        name: string;
        slug: string;
        versionCode: string;
        officialNotificationPdfUrl: string | null;
    };
    subjects: SubjectItem[];
}

interface TopicNoteData {
    topicId: string;
    topicName: string;
    note: {
        id: string;
        title: string;
        summary: string | null;
        contentEn: string | null;
        contentHi: string | null;
        isBookmarked: boolean;
        bookmarkId: string | null;
    } | null;
}

const SUBJECT_ACCENTS = [
    '#4F46E5',
    '#0284C7',
    '#059669',
    '#7C3AED',
    '#D97706',
    '#DB2777',
];

function formatMinutes(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    if (mins < 60) return `${mins}m`;
    const hrs = Math.floor(mins / 60);
    const rem = mins % 60;
    return `${hrs}h ${rem}m`;
}

function getStatusBadge(status: ProgressStatus): { label: string; bg: string; color: string } {
    if (status === 'completed') {
        return { label: 'Completed', bg: Colors.successLight, color: '#047857' };
    }
    if (status === 'in_progress') {
        return { label: 'In Progress', bg: Colors.warningLight, color: '#B45309' };
    }
    return { label: 'Not Started', bg: Colors.surfaceAlt, color: Colors.textSecondary };
}

export default function StudyScreen() {
    const user = useAuthStore((s) => s.user);
    const router = useRouter();

    const enrolledExams = user?.enrolledExaminations || [];
    const defaultExamId =
        enrolledExams.find((e) => e.isPrimary)?.examinationId ||
        enrolledExams[0]?.examinationId ||
        '';

    const [selectedExamId, setSelectedExamId] = useState<string>(defaultExamId);
    const [syllabus, setSyllabus] = useState<SyllabusData | null>(null);
    const [expandedSubjectId, setExpandedSubjectId] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    // Bilingual Notes Modal state
    const [noteModalVisible, setNoteModalVisible] = useState(false);
    const [noteLoading, setNoteLoading] = useState(false);
    const [noteData, setNoteData] = useState<TopicNoteData | null>(null);
    const [noteLang, setNoteLang] = useState<'en' | 'hi'>('en');
    const [bookmarkBusy, setBookmarkBusy] = useState(false);

    const loadSyllabus = async (examIdToLoad: string) => {
        if (!examIdToLoad) {
            setLoading(false);
            setRefreshing(false);
            return;
        }
        try {
            const res = await api.get(`/examinations/${examIdToLoad}/syllabus`);
            const payload: SyllabusData = res.data.data;
            setSyllabus(payload);
            if (!expandedSubjectId && payload.subjects.length > 0) {
                setExpandedSubjectId(payload.subjects[0].id);
            }
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err, 'Syllabus load nahi ho paaya.'));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            const targetId = selectedExamId || defaultExamId;
            if (targetId && targetId !== selectedExamId) {
                setSelectedExamId(targetId);
            }
            loadSyllabus(targetId);
        }, [selectedExamId, defaultExamId])
    );

    const handleExamSwitch = (examId: string) => {
        setSelectedExamId(examId);
        setExpandedSubjectId(null);
        setLoading(true);
        loadSyllabus(examId);
    };

    const toggleTopicComplete = async (topic: TopicItem) => {
        const nextCompleted = topic.progress.status !== 'completed';
        try {
            await api.patch(`/topics/${topic.id}/complete`, { completed: nextCompleted });
            await loadSyllabus(selectedExamId || defaultExamId);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        }
    };

    const openNotes = async (topicId: string) => {
        setNoteModalVisible(true);
        setNoteLoading(true);
        setNoteData(null);
        try {
            const res = await api.get(`/topics/${topicId}/notes`);
            setNoteData(res.data.data);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
            setNoteModalVisible(false);
        } finally {
            setNoteLoading(false);
        }
    };

    const toggleNoteBookmark = async () => {
        if (!noteData?.note || bookmarkBusy) return;
        setBookmarkBusy(true);
        try {
            if (noteData.note.isBookmarked && noteData.note.bookmarkId) {
                await api.delete(`/bookmarks/${noteData.note.bookmarkId}`);
                setNoteData({
                    ...noteData,
                    note: { ...noteData.note, isBookmarked: false, bookmarkId: null },
                });
            } else {
                const res = await api.post('/bookmarks', {
                    bookmarkType: 'study_note',
                    studyNoteId: noteData.note.id,
                });
                setNoteData({
                    ...noteData,
                    note: {
                        ...noteData.note,
                        isBookmarked: true,
                        bookmarkId: res.data.data.bookmarkId,
                    },
                });
            }
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setBookmarkBusy(false);
        }
    };

    const startStudyMode = (params: {
        subjectId: string;
        subjectName: string;
        chapterId?: string;
        topicId?: string;
        topicName?: string;
    }) => {
        router.push({
            pathname: '/study-session',
            params: {
                subjectId: params.subjectId,
                subjectName: params.subjectName,
                chapterId: params.chapterId || '',
                topicId: params.topicId || '',
                topicName: params.topicName || params.subjectName,
                isFocusMode: '0',
            },
        });
    };

    return (
        <View style={styles.root}>
            {/* Colourful Study Header */}
            <LinearGradient colors={Gradients.study} style={styles.header}>
                <View style={styles.headerRow}>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.headerTitle}>Study &amp; Syllabus</Text>
                        <Text style={styles.headerSub}>
                            {syllabus?.examination.name || 'Select your target exam'} • v
                            {syllabus?.examination.versionCode || '1.0'}
                        </Text>
                    </View>
                    {syllabus?.examination.officialNotificationPdfUrl && (
                        <TouchableOpacity
                            onPress={() => Linking.openURL(syllabus.examination.officialNotificationPdfUrl!)}
                            style={styles.pdfBtn}
                        >
                            <Ionicons name="document-text" size={16} color={Colors.white} />
                            <Text style={styles.pdfBtnText}>PDF</Text>
                        </TouchableOpacity>
                    )}
                </View>

                {/* Multi-Exam Horizontal Switcher */}
                {enrolledExams.length > 0 && (
                    <ScrollView
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={styles.examChipsRow}
                    >
                        {enrolledExams.map((ex) => {
                            const active = ex.examinationId === (selectedExamId || defaultExamId);
                            return (
                                <TouchableOpacity
                                    key={ex.examinationId}
                                    onPress={() => handleExamSwitch(ex.examinationId)}
                                    style={[styles.examChip, active && styles.examChipActive]}
                                >
                                    <Text style={[styles.examChipText, active && styles.examChipTextActive]}>
                                        {ex.name}
                                    </Text>
                                </TouchableOpacity>
                            );
                        })}
                        <TouchableOpacity
                            onPress={() => router.push('/(auth)/select-exam')}
                            style={styles.addExamChip}
                        >
                            <Ionicons name="add" size={14} color={Colors.white} />
                            <Text style={styles.addExamText}>Manage</Text>
                        </TouchableOpacity>
                    </ScrollView>
                )}
            </LinearGradient>

            {loading ? (
                <View style={styles.center}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                </View>
            ) : !syllabus || syllabus.subjects.length === 0 ? (
                <View style={styles.emptyBox}>
                    <Ionicons name="book-outline" size={50} color={Colors.textMuted} />
                    <Text style={styles.emptyTitle}>No Syllabus Content Yet</Text>
                    <Text style={styles.emptySub}>
                        Admin Panel se is exam ke Subjects, Chapters aur Topics add karein, woh yahan turant dikhne lagenge.
                    </Text>
                </View>
            ) : (
                <ScrollView
                    contentContainerStyle={styles.scrollContent}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={() => {
                                setRefreshing(true);
                                loadSyllabus(selectedExamId || defaultExamId);
                            }}
                        />
                    }
                >
                    {syllabus.subjects.map((subject, idx) => {
                        const accent = SUBJECT_ACCENTS[idx % SUBJECT_ACCENTS.length];
                        const isExpanded = expandedSubjectId === subject.id;
                        const badge = getStatusBadge(subject.progress.status);

                        return (
                            <View key={subject.id} style={styles.subjectCard}>
                                {/* Subject Header */}
                                <TouchableOpacity
                                    activeOpacity={0.85}
                                    onPress={() => setExpandedSubjectId(isExpanded ? null : subject.id)}
                                    style={styles.subjectHeader}
                                >
                                    <View style={[styles.subjectIconBox, { backgroundColor: `${accent}18` }]}>
                                        <Ionicons name="book" size={22} color={accent} />
                                    </View>

                                    <View style={{ flex: 1 }}>
                                        <View style={styles.subjectTitleRow}>
                                            <Text style={styles.subjectName} numberOfLines={2}>
                                                {subject.name}
                                            </Text>
                                            <View style={[styles.statusBadge, { backgroundColor: badge.bg }]}>
                                                <Text style={[styles.statusText, { color: badge.color }]}>
                                                    {badge.label}
                                                </Text>
                                            </View>
                                        </View>

                                        <Text style={styles.subjectMeta}>
                                            {subject.progress.completedTopics}/{subject.progress.totalTopics} Topics •{' '}
                                            {formatMinutes(subject.progress.totalStudySeconds)} studied
                                        </Text>

                                        <View style={styles.progressRow}>
                                            <View style={styles.barBg}>
                                                <View
                                                    style={[
                                                        styles.barFill,
                                                        {
                                                            width: `${Math.min(100, subject.progress.completionPercentage)}%`,
                                                            backgroundColor: accent,
                                                        },
                                                    ]}
                                                />
                                            </View>
                                            <Text style={[styles.pctText, { color: accent }]}>
                                                {Math.round(subject.progress.completionPercentage)}%
                                            </Text>
                                        </View>
                                    </View>

                                    <Ionicons
                                        name={isExpanded ? 'chevron-up' : 'chevron-down'}
                                        size={20}
                                        color={Colors.textSecondary}
                                    />
                                </TouchableOpacity>

                                {/* Expanded Chapters & Topics */}
                                {isExpanded && (
                                    <View style={styles.chaptersWrap}>
                                        <TouchableOpacity
                                            onPress={() =>
                                                startStudyMode({
                                                    subjectId: subject.id,
                                                    subjectName: subject.name,
                                                })
                                            }
                                            style={[styles.subjectStudyBtn, { backgroundColor: `${accent}14` }]}
                                        >
                                            <Ionicons name="play-circle" size={18} color={accent} />
                                            <Text style={[styles.subjectStudyBtnText, { color: accent }]}>
                                                Start Studying {subject.name}
                                            </Text>
                                        </TouchableOpacity>

                                        {subject.chapters.length === 0 ? (
                                            <Text style={styles.noItemsText}>No chapters added in this subject yet.</Text>
                                        ) : (
                                            subject.chapters.map((chapter, cIdx) => (
                                                <View key={chapter.id} style={styles.chapterBlock}>
                                                    <Text style={styles.chapterTitle}>
                                                        Chapter {cIdx + 1}: {chapter.name}
                                                    </Text>

                                                    {chapter.topics.length === 0 ? (
                                                        <Text style={styles.noItemsText}>No topics in this chapter.</Text>
                                                    ) : (
                                                        chapter.topics.map((topic) => {
                                                            const done = topic.progress.status === 'completed';
                                                            return (
                                                                <View key={topic.id} style={styles.topicRow}>
                                                                    <TouchableOpacity
                                                                        onPress={() => toggleTopicComplete(topic)}
                                                                        style={styles.checkBtn}
                                                                    >
                                                                        <Ionicons
                                                                            name={done ? 'checkmark-circle' : 'ellipse-outline'}
                                                                            size={24}
                                                                            color={done ? Colors.success : Colors.textMuted}
                                                                        />
                                                                    </TouchableOpacity>

                                                                    <View style={{ flex: 1 }}>
                                                                        <Text
                                                                            style={[
                                                                                styles.topicName,
                                                                                done && { color: Colors.textSecondary },
                                                                            ]}
                                                                        >
                                                                            {topic.name}
                                                                        </Text>
                                                                        <Text style={styles.topicSub}>
                                                                            Est. {topic.estimatedStudyTimeMinutes ?? 30}m • Studied{' '}
                                                                            {formatMinutes(topic.progress.studyTimeSeconds)}
                                                                            {topic.progress.accuracy !== null
                                                                                ? ` • Acc ${topic.progress.accuracy}%`
                                                                                : ''}
                                                                        </Text>

                                                                        <View style={styles.topicActions}>
                                                                            <TouchableOpacity
                                                                                onPress={() => openNotes(topic.id)}
                                                                                style={styles.notesBtn}
                                                                            >
                                                                                <Ionicons
                                                                                    name="document-text-outline"
                                                                                    size={14}
                                                                                    color={Colors.primary}
                                                                                />
                                                                                <Text style={styles.notesBtnText}>Notes</Text>
                                                                            </TouchableOpacity>

                                                                            <TouchableOpacity
                                                                                onPress={() =>
                                                                                    startStudyMode({
                                                                                        subjectId: subject.id,
                                                                                        subjectName: subject.name,
                                                                                        chapterId: chapter.id,
                                                                                        topicId: topic.id,
                                                                                        topicName: topic.name,
                                                                                    })
                                                                                }
                                                                                style={[styles.studyBtn, { backgroundColor: accent }]}
                                                                            >
                                                                                <Ionicons name="play" size={13} color={Colors.white} />
                                                                                <Text style={styles.studyBtnText}>Study</Text>
                                                                            </TouchableOpacity>
                                                                        </View>
                                                                    </View>
                                                                </View>
                                                            );
                                                        })
                                                    )}
                                                </View>
                                            ))
                                        )}
                                    </View>
                                )}
                            </View>
                        );
                    })}
                </ScrollView>
            )}

            {/* Bilingual Study Notes Modal */}
            <Modal
                visible={noteModalVisible}
                animationType="slide"
                onRequestClose={() => setNoteModalVisible(false)}
            >
                <View style={styles.modalRoot}>
                    <LinearGradient colors={Gradients.hero} style={styles.modalHeader}>
                        <TouchableOpacity
                            onPress={() => setNoteModalVisible(false)}
                            style={styles.modalIconBtn}
                        >
                            <Ionicons name="close" size={22} color={Colors.white} />
                        </TouchableOpacity>

                        <View style={{ flex: 1 }}>
                            <Text style={styles.modalTitle} numberOfLines={1}>
                                {noteData?.topicName || 'Study Notes'}
                            </Text>
                            <Text style={styles.modalSub}>Topic Revision Material</Text>
                        </View>

                        {noteData?.note && (
                            <TouchableOpacity
                                disabled={bookmarkBusy}
                                onPress={toggleNoteBookmark}
                                style={styles.modalIconBtn}
                            >
                                <Ionicons
                                    name={noteData.note.isBookmarked ? 'bookmark' : 'bookmark-outline'}
                                    size={20}
                                    color={noteData.note.isBookmarked ? '#FDE047' : Colors.white}
                                />
                            </TouchableOpacity>
                        )}
                    </LinearGradient>

                    {noteLoading ? (
                        <View style={styles.center}>
                            <ActivityIndicator size="large" color={Colors.primary} />
                        </View>
                    ) : !noteData?.note ? (
                        <View style={styles.emptyBox}>
                            <Ionicons name="document-text-outline" size={48} color={Colors.textMuted} />
                            <Text style={styles.emptyTitle}>No Study Notes Added</Text>
                            <Text style={styles.emptySub}>
                                Is topic ke notes abhi Admin Panel se publish nahi kiye gaye hain.
                            </Text>
                        </View>
                    ) : (
                        <ScrollView contentContainerStyle={styles.modalBody}>
                            {/* Language Switcher */}
                            <View style={styles.langToggle}>
                                <TouchableOpacity
                                    onPress={() => setNoteLang('en')}
                                    style={[styles.langBtn, noteLang === 'en' && styles.langBtnActive]}
                                >
                                    <Text style={[styles.langText, noteLang === 'en' && styles.langTextActive]}>
                                        English
                                    </Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    onPress={() => setNoteLang('hi')}
                                    style={[styles.langBtn, noteLang === 'hi' && styles.langBtnActive]}
                                >
                                    <Text style={[styles.langText, noteLang === 'hi' && styles.langTextActive]}>
                                        Hindi (हिन्दी)
                                    </Text>
                                </TouchableOpacity>
                            </View>

                            <Text style={styles.noteHeading}>{noteData.note.title}</Text>

                            {noteData.note.summary && (
                                <View style={styles.summaryBox}>
                                    <Text style={styles.summaryLabel}>Quick Summary</Text>
                                    <Text style={styles.summaryText}>{noteData.note.summary}</Text>
                                </View>
                            )}

                            <View style={styles.noteContentCard}>
                                <Text style={styles.noteBodyText}>
                                    {noteLang === 'hi'
                                        ? noteData.note.contentHi ||
                                        noteData.note.contentEn ||
                                        'Hindi notes not available for this topic.'
                                        : noteData.note.contentEn ||
                                        noteData.note.contentHi ||
                                        'English notes not available for this topic.'}
                                </Text>
                            </View>
                        </ScrollView>
                    )}
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    header: {
        paddingTop: 56,
        paddingBottom: 18,
        paddingHorizontal: 18,
        borderBottomLeftRadius: 26,
        borderBottomRightRadius: 26,
    },
    headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    headerTitle: { fontSize: 23, fontWeight: '800', color: Colors.white },
    headerSub: { fontSize: 12, color: '#E0F2FE', marginTop: 3 },
    pdfBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        backgroundColor: 'rgba(255,255,255,0.22)',
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 12,
    },
    pdfBtnText: { color: Colors.white, fontSize: 12, fontWeight: '700' },
    examChipsRow: { gap: 8, paddingTop: 14 },
    examChip: {
        paddingHorizontal: 14,
        paddingVertical: 7,
        borderRadius: 20,
        backgroundColor: 'rgba(255,255,255,0.2)',
    },
    examChipActive: { backgroundColor: Colors.white },
    examChipText: { color: Colors.white, fontSize: 12, fontWeight: '700' },
    examChipTextActive: { color: '#0369A1' },
    addExamChip: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 3,
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.5)',
    },
    addExamText: { color: Colors.white, fontSize: 12, fontWeight: '600' },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    emptyBox: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
    emptyTitle: { fontSize: 17, fontWeight: '700', color: Colors.text, marginTop: 12 },
    emptySub: {
        fontSize: 13,
        color: Colors.textSecondary,
        textAlign: 'center',
        marginTop: 6,
        lineHeight: 20,
    },
    scrollContent: { padding: 16, gap: 14, paddingBottom: 32 },
    subjectCard: {
        backgroundColor: Colors.surface,
        borderRadius: 20,
        overflow: 'hidden',
        ...Shadows.card,
    },
    subjectHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        padding: 16,
    },
    subjectIconBox: {
        width: 46,
        height: 46,
        borderRadius: 14,
        alignItems: 'center',
        justifyContent: 'center',
    },
    subjectTitleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 8,
    },
    subjectName: { flex: 1, fontSize: 16, fontWeight: '800', color: Colors.text },
    statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
    statusText: { fontSize: 10, fontWeight: '700' },
    subjectMeta: { fontSize: 12, color: Colors.textSecondary, marginTop: 4 },
    progressRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 },
    barBg: {
        flex: 1,
        height: 7,
        backgroundColor: Colors.surfaceAlt,
        borderRadius: 8,
        overflow: 'hidden',
    },
    barFill: { height: '100%', borderRadius: 8 },
    pctText: { fontSize: 12, fontWeight: '800', width: 36, textAlign: 'right' },
    chaptersWrap: {
        borderTopWidth: 1,
        borderTopColor: Colors.border,
        padding: 14,
        backgroundColor: '#FAFBFD',
        gap: 12,
    },
    subjectStudyBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        paddingVertical: 10,
        borderRadius: 12,
    },
    subjectStudyBtnText: { fontSize: 13, fontWeight: '700' },
    chapterBlock: { gap: 8 },
    chapterTitle: {
        fontSize: 13,
        fontWeight: '800',
        color: Colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.4,
        marginTop: 4,
    },
    noItemsText: { fontSize: 12, color: Colors.textMuted, fontStyle: 'italic' },
    topicRow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 10,
        backgroundColor: Colors.surface,
        padding: 12,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    checkBtn: { paddingTop: 2 },
    topicName: { fontSize: 14, fontWeight: '700', color: Colors.text },
    topicSub: { fontSize: 11, color: Colors.textSecondary, marginTop: 3 },
    topicActions: { flexDirection: 'row', gap: 8, marginTop: 10 },
    notesBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: Colors.primaryLight,
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 10,
    },
    notesBtnText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
    studyBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        paddingHorizontal: 14,
        paddingVertical: 6,
        borderRadius: 10,
    },
    studyBtnText: { fontSize: 12, fontWeight: '700', color: Colors.white },
    modalRoot: { flex: 1, backgroundColor: Colors.bg },
    modalHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingTop: 52,
        paddingBottom: 18,
        paddingHorizontal: 16,
    },
    modalIconBtn: {
        width: 38,
        height: 38,
        borderRadius: 12,
        backgroundColor: 'rgba(255,255,255,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    modalTitle: { fontSize: 18, fontWeight: '800', color: Colors.white },
    modalSub: { fontSize: 12, color: '#E0E7FF', marginTop: 2 },
    modalBody: { padding: 18, gap: 14, paddingBottom: 40 },
    langToggle: {
        flexDirection: 'row',
        backgroundColor: Colors.surfaceAlt,
        borderRadius: 14,
        padding: 4,
    },
    langBtn: { flex: 1, paddingVertical: 9, alignItems: 'center', borderRadius: 11 },
    langBtnActive: { backgroundColor: Colors.primary },
    langText: { fontSize: 13, fontWeight: '700', color: Colors.textSecondary },
    langTextActive: { color: Colors.white },
    noteHeading: { fontSize: 20, fontWeight: '800', color: Colors.text },
    summaryBox: {
        backgroundColor: Colors.primaryLight,
        borderRadius: 14,
        padding: 14,
        borderLeftWidth: 4,
        borderLeftColor: Colors.primary,
    },
    summaryLabel: { fontSize: 11, fontWeight: '800', color: Colors.primary, textTransform: 'uppercase' },
    summaryText: { fontSize: 13, color: Colors.text, marginTop: 4, lineHeight: 20 },
    noteContentCard: {
        backgroundColor: Colors.surface,
        borderRadius: 16,
        padding: 16,
        ...Shadows.card,
    },
    noteBodyText: { fontSize: 15, color: Colors.text, lineHeight: 24 },
});