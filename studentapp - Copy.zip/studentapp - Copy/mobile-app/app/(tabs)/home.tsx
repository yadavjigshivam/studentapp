import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    RefreshControl,
    ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useRouter } from 'expo-router';
import { api } from '../../src/services/api';
import { useAuthStore } from '../../src/store/authStore';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

interface DashboardSummary {
    date: string;
    primaryExamination: { id: string; name: string; slug: string } | null;
    studyTime: {
        completedSeconds: number;
        targetSeconds: number;
        formattedCompleted: string;
        formattedTarget: string;
    };
    questions: {
        attemptedToday: number;
        correctToday: number;
        incorrectToday: number;
        accuracyToday: number;
        targetToday: number;
    };
    topics: {
        completedToday: number;
        targetToday: number;
    };
    dailyTargetCompletionPercentage: number;
    streak: {
        currentStreakDays: number;
        longestStreakDays: number;
        isActiveToday: boolean;
    };
}

interface ActiveSessionInfo {
    hasActiveSession: boolean;
    session: {
        id: string;
        subjectId: string | null;
        topicId: string | null;
        subjectName: string;
        topicName: string;
        status: string;
        isFocusMode: boolean;
        approximateElapsedSeconds: number;
    } | null;
}

export default function HomeDashboardScreen() {
    const user = useAuthStore((s) => s.user);
    const router = useRouter();

    const [summary, setSummary] = useState<DashboardSummary | null>(null);
    const [activeInfo, setActiveInfo] = useState<ActiveSessionInfo | null>(null);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const fetchData = async () => {
        try {
            const [dashRes, activeRes] = await Promise.all([
                api.get('/progress/dashboard-summary'),
                api.get('/study-sessions/active'),
            ]);
            setSummary(dashRes.data.data);
            setActiveInfo(activeRes.data.data);
        } catch {
            // Retain last loaded data
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchData();
        }, [])
    );

    const onRefresh = () => {
        setRefreshing(true);
        fetchData();
    };

    const todayDisplay = new Date().toLocaleDateString('en-IN', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
    });

    const studyPct = summary
        ? Math.min(
            100,
            Math.round(
                (summary.studyTime.completedSeconds / Math.max(1, summary.studyTime.targetSeconds)) * 100
            )
        )
        : 0;

    const qPct = summary
        ? Math.min(
            100,
            Math.round(
                (summary.questions.attemptedToday / Math.max(1, summary.questions.targetToday)) * 100
            )
        )
        : 0;

    const topicPct = summary
        ? Math.min(
            100,
            Math.round((summary.topics.completedToday / Math.max(1, summary.topics.targetToday)) * 100)
        )
        : 0;

    if (loading && !summary) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color={Colors.primary} />
            </View>
        );
    }

    return (
        <ScrollView
            style={styles.root}
            contentContainerStyle={styles.content}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        >
            {/* Colourful Gradient Hero Header */}
            <LinearGradient colors={Gradients.hero} style={styles.hero}>
                <View style={styles.heroTopRow}>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.dateText}>{todayDisplay}</Text>
                        <Text style={styles.greeting}>Hello, {user?.firstName || 'Student'}!</Text>
                        <View style={styles.examPill}>
                            <Ionicons name="ribbon" size={14} color="#FDE047" />
                            <Text style={styles.examPillText}>
                                {summary?.primaryExamination?.name || 'Select Your Exam'}
                            </Text>
                        </View>
                    </View>

                    <LinearGradient colors={Gradients.streak} style={styles.streakBadge}>
                        <Ionicons name="flame" size={22} color={Colors.white} />
                        <Text style={styles.streakNum}>{summary?.streak.currentStreakDays ?? 0}</Text>
                        <Text style={styles.streakLbl}>Day Streak</Text>
                    </LinearGradient>
                </View>

                {/* Daily Target Progress Strip inside Hero */}
                <TouchableOpacity
                    activeOpacity={0.85}
                    onPress={() => router.push('/daily-targets')}
                    style={styles.targetHeroCard}
                >
                    <View style={styles.targetHeroTop}>
                        <Text style={styles.targetHeroTitle}>Today&apos;s Target Completion</Text>
                        <Text style={styles.targetHeroPct}>
                            {Math.round(summary?.dailyTargetCompletionPercentage ?? 0)}%
                        </Text>
                    </View>
                    <View style={styles.heroBarBg}>
                        <View
                            style={[
                                styles.heroBarFill,
                                { width: `${Math.min(100, summary?.dailyTargetCompletionPercentage ?? 0)}%` },
                            ]}
                        />
                    </View>
                    <Text style={styles.targetHeroSub}>Tap to manage your daily study targets →</Text>
                </TouchableOpacity>
            </LinearGradient>

            {/* Interrupted / Active Study Session Recovery Banner */}
            {activeInfo?.hasActiveSession && activeInfo.session && (
                <TouchableOpacity
                    activeOpacity={0.9}
                    onPress={() =>
                        router.push({
                            pathname: '/study-session',
                            params: {
                                resumeSessionId: activeInfo.session!.id,
                                subjectName: activeInfo.session!.subjectName,
                                topicName: activeInfo.session!.topicName,
                                topicId: activeInfo.session!.topicId || '',
                                subjectId: activeInfo.session!.subjectId || '',
                                isFocusMode: activeInfo.session!.isFocusMode ? '1' : '0',
                            },
                        })
                    }
                    style={styles.recoveryBanner}
                >
                    <Ionicons name="time" size={24} color="#B45309" />
                    <View style={{ flex: 1 }}>
                        <Text style={styles.recoveryTitle}>Unfinished Study Session Found</Text>
                        <Text style={styles.recoverySub}>
                            {activeInfo.session.topicName} • {Math.floor(activeInfo.session.approximateElapsedSeconds / 60)}m recorded. Tap to Resume or End.
                        </Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="#B45309" />
                </TouchableOpacity>
            )}

            {/* Quick Action Buttons: Continue Studying + Start Focus Mode */}
            <View style={styles.quickActions}>
                <TouchableOpacity
                    activeOpacity={0.85}
                    style={styles.actionBtnWrap}
                    onPress={() => router.push('/(tabs)/study')}
                >
                    <LinearGradient colors={Gradients.study} style={styles.actionBtn}>
                        <Ionicons name="play-circle" size={24} color={Colors.white} />
                        <Text style={styles.actionTitle}>Continue Studying</Text>
                        <Text style={styles.actionSub}>Open syllabus &amp; timer</Text>
                    </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                    activeOpacity={0.85}
                    style={styles.actionBtnWrap}
                    onPress={() =>
                        router.push({
                            pathname: '/study-session',
                            params: {
                                subjectName: summary?.primaryExamination?.name || 'Focus Session',
                                topicName: 'Deep Focus Study',
                                isFocusMode: '1',
                            },
                        })
                    }
                >
                    <LinearGradient colors={Gradients.focus} style={styles.actionBtn}>
                        <Ionicons name="flash" size={24} color={Colors.white} />
                        <Text style={styles.actionTitle}>Start Focus Mode</Text>
                        <Text style={styles.actionSub}>Distraction-free timer</Text>
                    </LinearGradient>
                </TouchableOpacity>
            </View>

            {/* Today's Study Report */}
            <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Today&apos;s Study Report</Text>
                <TouchableOpacity onPress={() => router.push('/daily-targets')}>
                    <Text style={styles.sectionLink}>+ Set Targets</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.reportCard}>
                {/* 1. Study Time */}
                <View style={styles.metricBlock}>
                    <View style={styles.metricRow}>
                        <View style={styles.metricLabelWrap}>
                            <View style={[styles.dot, { backgroundColor: Colors.primary }]} />
                            <Text style={styles.metricLabel}>Study Time</Text>
                        </View>
                        <Text style={styles.metricVal}>
                            {summary?.studyTime.formattedCompleted || '0h 00m'} /{' '}
                            {summary?.studyTime.formattedTarget || '2h 00m'}
                        </Text>
                    </View>
                    <View style={styles.barBg}>
                        <View style={[styles.barFill, { width: `${studyPct}%`, backgroundColor: Colors.primary }]} />
                    </View>
                </View>

                {/* 2. Questions Practiced */}
                <View style={styles.metricBlock}>
                    <View style={styles.metricRow}>
                        <View style={styles.metricLabelWrap}>
                            <View style={[styles.dot, { backgroundColor: Colors.success }]} />
                            <Text style={styles.metricLabel}>Questions Practiced</Text>
                        </View>
                        <Text style={styles.metricVal}>
                            {summary?.questions.attemptedToday ?? 0} / {summary?.questions.targetToday ?? 100}
                        </Text>
                    </View>
                    <View style={styles.barBg}>
                        <View style={[styles.barFill, { width: `${qPct}%`, backgroundColor: Colors.success }]} />
                    </View>
                </View>

                {/* 3. Topics Completed */}
                <View style={styles.metricBlock}>
                    <View style={styles.metricRow}>
                        <View style={styles.metricLabelWrap}>
                            <View style={[styles.dot, { backgroundColor: Colors.secondary }]} />
                            <Text style={styles.metricLabel}>Topics Completed</Text>
                        </View>
                        <Text style={styles.metricVal}>
                            {summary?.topics.completedToday ?? 0} / {summary?.topics.targetToday ?? 2}
                        </Text>
                    </View>
                    <View style={styles.barBg}>
                        <View style={[styles.barFill, { width: `${topicPct}%`, backgroundColor: Colors.secondary }]} />
                    </View>
                </View>
            </View>

            {/* Daily Accuracy Breakdown Tiles */}
            <View style={styles.statsGrid}>
                <View style={[styles.statTile, { backgroundColor: Colors.successLight }]}>
                    <Text style={[styles.statTileNum, { color: '#047857' }]}>
                        {summary?.questions.correctToday ?? 0}
                    </Text>
                    <Text style={styles.statTileLbl}>Correct</Text>
                </View>

                <View style={[styles.statTile, { backgroundColor: Colors.dangerLight }]}>
                    <Text style={[styles.statTileNum, { color: '#B91C1C' }]}>
                        {summary?.questions.incorrectToday ?? 0}
                    </Text>
                    <Text style={styles.statTileLbl}>Incorrect</Text>
                </View>

                <View style={[styles.statTile, { backgroundColor: Colors.primaryLight }]}>
                    <Text style={[styles.statTileNum, { color: Colors.primary }]}>
                        {summary?.questions.accuracyToday ?? 0}%
                    </Text>
                    <Text style={styles.statTileLbl}>Accuracy</Text>
                </View>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    content: { paddingBottom: 32 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.bg },
    hero: {
        paddingTop: 56,
        paddingBottom: 24,
        paddingHorizontal: 20,
        borderBottomLeftRadius: 28,
        borderBottomRightRadius: 28,
    },
    heroTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
    dateText: { fontSize: 12, color: '#C7D2FE', fontWeight: '600' },
    greeting: { fontSize: 24, fontWeight: '800', color: Colors.white, marginTop: 4 },
    examPill: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        alignSelf: 'flex-start',
        backgroundColor: 'rgba(255,255,255,0.18)',
        paddingHorizontal: 12,
        paddingVertical: 5,
        borderRadius: 20,
        marginTop: 8,
    },
    examPillText: { color: Colors.white, fontSize: 12, fontWeight: '700' },
    streakBadge: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 14,
        paddingVertical: 10,
        borderRadius: 18,
        minWidth: 74,
    },
    streakNum: { color: Colors.white, fontSize: 20, fontWeight: '800', marginTop: 2 },
    streakLbl: { color: '#FEF3C7', fontSize: 10, fontWeight: '700' },
    targetHeroCard: {
        marginTop: 20,
        backgroundColor: 'rgba(255,255,255,0.16)',
        borderRadius: 16,
        padding: 14,
    },
    targetHeroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    targetHeroTitle: { color: Colors.white, fontSize: 13, fontWeight: '700' },
    targetHeroPct: { color: '#FDE047', fontSize: 16, fontWeight: '800' },
    heroBarBg: {
        height: 8,
        backgroundColor: 'rgba(255,255,255,0.25)',
        borderRadius: 8,
        marginTop: 10,
        overflow: 'hidden',
    },
    heroBarFill: { height: '100%', backgroundColor: '#4ADE80', borderRadius: 8 },
    targetHeroSub: { color: '#E0E7FF', fontSize: 11, marginTop: 8, fontWeight: '500' },
    recoveryBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        backgroundColor: Colors.warningLight,
        borderWidth: 1,
        borderColor: '#FDE68A',
        marginHorizontal: 18,
        marginTop: 16,
        padding: 14,
        borderRadius: 16,
    },
    recoveryTitle: { fontSize: 14, fontWeight: '700', color: '#92400E' },
    recoverySub: { fontSize: 12, color: '#B45309', marginTop: 2 },
    quickActions: {
        flexDirection: 'row',
        gap: 12,
        paddingHorizontal: 18,
        marginTop: 18,
    },
    actionBtnWrap: { flex: 1, borderRadius: 18, overflow: 'hidden', ...Shadows.card },
    actionBtn: { padding: 16, minHeight: 104, justifyContent: 'space-between' },
    actionTitle: { color: Colors.white, fontSize: 15, fontWeight: '800', marginTop: 8 },
    actionSub: { color: 'rgba(255,255,255,0.85)', fontSize: 11, marginTop: 2 },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        marginTop: 22,
        marginBottom: 10,
    },
    sectionTitle: { fontSize: 17, fontWeight: '800', color: Colors.text },
    sectionLink: { fontSize: 13, fontWeight: '700', color: Colors.primary },
    reportCard: {
        backgroundColor: Colors.surface,
        marginHorizontal: 18,
        borderRadius: 20,
        padding: 18,
        gap: 16,
        ...Shadows.card,
    },
    metricBlock: { gap: 8 },
    metricRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    metricLabelWrap: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    dot: { width: 10, height: 10, borderRadius: 5 },
    metricLabel: { fontSize: 14, fontWeight: '600', color: Colors.text },
    metricVal: { fontSize: 13, fontWeight: '700', color: Colors.textSecondary },
    barBg: { height: 9, backgroundColor: Colors.surfaceAlt, borderRadius: 8, overflow: 'hidden' },
    barFill: { height: '100%', borderRadius: 8 },
    statsGrid: {
        flexDirection: 'row',
        gap: 10,
        marginHorizontal: 18,
        marginTop: 14,
    },
    statTile: {
        flex: 1,
        borderRadius: 16,
        paddingVertical: 14,
        alignItems: 'center',
    },
    statTileNum: { fontSize: 20, fontWeight: '800' },
    statTileLbl: { fontSize: 12, fontWeight: '600', color: Colors.textSecondary, marginTop: 4 },
});