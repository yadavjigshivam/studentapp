import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    Modal,
    TextInput,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useRouter } from 'expo-router';
import { api, getApiErrorMessage } from '../../src/services/api';
import { useAuthStore } from '../../src/store/authStore';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

interface BookmarkItem {
    id: string;
    bookmarkType: 'question' | 'study_note';
    createdAt: string;
    question?: {
        id: string;
        questionTextEn: string;
        questionTextHi: string | null;
        difficultyLevel: string;
        subject?: { id: string; name: string };
    } | null;
    studyNote?: {
        id: string;
        title: string;
        summary: string | null;
        topic?: { id: string; name: string };
    } | null;
}

export default function ProfileScreen() {
    const { user, refreshProfile, logout } = useAuthStore();
    const router = useRouter();

    // Edit Profile Modal
    const [editModal, setEditModal] = useState(false);
    const [firstName, setFirstName] = useState(user?.firstName || '');
    const [lastName, setLastName] = useState(user?.lastName || '');
    const [phone, setPhone] = useState(user?.phone || '');
    const [savingProfile, setSavingProfile] = useState(false);

    // Change Password Modal
    const [pwdModal, setPwdModal] = useState(false);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [savingPwd, setSavingPwd] = useState(false);

    // Bookmarks Modal
    const [bmModal, setBmModal] = useState(false);
    const [bmTab, setBmTab] = useState<'question' | 'study_note'>('question');
    const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
    const [loadingBm, setLoadingBm] = useState(false);

    useFocusEffect(
        useCallback(() => {
            refreshProfile().catch(() => { });
        }, [])
    );

    const openEditProfile = () => {
        setFirstName(user?.firstName || '');
        setLastName(user?.lastName || '');
        setPhone(user?.phone || '');
        setEditModal(true);
    };

    const handleSaveProfile = async () => {
        if (!firstName.trim()) {
            Alert.alert('Validation', 'First name is required.');
            return;
        }
        setSavingProfile(true);
        try {
            await api.patch('/users/me', {
                firstName: firstName.trim(),
                lastName: lastName.trim() || null,
                phone: phone.trim() || null,
            });
            await refreshProfile();
            setEditModal(false);
            Alert.alert('Updated', 'Profile successfully update ho gaya.');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setSavingProfile(false);
        }
    };

    const handleChangePassword = async () => {
        if (!currentPassword || !newPassword) {
            Alert.alert('Validation', 'Current aur new password dono bharein.');
            return;
        }
        if (newPassword !== confirmPassword) {
            Alert.alert('Validation', 'New password aur confirm password match nahi kar rahe.');
            return;
        }
        setSavingPwd(true);
        try {
            await api.post('/auth/change-password', {
                currentPassword,
                newPassword,
                confirmPassword,
            });
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
            setPwdModal(false);
            Alert.alert('Success', 'Password successfully change ho gaya.');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setSavingPwd(false);
        }
    };

    const loadBookmarks = async (type: 'question' | 'study_note') => {
        setLoadingBm(true);
        try {
            const res = await api.get(`/bookmarks?type=${type}&limit=50`);
            setBookmarks(res.data.data || []);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setLoadingBm(false);
        }
    };

    const openBookmarks = () => {
        setBmModal(true);
        loadBookmarks(bmTab);
    };

    const removeBookmark = async (id: string) => {
        try {
            await api.delete(`/bookmarks/${id}`);
            setBookmarks((prev) => prev.filter((b) => b.id !== id));
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        }
    };

    const handleLogout = () => {
        Alert.alert('Sign Out', 'Kya aap account se logout karna chahte hain?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Logout',
                style: 'destructive',
                onPress: async () => {
                    await logout();
                },
            },
        ]);
    };

    const initials = `${user?.firstName?.[0] || 'S'}${user?.lastName?.[0] || ''}`.toUpperCase();

    return (
        <View style={styles.root}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                {/* Profile Hero */}
                <LinearGradient colors={Gradients.hero} style={styles.hero}>
                    <View style={styles.avatar}>
                        <Text style={styles.avatarText}>{initials}</Text>
                    </View>
                    <Text style={styles.name}>
                        {user?.displayName || `${user?.firstName || ''} ${user?.lastName || ''}`.trim()}
                    </Text>
                    <Text style={styles.email}>{user?.email}</Text>
                    {user?.phone && <Text style={styles.phone}>{user.phone}</Text>}

                    <View style={styles.streakStrip}>
                        <View style={styles.stripItem}>
                            <Text style={styles.stripNum}>{user?.streak?.currentStreak ?? 0}</Text>
                            <Text style={styles.stripLbl}>Current Streak</Text>
                        </View>
                        <View style={styles.stripDivider} />
                        <View style={styles.stripItem}>
                            <Text style={styles.stripNum}>{user?.streak?.longestStreak ?? 0}</Text>
                            <Text style={styles.stripLbl}>Best Streak</Text>
                        </View>
                        <View style={styles.stripDivider} />
                        <View style={styles.stripItem}>
                            <Text style={styles.stripNum}>{user?.enrolledExaminations?.length ?? 0}</Text>
                            <Text style={styles.stripLbl}>Target Exams</Text>
                        </View>
                    </View>
                </LinearGradient>

                {/* Enrolled Examinations Card */}
                <View style={styles.sectionCard}>
                    <View style={styles.sectionTop}>
                        <Text style={styles.sectionTitle}>My Target Examinations</Text>
                        <TouchableOpacity onPress={() => router.push('/(auth)/select-exam')}>
                            <Text style={styles.linkText}>Manage</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.examChips}>
                        {(user?.enrolledExaminations || []).length === 0 ? (
                            <Text style={styles.mutedText}>No examinations selected yet.</Text>
                        ) : (
                            user!.enrolledExaminations.map((ex) => (
                                <View
                                    key={ex.examinationId}
                                    style={[styles.examTag, ex.isPrimary && styles.examTagPrimary]}
                                >
                                    {ex.isPrimary && <Ionicons name="star" size={12} color={Colors.white} />}
                                    <Text
                                        style={[
                                            styles.examTagText,
                                            ex.isPrimary && { color: Colors.white },
                                        ]}
                                    >
                                        {ex.name}
                                    </Text>
                                </View>
                            ))
                        )}
                    </View>
                </View>

                {/* Menu Actions */}
                <View style={styles.menuCard}>
                    <TouchableOpacity onPress={openEditProfile} style={styles.menuRow}>
                        <View style={[styles.menuIcon, { backgroundColor: Colors.primaryLight }]}>
                            <Ionicons name="person-outline" size={20} color={Colors.primary} />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.menuTitle}>Edit Profile</Text>
                            <Text style={styles.menuSub}>Update name &amp; contact details</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={Colors.textMuted} />
                    </TouchableOpacity>

                    <TouchableOpacity onPress={openBookmarks} style={styles.menuRow}>
                        <View style={[styles.menuIcon, { backgroundColor: Colors.warningLight }]}>
                            <Ionicons name="bookmark-outline" size={20} color={Colors.warning} />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.menuTitle}>Saved Bookmarks</Text>
                            <Text style={styles.menuSub}>Bookmarked MCQs &amp; study notes</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={Colors.textMuted} />
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => router.push('/daily-targets')}
                        style={styles.menuRow}
                    >
                        <View style={[styles.menuIcon, { backgroundColor: Colors.successLight }]}>
                            <Ionicons name="flag-outline" size={20} color={Colors.success} />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.menuTitle}>Daily Study Targets</Text>
                            <Text style={styles.menuSub}>Set and review daily goals</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={Colors.textMuted} />
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => router.push('/focus-settings')}
                        style={styles.menuRow}
                    >
                        <View style={[styles.menuIcon, { backgroundColor: '#F3E8FF' }]}>
                            <Ionicons name="flash-outline" size={20} color={Colors.secondary} />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.menuTitle}>Focus Mode Settings</Text>
                            <Text style={styles.menuSub}>Distracting apps, focus duration &amp; DND</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={Colors.textMuted} />
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => setPwdModal(true)} style={styles.menuRow}>
                        <View style={[styles.menuIcon, { backgroundColor: '#E0F2FE' }]}>
                            <Ionicons name="lock-closed-outline" size={20} color="#0284C7" />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.menuTitle}>Change Password</Text>
                            <Text style={styles.menuSub}>Update account security password</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={Colors.textMuted} />
                    </TouchableOpacity>
                </View>

                {/* Logout Button */}
                <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
                    <Ionicons name="log-out-outline" size={20} color={Colors.danger} />
                    <Text style={styles.logoutText}>Sign Out</Text>
                </TouchableOpacity>

                <Text style={styles.versionText}>
                    ExamPro Study v{process.env.EXPO_PUBLIC_APP_VERSION || '1.0.0'}
                </Text>
            </ScrollView>

            {/* Edit Profile Modal */}
            <Modal visible={editModal} transparent animationType="slide">
                <View style={styles.sheetOverlay}>
                    <View style={styles.sheetBox}>
                        <View style={styles.sheetHeader}>
                            <Text style={styles.sheetTitle}>Edit Profile</Text>
                            <TouchableOpacity onPress={() => setEditModal(false)}>
                                <Ionicons name="close" size={24} color={Colors.textSecondary} />
                            </TouchableOpacity>
                        </View>

                        <TextInput
                            style={styles.input}
                            placeholder="First Name"
                            value={firstName}
                            onChangeText={setFirstName}
                        />
                        <TextInput
                            style={styles.input}
                            placeholder="Last Name"
                            value={lastName}
                            onChangeText={setLastName}
                        />
                        <TextInput
                            style={styles.input}
                            placeholder="Phone (+91...)"
                            keyboardType="phone-pad"
                            value={phone}
                            onChangeText={setPhone}
                        />

                        <TouchableOpacity
                            disabled={savingProfile}
                            onPress={handleSaveProfile}
                            style={styles.saveBtn}
                        >
                            {savingProfile ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <Text style={styles.saveBtnText}>Save Changes</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* Change Password Modal */}
            <Modal visible={pwdModal} transparent animationType="slide">
                <View style={styles.sheetOverlay}>
                    <View style={styles.sheetBox}>
                        <View style={styles.sheetHeader}>
                            <Text style={styles.sheetTitle}>Change Password</Text>
                            <TouchableOpacity onPress={() => setPwdModal(false)}>
                                <Ionicons name="close" size={24} color={Colors.textSecondary} />
                            </TouchableOpacity>
                        </View>

                        <TextInput
                            style={styles.input}
                            placeholder="Current Password"
                            secureTextEntry
                            value={currentPassword}
                            onChangeText={setCurrentPassword}
                        />
                        <TextInput
                            style={styles.input}
                            placeholder="New Password (Min 8 chars, A-Z, a-z, 0-9, @#$)"
                            secureTextEntry
                            value={newPassword}
                            onChangeText={setNewPassword}
                        />
                        <TextInput
                            style={styles.input}
                            placeholder="Confirm New Password"
                            secureTextEntry
                            value={confirmPassword}
                            onChangeText={setConfirmPassword}
                        />

                        <TouchableOpacity
                            disabled={savingPwd}
                            onPress={handleChangePassword}
                            style={styles.saveBtn}
                        >
                            {savingPwd ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <Text style={styles.saveBtnText}>Update Password</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* Bookmarks Modal */}
            <Modal visible={bmModal} animationType="slide" onRequestClose={() => setBmModal(false)}>
                <View style={styles.root}>
                    <LinearGradient colors={Gradients.hero} style={styles.bmHeader}>
                        <TouchableOpacity onPress={() => setBmModal(false)} style={styles.bmCloseBtn}>
                            <Ionicons name="arrow-back" size={22} color={Colors.white} />
                        </TouchableOpacity>
                        <Text style={styles.bmHeaderTitle}>Saved Bookmarks</Text>
                    </LinearGradient>

                    <View style={styles.bmTabs}>
                        <TouchableOpacity
                            onPress={() => {
                                setBmTab('question');
                                loadBookmarks('question');
                            }}
                            style={[styles.bmTabBtn, bmTab === 'question' && styles.bmTabActive]}
                        >
                            <Text style={[styles.bmTabText, bmTab === 'question' && { color: Colors.white }]}>
                                Questions
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            onPress={() => {
                                setBmTab('study_note');
                                loadBookmarks('study_note');
                            }}
                            style={[styles.bmTabBtn, bmTab === 'study_note' && styles.bmTabActive]}
                        >
                            <Text style={[styles.bmTabText, bmTab === 'study_note' && { color: Colors.white }]}>
                                Study Notes
                            </Text>
                        </TouchableOpacity>
                    </View>

                    {loadingBm ? (
                        <ActivityIndicator style={{ marginTop: 40 }} size="large" color={Colors.primary} />
                    ) : bookmarks.length === 0 ? (
                        <View style={styles.emptyBm}>
                            <Ionicons name="bookmark-outline" size={48} color={Colors.textMuted} />
                            <Text style={styles.emptyBmTitle}>No Saved Bookmarks</Text>
                            <Text style={styles.emptyBmSub}>
                                Practice ya Study Notes padhte waqt bookmark icon tap karein — woh yahan save ho jayenge.
                            </Text>
                        </View>
                    ) : (
                        <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
                            {bookmarks.map((bm) => (
                                <View key={bm.id} style={styles.bmCard}>
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.bmTag}>
                                            {bm.bookmarkType === 'question'
                                                ? bm.question?.subject?.name || 'Question'
                                                : bm.studyNote?.topic?.name || 'Study Note'}
                                        </Text>
                                        <Text style={styles.bmText}>
                                            {bm.bookmarkType === 'question'
                                                ? bm.question?.questionTextEn || 'Saved question'
                                                : bm.studyNote?.title || 'Saved study note'}
                                        </Text>
                                    </View>
                                    <TouchableOpacity onPress={() => removeBookmark(bm.id)} style={{ padding: 6 }}>
                                        <Ionicons name="trash-outline" size={20} color={Colors.danger} />
                                    </TouchableOpacity>
                                </View>
                            ))}
                        </ScrollView>
                    )}
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    scrollContent: { paddingBottom: 36 },
    hero: {
        paddingTop: 60,
        paddingBottom: 24,
        paddingHorizontal: 20,
        alignItems: 'center',
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
    },
    avatar: {
        width: 76,
        height: 76,
        borderRadius: 26,
        backgroundColor: Colors.white,
        alignItems: 'center',
        justifyContent: 'center',
        ...Shadows.card,
    },
    avatarText: { fontSize: 28, fontWeight: '900', color: Colors.primary },
    name: { fontSize: 22, fontWeight: '800', color: Colors.white, marginTop: 12 },
    email: { fontSize: 13, color: '#E0E7FF', marginTop: 3 },
    phone: { fontSize: 12, color: '#C7D2FE', marginTop: 2 },
    streakStrip: {
        flexDirection: 'row',
        backgroundColor: 'rgba(255,255,255,0.16)',
        borderRadius: 18,
        paddingVertical: 12,
        paddingHorizontal: 14,
        marginTop: 18,
        width: '100%',
        alignItems: 'center',
    },
    stripItem: { flex: 1, alignItems: 'center' },
    stripNum: { fontSize: 18, fontWeight: '800', color: Colors.white },
    stripLbl: { fontSize: 10, color: '#E0E7FF', marginTop: 2, fontWeight: '600' },
    stripDivider: { width: 1, height: 28, backgroundColor: 'rgba(255,255,255,0.25)' },
    sectionCard: {
        backgroundColor: Colors.surface,
        marginHorizontal: 16,
        marginTop: 16,
        borderRadius: 20,
        padding: 16,
        ...Shadows.card,
    },
    sectionTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
    sectionTitle: { fontSize: 15, fontWeight: '800', color: Colors.text },
    linkText: { fontSize: 13, fontWeight: '700', color: Colors.primary },
    examChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    examTag: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        backgroundColor: Colors.surfaceAlt,
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 16,
    },
    examTagPrimary: { backgroundColor: Colors.primary },
    examTagText: { fontSize: 12, fontWeight: '700', color: Colors.text },
    mutedText: { fontSize: 13, color: Colors.textMuted },
    menuCard: {
        backgroundColor: Colors.surface,
        marginHorizontal: 16,
        marginTop: 14,
        borderRadius: 20,
        overflow: 'hidden',
        ...Shadows.card,
    },
    menuRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        padding: 15,
        borderBottomWidth: 1,
        borderBottomColor: Colors.surfaceAlt,
    },
    menuIcon: {
        width: 40,
        height: 40,
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
    },
    menuTitle: { fontSize: 15, fontWeight: '700', color: Colors.text },
    menuSub: { fontSize: 11, color: Colors.textSecondary, marginTop: 2 },
    logoutBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        marginHorizontal: 16,
        marginTop: 18,
        backgroundColor: Colors.dangerLight,
        borderWidth: 1,
        borderColor: '#FECACA',
        paddingVertical: 14,
        borderRadius: 16,
    },
    logoutText: { color: Colors.danger, fontSize: 15, fontWeight: '800' },
    versionText: {
        textAlign: 'center',
        fontSize: 11,
        color: Colors.textMuted,
        marginTop: 14,
    },
    sheetOverlay: {
        flex: 1,
        backgroundColor: 'rgba(15,23,42,0.55)',
        justifyContent: 'flex-end',
    },
    sheetBox: {
        backgroundColor: Colors.surface,
        borderTopLeftRadius: 26,
        borderTopRightRadius: 26,
        padding: 20,
        paddingBottom: 30,
        gap: 12,
    },
    sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
    sheetTitle: { fontSize: 18, fontWeight: '800', color: Colors.text },
    input: {
        backgroundColor: Colors.surfaceAlt,
        borderWidth: 1,
        borderColor: Colors.border,
        borderRadius: 12,
        paddingHorizontal: 14,
        height: 48,
        fontSize: 14,
        color: Colors.text,
    },
    saveBtn: {
        backgroundColor: Colors.primary,
        height: 48,
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 6,
    },
    saveBtnText: { color: Colors.white, fontSize: 15, fontWeight: '800' },
    bmHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingTop: 54,
        paddingBottom: 18,
        paddingHorizontal: 16,
    },
    bmCloseBtn: {
        width: 38,
        height: 38,
        borderRadius: 12,
        backgroundColor: 'rgba(255,255,255,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    bmHeaderTitle: { fontSize: 20, fontWeight: '800', color: Colors.white },
    bmTabs: {
        flexDirection: 'row',
        margin: 16,
        backgroundColor: Colors.surfaceAlt,
        borderRadius: 14,
        padding: 4,
    },
    bmTabBtn: { flex: 1, paddingVertical: 10, borderRadius: 11, alignItems: 'center' },
    bmTabActive: { backgroundColor: Colors.primary },
    bmTabText: { fontSize: 13, fontWeight: '700', color: Colors.textSecondary },
    emptyBm: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
    emptyBmTitle: { fontSize: 17, fontWeight: '700', color: Colors.text, marginTop: 10 },
    emptyBmSub: { fontSize: 13, color: Colors.textSecondary, textAlign: 'center', marginTop: 6 },
    bmCard: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        backgroundColor: Colors.surface,
        borderRadius: 16,
        padding: 14,
        ...Shadows.card,
    },
    bmTag: { fontSize: 11, fontWeight: '800', color: Colors.primary, marginBottom: 4 },
    bmText: { fontSize: 14, fontWeight: '600', color: Colors.text, lineHeight: 20 },
});