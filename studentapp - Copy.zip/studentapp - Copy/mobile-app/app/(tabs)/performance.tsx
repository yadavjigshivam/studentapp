import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    ActivityIndicator,
    RefreshControl,
    Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import { api, getApiErrorMessage } from '../../src/services/api';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

interface DailyPoint {
    date: string;
    studyMinutes: number;
    studySeconds: number;
    questionsAttempted: number;
    questionsCorrect: number;
    accuracy: number;
}

interface SubjectStat {
    subjectId: string;
    subjectName: string;
    studyTimeSeconds: number;
    questionsAttempted: number;
    questionsCorrect: number;
    completionPercentage: number;
    accuracyPercentage: number | null;
    strengthLabel: 'strong' | 'moderate' | 'weak' | 'insufficient_data';
}

interface AnalyticsPayload {
    periodDays: number;
    dailyTimeline: DailyPoint[];
    subjects: SubjectStat[];
}

interface WeakAreasPayload {
    weakSubjects: Array<{
        subjectId: string;
        subjectName: string;
        attemptedQuestions: number;
        correctQuestions: number;
        accuracyPercentage: number;
    }>;
    strongSubjects: Array<{
        subjectId: string;
        subjectName: string;
        attemptedQuestions: number;
        accuracyPercentage: number;
    }>;
    weakTopics: Array<{
        topicId: string;
        topicName: string;
        subjectName: string;
        attemptedQuestions: number;
        accuracyPercentage: number;
    }>;
    strongTopics: Array<{
        topicId: string;
        topicName: string;
        subjectName: string;
        attemptedQuestions: number;
        accuracyPercentage: number;
    }>;
    insufficientDataAreas: Array<{
        subjectId: string;
        subjectName: string;
        attemptedQuestions: number;
        thresholdRequired: number;
        message: string;
    }>;
}

function getStrengthMeta(label: SubjectStat['strengthLabel']): {
    text: string;
    bg: string;
    color: string;
} {
    switch (label) {
        case 'strong':
            return { text: 'Strong', bg: Colors.successLight, color: '#047857' };
        case 'moderate':
            return { text: 'Moderate', bg: Colors.warningLight, color: '#B45309' };
        case 'weak':
            return { text: 'Weak', bg: Colors.dangerLight, color: '#B91C1C' };
        default:
            return { text: 'Need 20+ Qs', bg: Colors.surfaceAlt, color: Colors.textSecondary };
    }
}

function formatDayShort(isoDate: string): string {
    const parts = isoDate.split('-');
    if (parts.length !== 3) return isoDate;
    return `${parts[2]}/${parts[1]}`;
}

export default function PerformanceScreen() {
    const [days, setDays] = useState<7 | 30>(7);
    const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);
    const [weakAreas, setWeakAreas] = useState<WeakAreasPayload | null>(null);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const loadAnalytics = async (period: 7 | 30) => {
        try {
            const [anaRes, weakRes] = await Promise.all([
                api.get(`/progress/analytics?days=${period}`),
                api.get('/progress/weak-areas'),
            ]);
            setAnalytics(anaRes.data.data);
            setWeakAreas(weakRes.data.data);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err, 'Analytics load nahi ho paaya.'));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            loadAnalytics(days);
        }, [days])
    );

    const switchPeriod = (nextDays: 7 | 30) => {
        setDays(nextDays);
        setLoading(true);
        loadAnalytics(nextDays);
    };

    const timeline = analytics?.dailyTimeline || [];
    const chartPoints = days === 30 ? timeline.slice(-14) : timeline;

    const totalMinutes = timeline.reduce((sum, d) => sum + d.studyMinutes, 0);
    const totalQuestions = timeline.reduce((sum, d) => sum + d.questionsAttempted, 0);
    const totalCorrect = timeline.reduce((sum, d) => sum + d.questionsCorrect, 0);
    const overallAccuracy =
        totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;

    const maxStudyMin = Math.max(10, ...chartPoints.map((p) => p.studyMinutes));
    const maxQuestions = Math.max(5, ...chartPoints.map((p) => p.questionsAttempted));

    return (
        <View style={styles.root}>
            {/* Gradient Header */}
            <LinearGradient colors={Gradients.hero} style={styles.header}>
                <Text style={styles.headerTitle}>Performance Analytics</Text>
                <Text style={styles.headerSub}>
                    Real-time accuracy, study trends &amp; weak topic diagnostics
                </Text>

                <View style={styles.periodWrap}>
                    <TouchableOpacity
                        onPress={() => switchPeriod(7)}
                        style={[styles.periodBtn, days === 7 && styles.periodBtnActive]}
                    >
                        <Text style={[styles.periodText, days === 7 && styles.periodTextActive]}>
                            Last 7 Days
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => switchPeriod(30)}
                        style={[styles.periodBtn, days === 30 && styles.periodBtnActive]}
                    >
                        <Text style={[styles.periodText, days === 30 && styles.periodTextActive]}>
                            Last 30 Days
                        </Text>
                    </TouchableOpacity>
                </View>
            </LinearGradient>

            {loading && !analytics ? (
                <View style={styles.center}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                </View>
            ) : (
                <ScrollView
                    contentContainerStyle={styles.body}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={() => {
                                setRefreshing(true);
                                loadAnalytics(days);
                            }}
                        />
                    }
                >
                    {/* Period Summary Tiles */}
                    <View style={styles.summaryRow}>
                        <LinearGradient colors={Gradients.study} style={styles.summaryTile}>
                            <Ionicons name="time" size={20} color={Colors.white} />
                            <Text style={styles.tileVal}>
                                {totalMinutes >= 60
                                    ? `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}m`
                                    : `${totalMinutes}m`}
                            </Text>
                            <Text style={styles.tileLbl}>Study Time</Text>
                        </LinearGradient>

                        <LinearGradient colors={Gradients.practice} style={styles.summaryTile}>
                            <Ionicons name="checkmark-done-circle" size={20} color={Colors.white} />
                            <Text style={styles.tileVal}>{totalQuestions}</Text>
                            <Text style={styles.tileLbl}>Questions</Text>
                        </LinearGradient>

                        <LinearGradient colors={Gradients.focus} style={styles.summaryTile}>
                            <Ionicons name="analytics" size={20} color={Colors.white} />
                            <Text style={styles.tileVal}>{overallAccuracy}%</Text>
                            <Text style={styles.tileLbl}>Accuracy</Text>
                        </LinearGradient>
                    </View>

                    {/* Daily Study Time Bar Chart */}
                    <View style={styles.card}>
                        <View style={styles.cardHead}>
                            <Text style={styles.cardTitle}>Daily Study Time (Minutes)</Text>
                            <Text style={styles.cardHint}>
                                {days === 30 ? 'Last 14 days shown' : '7-day trend'}
                            </Text>
                        </View>
                        <View style={styles.chartArea}>
                            {chartPoints.map((pt) => {
                                const heightPct = Math.max(6, Math.round((pt.studyMinutes / maxStudyMin) * 100));
                                return (
                                    <View key={pt.date} style={styles.barCol}>
                                        <Text style={styles.barTopVal}>
                                            {pt.studyMinutes > 0 ? pt.studyMinutes : ''}
                                        </Text>
                                        <View style={styles.barTrack}>
                                            <LinearGradient
                                                colors={Gradients.study}
                                                style={[
                                                    styles.barRect,
                                                    { height: `${pt.studyMinutes > 0 ? heightPct : 4}%` },
                                                ]}
                                            />
                                        </View>
                                        <Text style={styles.barDate}>{formatDayShort(pt.date)}</Text>
                                    </View>
                                );
                            })}
                        </View>
                    </View>

                    {/* Daily Questions Practiced Chart */}
                    <View style={styles.card}>
                        <View style={styles.cardHead}>
                            <Text style={styles.cardTitle}>Questions Practiced Per Day</Text>
                            <Text style={styles.cardHint}>{totalCorrect} correct</Text>
                        </View>
                        <View style={styles.chartArea}>
                            {chartPoints.map((pt) => {
                                const heightPct = Math.max(
                                    6,
                                    Math.round((pt.questionsAttempted / maxQuestions) * 100)
                                );
                                return (
                                    <View key={pt.date} style={styles.barCol}>
                                        <Text style={styles.barTopVal}>
                                            {pt.questionsAttempted > 0 ? pt.questionsAttempted : ''}
                                        </Text>
                                        <View style={styles.barTrack}>
                                            <LinearGradient
                                                colors={Gradients.practice}
                                                style={[
                                                    styles.barRect,
                                                    { height: `${pt.questionsAttempted > 0 ? heightPct : 4}%` },
                                                ]}
                                            />
                                        </View>
                                        <Text style={styles.barDate}>{formatDayShort(pt.date)}</Text>
                                    </View>
                                );
                            })}
                        </View>
                    </View>

                    {/* Weak Areas Diagnostic Section */}
                    <View style={styles.card}>
                        <View style={styles.cardHead}>
                            <Text style={styles.cardTitle}>Weak Subject &amp; Topic Diagnosis</Text>
                            <Ionicons name="pulse" size={18} color={Colors.danger} />
                        </View>

                        {weakAreas &&
                            weakAreas.weakSubjects.length === 0 &&
                            weakAreas.weakTopics.length === 0 ? (
                            <View style={styles.goodBox}>
                                <Ionicons name="sparkles" size={22} color={Colors.success} />
                                <Text style={styles.goodText}>
                                    Abhi koi weak area detect nahi hua hai! Subject analysis ke liye 20+ aur topic ke liye 10+ questions practice karein.
                                </Text>
                            </View>
                        ) : (
                            <View style={{ gap: 10 }}>
                                {weakAreas?.weakSubjects.map((ws) => (
                                    <View key={ws.subjectId} style={styles.weakRow}>
                                        <View style={{ flex: 1 }}>
                                            <Text style={styles.weakName}>{ws.subjectName}</Text>
                                            <Text style={styles.weakMeta}>
                                                Subject • {ws.correctQuestions}/{ws.attemptedQuestions} correct
                                            </Text>
                                        </View>
                                        <View style={styles.weakBadge}>
                                            <Text style={styles.weakBadgeText}>{ws.accuracyPercentage}%</Text>
                                        </View>
                                    </View>
                                ))}

                                {weakAreas?.weakTopics.map((wt) => (
                                    <View key={wt.topicId} style={styles.weakRow}>
                                        <View style={{ flex: 1 }}>
                                            <Text style={styles.weakName}>{wt.topicName}</Text>
                                            <Text style={styles.weakMeta}>
                                                {wt.subjectName} • {wt.attemptedQuestions} Qs attempted
                                            </Text>
                                        </View>
                                        <View style={styles.weakBadge}>
                                            <Text style={styles.weakBadgeText}>{wt.accuracyPercentage}%</Text>
                                        </View>
                                    </View>
                                ))}
                            </View>
                        )}

                        {weakAreas && weakAreas.insufficientDataAreas.length > 0 && (
                            <View style={styles.infoBox}>
                                <Text style={styles.infoTitle}>Unlock Full Diagnostics</Text>
                                {weakAreas.insufficientDataAreas.slice(0, 3).map((item) => (
                                    <Text key={item.subjectId} style={styles.infoLine}>
                                        • {item.subjectName}: {item.message}
                                    </Text>
                                ))}
                            </View>
                        )}
                    </View>

                    {/* Subject-wise Breakdown */}
                    <View style={styles.card}>
                        <Text style={styles.cardTitle}>Subject-wise Performance</Text>
                        {!analytics || analytics.subjects.length === 0 ? (
                            <Text style={styles.emptySubText}>
                                Study sessions ya practice questions complete karne ke baad yahan subject-wise progress dikhegi.
                            </Text>
                        ) : (
                            <View style={{ gap: 14, marginTop: 6 }}>
                                {analytics.subjects.map((sub) => {
                                    const badge = getStrengthMeta(sub.strengthLabel);
                                    const barPct = sub.accuracyPercentage ?? sub.completionPercentage;
                                    return (
                                        <View key={sub.subjectId} style={styles.subjectRow}>
                                            <View style={styles.subjectTop}>
                                                <Text style={styles.subjectName} numberOfLines={1}>
                                                    {sub.subjectName}
                                                </Text>
                                                <View style={[styles.strengthPill, { backgroundColor: badge.bg }]}>
                                                    <Text style={[styles.strengthText, { color: badge.color }]}>
                                                        {badge.text}
                                                    </Text>
                                                </View>
                                            </View>
                                            <Text style={styles.subjectMeta}>
                                                {sub.questionsAttempted} Qs •{' '}
                                                {sub.accuracyPercentage !== null
                                                    ? `${sub.accuracyPercentage}% Accuracy`
                                                    : 'Accuracy locked (<20 Qs)'}{' '}
                                                • {Math.round(sub.studyTimeSeconds / 60)}m studied
                                            </Text>
                                            <View style={styles.progressTrack}>
                                                <View
                                                    style={[
                                                        styles.progressFill,
                                                        {
                                                            width: `${Math.min(100, Math.round(barPct))}%`,
                                                            backgroundColor: badge.color,
                                                        },
                                                    ]}
                                                />
                                            </View>
                                        </View>
                                    );
                                })}
                            </View>
                        )}
                    </View>
                </ScrollView>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    header: {
        paddingTop: 56,
        paddingBottom: 18,
        paddingHorizontal: 18,
        borderBottomLeftRadius: 26,
        borderBottomRightRadius: 26,
    },
    headerTitle: { fontSize: 23, fontWeight: '800', color: Colors.white },
    headerSub: { fontSize: 12, color: '#E0E7FF', marginTop: 3 },
    periodWrap: {
        flexDirection: 'row',
        backgroundColor: 'rgba(0,0,0,0.18)',
        borderRadius: 14,
        padding: 4,
        marginTop: 14,
    },
    periodBtn: { flex: 1, paddingVertical: 8, borderRadius: 11, alignItems: 'center' },
    periodBtnActive: { backgroundColor: Colors.white },
    periodText: { fontSize: 13, fontWeight: '700', color: '#E0E7FF' },
    periodTextActive: { color: Colors.primary },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    body: { padding: 16, gap: 16, paddingBottom: 36 },
    summaryRow: { flexDirection: 'row', gap: 10 },
    summaryTile: {
        flex: 1,
        borderRadius: 18,
        paddingVertical: 14,
        paddingHorizontal: 10,
        alignItems: 'center',
        ...Shadows.card,
    },
    tileVal: { fontSize: 18, fontWeight: '800', color: Colors.white, marginTop: 6 },
    tileLbl: { fontSize: 11, color: 'rgba(255,255,255,0.88)', marginTop: 2, fontWeight: '600' },
    card: { backgroundColor: Colors.surface, borderRadius: 20, padding: 16, gap: 12, ...Shadows.card },
    cardHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    cardTitle: { fontSize: 15, fontWeight: '800', color: Colors.text },
    cardHint: { fontSize: 11, fontWeight: '600', color: Colors.textSecondary },
    chartArea: {
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        height: 150,
        paddingTop: 14,
        gap: 4,
    },
    barCol: { flex: 1, alignItems: 'center', height: '100%', justifyContent: 'flex-end' },
    barTopVal: { fontSize: 9, fontWeight: '700', color: Colors.textSecondary, marginBottom: 3 },
    barTrack: {
        width: '72%',
        maxWidth: 26,
        flex: 1,
        backgroundColor: Colors.surfaceAlt,
        borderRadius: 8,
        justifyContent: 'flex-end',
        overflow: 'hidden',
    },
    barRect: { width: '100%', borderRadius: 8 },
    barDate: { fontSize: 9, fontWeight: '600', color: Colors.textMuted, marginTop: 6 },
    goodBox: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        backgroundColor: Colors.successLight,
        padding: 12,
        borderRadius: 14,
    },
    goodText: { flex: 1, fontSize: 12, color: '#065F46', lineHeight: 18, fontWeight: '600' },
    weakRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        backgroundColor: Colors.dangerLight,
        padding: 12,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: '#FECACA',
    },
    weakName: { fontSize: 14, fontWeight: '700', color: '#991B1B' },
    weakMeta: { fontSize: 11, color: '#B91C1C', marginTop: 2 },
    weakBadge: {
        backgroundColor: Colors.danger,
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 10,
    },
    weakBadgeText: { color: Colors.white, fontSize: 12, fontWeight: '800' },
    infoBox: {
        backgroundColor: Colors.primaryLight,
        borderRadius: 12,
        padding: 12,
        gap: 4,
    },
    infoTitle: { fontSize: 12, fontWeight: '800', color: Colors.primary },
    infoLine: { fontSize: 11, color: Colors.textSecondary, lineHeight: 16 },
    emptySubText: { fontSize: 13, color: Colors.textSecondary, lineHeight: 19 },
    subjectRow: { gap: 5 },
    subjectTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
    subjectName: { flex: 1, fontSize: 14, fontWeight: '700', color: Colors.text },
    strengthPill: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 10 },
    strengthText: { fontSize: 10, fontWeight: '800' },
    subjectMeta: { fontSize: 11, color: Colors.textSecondary },
    progressTrack: {
        height: 7,
        backgroundColor: Colors.surfaceAlt,
        borderRadius: 6,
        overflow: 'hidden',
        marginTop: 2,
    },
    progressFill: { height: '100%', borderRadius: 6 },
});