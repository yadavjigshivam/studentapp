import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    ScrollView,
    TouchableOpacity,
    StyleSheet,
    ActivityIndicator,
    RefreshControl,
    Modal,
    Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useRouter } from 'expo-router';
import { api, getApiErrorMessage } from '../../src/services/api';
import { useAuthStore } from '../../src/store/authStore';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

type PracticeType =
    | 'topic_wise'
    | 'chapter_wise'
    | 'subject_wise'
    | 'random_drill'
    | 'incorrect_questions'
    | 'bookmarked_review';

type TestCategoryFilter = 'ALL' | 'FULL_TEST' | 'SHORT_TEST' | 'MINI_TEST' | 'SECTIONAL_TEST';

interface TopicOption {
    id: string;
    name: string;
}

interface ChapterOption {
    id: string;
    name: string;
    topics: TopicOption[];
}

interface SubjectOption {
    id: string;
    name: string;
    chapters: ChapterOption[];
}

interface QuizListItem {
    id: string;
    title: string;
    description: string | null;
    quizType: string;
    totalQuestions: number;
    durationMinutes: number | null;
    marksPerQuestion: number;
    negativeMarksPerQuestion: number;
    difficultyLevel: string | null;
    isTimed: boolean;
    subject: { id: string; name: string } | null;
    examination: { id: string; name: string };
}

interface QuizAttemptSummary {
    attemptId: string;
    attemptNumber: number;
    scoreObtained: number;
    totalMarks: number;
    accuracy: number;
    submittedAt: string | null;
    status: string;
}

const PRACTICE_MODES: Array<{
    key: PracticeType;
    title: string;
    subtitle: string;
    icon: keyof typeof Ionicons.glyphMap;
    colors: readonly [string, string];
}> = [
        {
            key: 'topic_wise',
            title: 'Topic-wise',
            subtitle: 'Master one topic at a time',
            icon: 'layers',
            colors: ['#4F46E5', '#6366F1'],
        },
        {
            key: 'chapter_wise',
            title: 'Chapter-wise',
            subtitle: 'Practice complete chapters',
            icon: 'library',
            colors: ['#0284C7', '#06B6D4'],
        },
        {
            key: 'subject_wise',
            title: 'Subject-wise',
            subtitle: 'Full subject question bank',
            icon: 'book',
            colors: ['#059669', '#10B981'],
        },
        {
            key: 'random_drill',
            title: 'Random Drill',
            subtitle: 'Mixed exam-level questions',
            icon: 'shuffle',
            colors: ['#7C3AED', '#A855F7'],
        },
        {
            key: 'incorrect_questions',
            title: 'Wrong Questions',
            subtitle: 'Fix your past mistakes',
            icon: 'refresh-circle',
            colors: ['#DC2626', '#F97316'],
        },
        {
            key: 'bookmarked_review',
            title: 'Bookmarked',
            subtitle: 'Revise your saved MCQs',
            icon: 'bookmark',
            colors: ['#D97706', '#F59E0B'],
        },
    ];

const QUESTION_COUNTS = [5, 10, 20, 30];

const TEST_FILTERS: Array<{ key: TestCategoryFilter; label: string }> = [
    { key: 'ALL', label: 'All Tests' },
    { key: 'FULL_TEST', label: 'Full Test' },
    { key: 'SHORT_TEST', label: 'Short Test' },
    { key: 'MINI_TEST', label: 'Mini Test' },
    { key: 'SECTIONAL_TEST', label: 'Sectional' },
];

function parseTestMeta(description: string | null, durationMinutes: number | null) {
    const raw = description || '';
    const match = raw.match(/^\[(FULL_TEST|SHORT_TEST|MINI_TEST|SECTIONAL_TEST)\]\s*/);
    let category: Exclude<TestCategoryFilter, 'ALL'> = 'SHORT_TEST';
    const cleanDescription = match ? raw.replace(match[0], '').trim() : raw;

    if (match) {
        category = match[1] as Exclude<TestCategoryFilter, 'ALL'>;
    } else if ((durationMinutes || 0) >= 90) {
        category = 'FULL_TEST';
    } else if ((durationMinutes || 0) <= 20) {
        category = 'MINI_TEST';
    }

    const metaMap: Record<
        Exclude<TestCategoryFilter, 'ALL'>,
        { label: string; bg: string; color: string }
    > = {
        FULL_TEST: { label: 'Full Test', bg: '#EEF2FF', color: '#4338CA' },
        SHORT_TEST: { label: 'Short Test', bg: '#E0F2FE', color: '#0369A1' },
        MINI_TEST: { label: 'Mini Test', bg: '#ECFDF5', color: '#047857' },
        SECTIONAL_TEST: { label: 'Sectional Test', bg: '#F3E8FF', color: '#7E22CE' },
    };

    return { category, cleanDescription, ...metaMap[category] };
}

function formatDuration(mins: number | null): string {
    if (!mins || mins <= 0) return 'Untimed';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    if (h === 0) return `${m} min`;
    if (m === 0) return `${h} hr${h > 1 ? 's' : ''}`;
    return `${h}h ${m}m`;
}

export default function PracticeTabScreen() {
    const user = useAuthStore((s) => s.user);
    const router = useRouter();

    const enrolledExams = user?.enrolledExaminations || [];
    const defaultExamId =
        enrolledExams.find((e) => e.isPrimary)?.examinationId ||
        enrolledExams[0]?.examinationId ||
        '';

    const [selectedExamId, setSelectedExamId] = useState<string>(defaultExamId);
    const [activeTab, setActiveTab] = useState<'tests' | 'practice'>('tests');
    const [testFilter, setTestFilter] = useState<TestCategoryFilter>('ALL');
    const [subjects, setSubjects] = useState<SubjectOption[]>([]);
    const [quizzes, setQuizzes] = useState<QuizListItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    // Practice configuration modal state
    const [configModalVisible, setConfigModalVisible] = useState(false);
    const [selectedMode, setSelectedMode] = useState<PracticeType>('topic_wise');
    const [runnerMode, setRunnerMode] = useState<'test' | 'quiz'>('test');
    const [pickedSubjectId, setPickedSubjectId] = useState<string>('');
    const [pickedChapterId, setPickedChapterId] = useState<string>('');
    const [pickedTopicId, setPickedTopicId] = useState<string>('');
    const [questionCount, setQuestionCount] = useState<number>(10);

    // Quiz attempts modal state
    const [attemptsModalVisible, setAttemptsModalVisible] = useState(false);
    const [attemptsQuizTitle, setAttemptsQuizTitle] = useState('');
    const [attemptsLoading, setAttemptsLoading] = useState(false);
    const [attemptsList, setAttemptsList] = useState<QuizAttemptSummary[]>([]);

    const loadData = async (examId: string) => {
        if (!examId) {
            setLoading(false);
            setRefreshing(false);
            return;
        }
        try {
            const [sylRes, quizRes] = await Promise.all([
                api.get(`/examinations/${examId}/syllabus`),
                api.get(`/quizzes?examinationId=${examId}&limit=50`),
            ]);
            const fetchedSubjects: SubjectOption[] = sylRes.data.data?.subjects || [];
            setSubjects(fetchedSubjects);
            setQuizzes(quizRes.data.data || []);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err, 'Practice data load nahi ho paaya.'));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            const targetId = selectedExamId || defaultExamId;
            if (targetId && targetId !== selectedExamId) {
                setSelectedExamId(targetId);
            }
            loadData(targetId);
        }, [selectedExamId, defaultExamId])
    );

    const openModeConfig = (mode: PracticeType) => {
        setSelectedMode(mode);
        setQuestionCount(10);

        const firstSubj = subjects[0];
        const firstChap = firstSubj?.chapters?.[0];
        const firstTopic = firstChap?.topics?.[0];

        setPickedSubjectId(firstSubj?.id || '');
        setPickedChapterId(firstChap?.id || '');
        setPickedTopicId(firstTopic?.id || '');
        setConfigModalVisible(true);
    };

    const currentSubject = subjects.find((s) => s.id === pickedSubjectId);
    const currentChapters = currentSubject?.chapters || [];
    const currentChapter = currentChapters.find((c) => c.id === pickedChapterId);
    const currentTopics = currentChapter?.topics || [];

    const handleSubjectPick = (subjId: string) => {
        setPickedSubjectId(subjId);
        const subj = subjects.find((s) => s.id === subjId);
        const chap = subj?.chapters?.[0];
        setPickedChapterId(chap?.id || '');
        setPickedTopicId(chap?.topics?.[0]?.id || '');
    };

    const handleChapterPick = (chapId: string) => {
        setPickedChapterId(chapId);
        const chap = currentChapters.find((c) => c.id === chapId);
        setPickedTopicId(chap?.topics?.[0]?.id || '');
    };

    const handleLaunchPractice = () => {
        const modeInfo = PRACTICE_MODES.find((m) => m.key === selectedMode);

        if (selectedMode === 'subject_wise' && !pickedSubjectId) {
            Alert.alert('Select Subject', 'Please select a subject first.');
            return;
        }
        if (selectedMode === 'chapter_wise' && !pickedChapterId) {
            Alert.alert('Select Chapter', 'Please select a chapter first.');
            return;
        }
        if (selectedMode === 'topic_wise' && !pickedTopicId) {
            Alert.alert('Select Topic', 'Please select a topic first.');
            return;
        }

        setConfigModalVisible(false);
        router.push({
            pathname: '/practice-runner',
            params: {
                mode: runnerMode,
                practiceType: selectedMode,
                examinationId:
                    selectedMode === 'incorrect_questions' || selectedMode === 'bookmarked_review'
                        ? ''
                        : selectedExamId || defaultExamId,
                subjectId:
                    selectedMode === 'subject_wise' ||
                        selectedMode === 'chapter_wise' ||
                        selectedMode === 'topic_wise'
                        ? pickedSubjectId
                        : '',
                chapterId:
                    selectedMode === 'chapter_wise' || selectedMode === 'topic_wise'
                        ? pickedChapterId
                        : '',
                topicId: selectedMode === 'topic_wise' ? pickedTopicId : '',
                questionCount: String(questionCount),
                title:
                    selectedMode === 'topic_wise'
                        ? currentTopics.find((t) => t.id === pickedTopicId)?.name || 'Topic Practice'
                        : selectedMode === 'chapter_wise'
                            ? currentChapter?.name || 'Chapter Practice'
                            : selectedMode === 'subject_wise'
                                ? currentSubject?.name || 'Subject Practice'
                                : modeInfo?.title || 'Practice',
            },
        });
    };

    const openQuizHistory = async (quiz: QuizListItem) => {
        setAttemptsQuizTitle(quiz.title);
        setAttemptsModalVisible(true);
        setAttemptsLoading(true);
        setAttemptsList([]);
        try {
            const res = await api.get(`/quizzes/${quiz.id}/attempts`);
            setAttemptsList(res.data.data || []);
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setAttemptsLoading(false);
        }
    };

    const filteredQuizzes = quizzes.filter((qz) => {
        if (testFilter === 'ALL') return true;
        return parseTestMeta(qz.description, qz.durationMinutes).category === testFilter;
    });

    const needsSubject =
        selectedMode === 'subject_wise' ||
        selectedMode === 'chapter_wise' ||
        selectedMode === 'topic_wise';
    const needsChapter = selectedMode === 'chapter_wise' || selectedMode === 'topic_wise';
    const needsTopic = selectedMode === 'topic_wise';

    return (
        <View style={styles.root}>
            {/* Colourful Header */}
            <LinearGradient colors={Gradients.practice} style={styles.header}>
                <Text style={styles.headerTitle}>Test Series &amp; Quick Quiz</Text>
                <Text style={styles.headerSub}>
                    Full Tests, Mini Tests (Submit par Result) &amp; Instant Quizzes
                </Text>

                {/* Exam Switcher */}
                {enrolledExams.length > 0 && (
                    <ScrollView
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={styles.examChipsRow}
                    >
                        {enrolledExams.map((ex) => {
                            const active = ex.examinationId === (selectedExamId || defaultExamId);
                            return (
                                <TouchableOpacity
                                    key={ex.examinationId}
                                    onPress={() => {
                                        setSelectedExamId(ex.examinationId);
                                        setLoading(true);
                                        loadData(ex.examinationId);
                                    }}
                                    style={[styles.examChip, active && styles.examChipActive]}
                                >
                                    <Text style={[styles.examChipText, active && styles.examChipTextActive]}>
                                        {ex.name}
                                    </Text>
                                </TouchableOpacity>
                            );
                        })}
                    </ScrollView>
                )}

                {/* Segment Switcher: Test Series vs Practice/Quiz */}
                <View style={styles.segmentWrap}>
                    <TouchableOpacity
                        onPress={() => setActiveTab('tests')}
                        style={[styles.segmentBtn, activeTab === 'tests' && styles.segmentBtnActive]}
                    >
                        <Text style={[styles.segmentText, activeTab === 'tests' && styles.segmentTextActive]}>
                            Test Series ({quizzes.length})
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={() => setActiveTab('practice')}
                        style={[styles.segmentBtn, activeTab === 'practice' && styles.segmentBtnActive]}
                    >
                        <Text
                            style={[styles.segmentText, activeTab === 'practice' && styles.segmentTextActive]}
                        >
                            Topic Practice / Quiz
                        </Text>
                    </TouchableOpacity>
                </View>
            </LinearGradient>

            {loading ? (
                <View style={styles.center}>
                    <ActivityIndicator size="large" color={Colors.success} />
                </View>
            ) : (
                <ScrollView
                    contentContainerStyle={styles.body}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={() => {
                                setRefreshing(true);
                                loadData(selectedExamId || defaultExamId);
                            }}
                        />
                    }
                >
                    {activeTab === 'tests' ? (
                        <View style={{ gap: 14 }}>
                            {/* Test Category Filters */}
                            <ScrollView
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                contentContainerStyle={{ gap: 8 }}
                            >
                                {TEST_FILTERS.map((f) => {
                                    const active = testFilter === f.key;
                                    return (
                                        <TouchableOpacity
                                            key={f.key}
                                            onPress={() => setTestFilter(f.key)}
                                            style={[styles.filterPill, active && styles.filterPillActive]}
                                        >
                                            <Text
                                                style={[styles.filterPillText, active && styles.filterPillTextActive]}
                                            >
                                                {f.label}
                                            </Text>
                                        </TouchableOpacity>
                                    );
                                })}
                            </ScrollView>

                            {filteredQuizzes.length === 0 ? (
                                <View style={styles.emptyBox}>
                                    <Ionicons name="clipboard-outline" size={48} color={Colors.textMuted} />
                                    <Text style={styles.emptyTitle}>No Tests Available Here</Text>
                                    <Text style={styles.emptySub}>
                                        Admin Panel ke Test Series section se is exam ke liye Full Test (2 hrs), Short Test ya Mini Test publish karein.
                                    </Text>
                                </View>
                            ) : (
                                filteredQuizzes.map((qz) => {
                                    const meta = parseTestMeta(qz.description, qz.durationMinutes);
                                    return (
                                        <View key={qz.id} style={styles.quizCard}>
                                            <View style={styles.quizHeader}>
                                                <View style={[styles.quizBadge, { backgroundColor: meta.bg }]}>
                                                    <Text style={[styles.quizBadgeText, { color: meta.color }]}>
                                                        {meta.label}
                                                    </Text>
                                                </View>
                                                {qz.subject && (
                                                    <Text style={styles.subjectTag}>{qz.subject.name}</Text>
                                                )}
                                            </View>

                                            <Text style={styles.quizTitle}>{qz.title}</Text>
                                            {meta.cleanDescription.length > 0 && (
                                                <Text style={styles.quizDesc} numberOfLines={2}>
                                                    {meta.cleanDescription}
                                                </Text>
                                            )}

                                            <View style={styles.quizMetaRow}>
                                                <View style={styles.metaPill}>
                                                    <Ionicons name="help-circle-outline" size={14} color={Colors.primary} />
                                                    <Text style={styles.metaPillText}>{qz.totalQuestions} Qs</Text>
                                                </View>
                                                <View style={styles.metaPill}>
                                                    <Ionicons name="time-outline" size={14} color={Colors.secondary} />
                                                    <Text style={styles.metaPillText}>
                                                        {formatDuration(qz.durationMinutes)}
                                                    </Text>
                                                </View>
                                                <View style={styles.metaPill}>
                                                    <Ionicons name="ribbon-outline" size={14} color={Colors.success} />
                                                    <Text style={styles.metaPillText}>
                                                        +{qz.marksPerQuestion} / -{qz.negativeMarksPerQuestion}
                                                    </Text>
                                                </View>
                                            </View>

                                            <View style={styles.quizActionRow}>
                                                <TouchableOpacity
                                                    onPress={() => openQuizHistory(qz)}
                                                    style={styles.historyBtn}
                                                >
                                                    <Ionicons
                                                        name="stats-chart-outline"
                                                        size={15}
                                                        color={Colors.textSecondary}
                                                    />
                                                    <Text style={styles.historyBtnText}>Past Attempts</Text>
                                                </TouchableOpacity>

                                                <TouchableOpacity
                                                    onPress={() =>
                                                        router.push({
                                                            pathname: '/quiz-runner',
                                                            params: { quizId: qz.id, title: qz.title },
                                                        })
                                                    }
                                                    style={styles.startQuizBtn}
                                                >
                                                    <Text style={styles.startQuizText}>Start Test</Text>
                                                    <Ionicons name="arrow-forward" size={16} color={Colors.white} />
                                                </TouchableOpacity>
                                            </View>
                                        </View>
                                    );
                                })
                            )}
                        </View>
                    ) : (
                        <View style={styles.grid}>
                            {PRACTICE_MODES.map((mode) => (
                                <TouchableOpacity
                                    key={mode.key}
                                    activeOpacity={0.88}
                                    onPress={() => openModeConfig(mode.key)}
                                    style={styles.modeCardWrap}
                                >
                                    <LinearGradient colors={mode.colors} style={styles.modeCard}>
                                        <View style={styles.modeIconCircle}>
                                            <Ionicons name={mode.icon} size={24} color={Colors.white} />
                                        </View>
                                        <Text style={styles.modeTitle}>{mode.title}</Text>
                                        <Text style={styles.modeSub}>{mode.subtitle}</Text>
                                        <View style={styles.modeStartRow}>
                                            <Text style={styles.modeStartText}>Start →</Text>
                                        </View>
                                    </LinearGradient>
                                </TouchableOpacity>
                            ))}
                        </View>
                    )}
                </ScrollView>
            )}

            {/* Practice Configuration Modal */}
            <Modal
                visible={configModalVisible}
                transparent
                animationType="slide"
                onRequestClose={() => setConfigModalVisible(false)}
            >
                <View style={styles.sheetOverlay}>
                    <View style={styles.sheetBox}>
                        <View style={styles.sheetHeader}>
                            <Text style={styles.sheetTitle}>
                                Configure {PRACTICE_MODES.find((m) => m.key === selectedMode)?.title}
                            </Text>
                            <TouchableOpacity onPress={() => setConfigModalVisible(false)}>
                                <Ionicons name="close" size={24} color={Colors.textSecondary} />
                            </TouchableOpacity>
                        </View>

                        <ScrollView style={{ maxHeight: 440 }} contentContainerStyle={{ gap: 14 }}>
                            {/* Mode Choice: Test Mode vs Quick Quiz Mode */}
                            <View>
                                <Text style={styles.fieldLabel}>Choose Mode</Text>
                                <View style={styles.modeChoiceRow}>
                                    <TouchableOpacity
                                        onPress={() => setRunnerMode('test')}
                                        style={[
                                            styles.modeChoiceCard,
                                            runnerMode === 'test' && styles.modeChoiceActive,
                                        ]}
                                    >
                                        <Ionicons
                                            name="document-text"
                                            size={18}
                                            color={runnerMode === 'test' ? Colors.primary : Colors.textSecondary}
                                        />
                                        <Text
                                            style={[
                                                styles.modeChoiceTitle,
                                                runnerMode === 'test' && { color: Colors.primary },
                                            ]}
                                        >
                                            Test Mode
                                        </Text>
                                        <Text style={styles.modeChoiceSub}>
                                            Submit ke baad poora result &amp; solutions
                                        </Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        onPress={() => setRunnerMode('quiz')}
                                        style={[
                                            styles.modeChoiceCard,
                                            runnerMode === 'quiz' && styles.modeChoiceActive,
                                        ]}
                                    >
                                        <Ionicons
                                            name="flash"
                                            size={18}
                                            color={runnerMode === 'quiz' ? Colors.success : Colors.textSecondary}
                                        />
                                        <Text
                                            style={[
                                                styles.modeChoiceTitle,
                                                runnerMode === 'quiz' && { color: Colors.success },
                                            ]}
                                        >
                                            Quick Quiz
                                        </Text>
                                        <Text style={styles.modeChoiceSub}>
                                            Har question par turant sahi/galat
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            </View>

                            {needsSubject && (
                                <View>
                                    <Text style={styles.fieldLabel}>Select Subject</Text>
                                    <View style={styles.chipWrap}>
                                        {subjects.length === 0 ? (
                                            <Text style={styles.helperText}>No subjects found in this exam.</Text>
                                        ) : (
                                            subjects.map((s) => (
                                                <TouchableOpacity
                                                    key={s.id}
                                                    onPress={() => handleSubjectPick(s.id)}
                                                    style={[
                                                        styles.pickChip,
                                                        pickedSubjectId === s.id && styles.pickChipActive,
                                                    ]}
                                                >
                                                    <Text
                                                        style={[
                                                            styles.pickChipText,
                                                            pickedSubjectId === s.id && styles.pickChipTextActive,
                                                        ]}
                                                    >
                                                        {s.name}
                                                    </Text>
                                                </TouchableOpacity>
                                            ))
                                        )}
                                    </View>
                                </View>
                            )}

                            {needsChapter && (
                                <View>
                                    <Text style={styles.fieldLabel}>Select Chapter</Text>
                                    <View style={styles.chipWrap}>
                                        {currentChapters.length === 0 ? (
                                            <Text style={styles.helperText}>No chapters available for this subject.</Text>
                                        ) : (
                                            currentChapters.map((c) => (
                                                <TouchableOpacity
                                                    key={c.id}
                                                    onPress={() => handleChapterPick(c.id)}
                                                    style={[
                                                        styles.pickChip,
                                                        pickedChapterId === c.id && styles.pickChipActive,
                                                    ]}
                                                >
                                                    <Text
                                                        style={[
                                                            styles.pickChipText,
                                                            pickedChapterId === c.id && styles.pickChipTextActive,
                                                        ]}
                                                    >
                                                        {c.name}
                                                    </Text>
                                                </TouchableOpacity>
                                            ))
                                        )}
                                    </View>
                                </View>
                            )}

                            {needsTopic && (
                                <View>
                                    <Text style={styles.fieldLabel}>Select Topic</Text>
                                    <View style={styles.chipWrap}>
                                        {currentTopics.length === 0 ? (
                                            <Text style={styles.helperText}>No topics available for this chapter.</Text>
                                        ) : (
                                            currentTopics.map((t) => (
                                                <TouchableOpacity
                                                    key={t.id}
                                                    onPress={() => setPickedTopicId(t.id)}
                                                    style={[
                                                        styles.pickChip,
                                                        pickedTopicId === t.id && styles.pickChipActive,
                                                    ]}
                                                >
                                                    <Text
                                                        style={[
                                                            styles.pickChipText,
                                                            pickedTopicId === t.id && styles.pickChipTextActive,
                                                        ]}
                                                    >
                                                        {t.name}
                                                    </Text>
                                                </TouchableOpacity>
                                            ))
                                        )}
                                    </View>
                                </View>
                            )}

                            <View>
                                <Text style={styles.fieldLabel}>Number of Questions</Text>
                                <View style={styles.countRow}>
                                    {QUESTION_COUNTS.map((cnt) => (
                                        <TouchableOpacity
                                            key={cnt}
                                            onPress={() => setQuestionCount(cnt)}
                                            style={[
                                                styles.countBtn,
                                                questionCount === cnt && styles.countBtnActive,
                                            ]}
                                        >
                                            <Text
                                                style={[
                                                    styles.countBtnText,
                                                    questionCount === cnt && styles.countBtnTextActive,
                                                ]}
                                            >
                                                {cnt} Qs
                                            </Text>
                                        </TouchableOpacity>
                                    ))}
                                </View>
                            </View>
                        </ScrollView>

                        <TouchableOpacity onPress={handleLaunchPractice} style={styles.launchBtnWrap}>
                            <LinearGradient
                                colors={runnerMode === 'test' ? Gradients.hero : Gradients.practice}
                                style={styles.launchBtn}
                            >
                                <Text style={styles.launchBtnText}>
                                    {runnerMode === 'test' ? 'Start Test Mode' : 'Start Quick Quiz'}
                                </Text>
                            </LinearGradient>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* Past Attempts Modal */}
            <Modal
                visible={attemptsModalVisible}
                transparent
                animationType="slide"
                onRequestClose={() => setAttemptsModalVisible(false)}
            >
                <View style={styles.sheetOverlay}>
                    <View style={styles.sheetBox}>
                        <View style={styles.sheetHeader}>
                            <Text style={styles.sheetTitle} numberOfLines={1}>
                                Attempts: {attemptsQuizTitle}
                            </Text>
                            <TouchableOpacity onPress={() => setAttemptsModalVisible(false)}>
                                <Ionicons name="close" size={24} color={Colors.textSecondary} />
                            </TouchableOpacity>
                        </View>

                        {attemptsLoading ? (
                            <ActivityIndicator style={{ marginVertical: 28 }} color={Colors.primary} />
                        ) : attemptsList.length === 0 ? (
                            <Text style={styles.emptyAttemptText}>
                                Aapne abhi tak ye test attempt nahi kiya hai.
                            </Text>
                        ) : (
                            <ScrollView style={{ maxHeight: 320 }} contentContainerStyle={{ gap: 10 }}>
                                {attemptsList.map((att) => (
                                    <View key={att.attemptId} style={styles.attemptRow}>
                                        <View>
                                            <Text style={styles.attemptNum}>Attempt #{att.attemptNumber}</Text>
                                            <Text style={styles.attemptDate}>
                                                {att.submittedAt
                                                    ? new Date(att.submittedAt).toLocaleString()
                                                    : 'In Progress'}
                                            </Text>
                                        </View>
                                        <View style={{ alignItems: 'flex-end' }}>
                                            <Text style={styles.attemptScore}>
                                                {att.scoreObtained} / {att.totalMarks}
                                            </Text>
                                            <Text style={styles.attemptAcc}>{att.accuracy}% Acc</Text>
                                        </View>
                                    </View>
                                ))}
                            </ScrollView>
                        )}
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    header: {
        paddingTop: 56,
        paddingBottom: 18,
        paddingHorizontal: 18,
        borderBottomLeftRadius: 26,
        borderBottomRightRadius: 26,
    },
    headerTitle: { fontSize: 22, fontWeight: '800', color: Colors.white },
    headerSub: { fontSize: 12, color: '#D1FAE5', marginTop: 3 },
    examChipsRow: { gap: 8, paddingTop: 14 },
    examChip: {
        paddingHorizontal: 14,
        paddingVertical: 6,
        borderRadius: 20,
        backgroundColor: 'rgba(255,255,255,0.2)',
    },
    examChipActive: { backgroundColor: Colors.white },
    examChipText: { color: Colors.white, fontSize: 12, fontWeight: '700' },
    examChipTextActive: { color: '#047857' },
    segmentWrap: {
        flexDirection: 'row',
        backgroundColor: 'rgba(0,0,0,0.18)',
        borderRadius: 14,
        padding: 4,
        marginTop: 14,
    },
    segmentBtn: { flex: 1, paddingVertical: 8, borderRadius: 11, alignItems: 'center' },
    segmentBtnActive: { backgroundColor: Colors.white },
    segmentText: { fontSize: 13, fontWeight: '700', color: '#ECFDF5' },
    segmentTextActive: { color: '#047857' },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    body: { padding: 16, paddingBottom: 32 },
    filterPill: {
        paddingHorizontal: 14,
        paddingVertical: 7,
        borderRadius: 20,
        backgroundColor: Colors.surface,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    filterPillActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
    filterPillText: { fontSize: 12, fontWeight: '700', color: Colors.textSecondary },
    filterPillTextActive: { color: Colors.white },
    grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
    modeCardWrap: { width: '48%', borderRadius: 20, overflow: 'hidden', ...Shadows.card },
    modeCard: { padding: 16, minHeight: 152, justifyContent: 'space-between' },
    modeIconCircle: {
        width: 44,
        height: 44,
        borderRadius: 14,
        backgroundColor: 'rgba(255,255,255,0.22)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    modeTitle: { fontSize: 16, fontWeight: '800', color: Colors.white, marginTop: 10 },
    modeSub: { fontSize: 11, color: 'rgba(255,255,255,0.88)', marginTop: 3 },
    modeStartRow: { marginTop: 10 },
    modeStartText: { fontSize: 12, fontWeight: '800', color: '#FEF08A' },
    emptyBox: { alignItems: 'center', padding: 36 },
    emptyTitle: { fontSize: 17, fontWeight: '700', color: Colors.text, marginTop: 12 },
    emptySub: {
        fontSize: 13,
        color: Colors.textSecondary,
        textAlign: 'center',
        marginTop: 6,
        lineHeight: 20,
    },
    quizCard: {
        backgroundColor: Colors.surface,
        borderRadius: 20,
        padding: 16,
        gap: 10,
        ...Shadows.card,
    },
    quizHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    quizBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
    quizBadgeText: { fontSize: 11, fontWeight: '800' },
    subjectTag: { fontSize: 11, fontWeight: '700', color: Colors.textSecondary },
    quizTitle: { fontSize: 17, fontWeight: '800', color: Colors.text },
    quizDesc: { fontSize: 13, color: Colors.textSecondary, lineHeight: 19 },
    quizMetaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    metaPill: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: Colors.surfaceAlt,
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 10,
    },
    metaPillText: { fontSize: 12, fontWeight: '600', color: Colors.text },
    quizActionRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 10,
        paddingTop: 8,
        borderTopWidth: 1,
        borderTopColor: Colors.border,
    },
    historyBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        paddingVertical: 8,
        paddingHorizontal: 10,
    },
    historyBtnText: { fontSize: 13, fontWeight: '700', color: Colors.textSecondary },
    startQuizBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: Colors.primary,
        paddingHorizontal: 18,
        paddingVertical: 10,
        borderRadius: 12,
    },
    startQuizText: { color: Colors.white, fontSize: 13, fontWeight: '800' },
    sheetOverlay: {
        flex: 1,
        backgroundColor: 'rgba(15,23,42,0.55)',
        justifyContent: 'flex-end',
    },
    sheetBox: {
        backgroundColor: Colors.surface,
        borderTopLeftRadius: 26,
        borderTopRightRadius: 26,
        padding: 20,
        paddingBottom: 28,
        gap: 14,
    },
    sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    sheetTitle: { fontSize: 18, fontWeight: '800', color: Colors.text, flex: 1 },
    fieldLabel: { fontSize: 13, fontWeight: '700', color: Colors.text, marginBottom: 8 },
    modeChoiceRow: { flexDirection: 'row', gap: 10 },
    modeChoiceCard: {
        flex: 1,
        padding: 12,
        borderRadius: 14,
        borderWidth: 2,
        borderColor: Colors.border,
        backgroundColor: Colors.surfaceAlt,
        gap: 4,
    },
    modeChoiceActive: { borderColor: Colors.primary, backgroundColor: Colors.primaryLight },
    modeChoiceTitle: { fontSize: 14, fontWeight: '800', color: Colors.text },
    modeChoiceSub: { fontSize: 11, color: Colors.textSecondary, lineHeight: 15 },
    helperText: { fontSize: 12, color: Colors.textMuted, fontStyle: 'italic' },
    chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    pickChip: {
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 12,
        backgroundColor: Colors.surfaceAlt,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    pickChipActive: { backgroundColor: Colors.primaryLight, borderColor: Colors.primary },
    pickChipText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
    pickChipTextActive: { color: Colors.primary, fontWeight: '700' },
    countRow: { flexDirection: 'row', gap: 8 },
    countBtn: {
        flex: 1,
        paddingVertical: 10,
        borderRadius: 12,
        backgroundColor: Colors.surfaceAlt,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.border,
    },
    countBtnActive: { backgroundColor: Colors.success, borderColor: Colors.success },
    countBtnText: { fontSize: 13, fontWeight: '700', color: Colors.text },
    countBtnTextActive: { color: Colors.white },
    launchBtnWrap: { borderRadius: 14, overflow: 'hidden', marginTop: 4 },
    launchBtn: { height: 50, alignItems: 'center', justifyContent: 'center' },
    launchBtnText: { color: Colors.white, fontSize: 15, fontWeight: '800' },
    emptyAttemptText: {
        textAlign: 'center',
        color: Colors.textSecondary,
        paddingVertical: 24,
        fontSize: 14,
    },
    attemptRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: Colors.surfaceAlt,
        padding: 14,
        borderRadius: 14,
    },
    attemptNum: { fontSize: 14, fontWeight: '800', color: Colors.text },
    attemptDate: { fontSize: 11, color: Colors.textSecondary, marginTop: 2 },
    attemptScore: { fontSize: 16, fontWeight: '800', color: Colors.primary },
    attemptAcc: { fontSize: 11, fontWeight: '700', color: Colors.success, marginTop: 2 },
});