import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    ActivityIndicator,
    Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { api, getApiErrorMessage } from '../../src/services/api';
import { useAuthStore } from '../../src/store/authStore';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

interface ExamCatalogItem {
    id: string;
    name: string;
    slug: string;
    description: string | null;
    category: string | null;
    subjectsCount: number;
}

export default function SelectExamScreen() {
    const [exams, setExams] = useState<ExamCatalogItem[]>([]);
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const [primaryId, setPrimaryId] = useState<string>('');
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const { user, refreshProfile } = useAuthStore();
    const router = useRouter();

    useEffect(() => {
        const load = async () => {
            try {
                const res = await api.get('/examinations?limit=50');
                setExams(res.data.data || []);

                const enrolled = user?.enrolledExaminations || [];
                if (enrolled.length > 0) {
                    setSelectedIds(enrolled.map((e) => e.examinationId));
                    const prim = enrolled.find((e) => e.isPrimary);
                    setPrimaryId(prim?.examinationId || enrolled[0].examinationId);
                }
            } catch (err) {
                Alert.alert('Error', getApiErrorMessage(err));
            } finally {
                setLoading(false);
            }
        };
        load();
    }, []);

    const toggleExam = (id: string) => {
        setSelectedIds((prev) => {
            if (prev.includes(id)) {
                const next = prev.filter((item) => item !== id);
                if (primaryId === id) setPrimaryId(next[0] || '');
                return next;
            }
            if (!primaryId) setPrimaryId(id);
            return [...prev, id];
        });
    };

    const handleSave = async () => {
        if (selectedIds.length === 0) {
            Alert.alert('Select Examination', 'Kam se kam ek target exam select karein.');
            return;
        }
        setSaving(true);
        try {
            const effectivePrimary = primaryId || selectedIds[0];
            for (const examId of selectedIds) {
                await api.post('/users/me/examinations', {
                    examinationId: examId,
                    isPrimary: examId === effectivePrimary,
                });
            }
            await api.put(`/users/me/examinations/${effectivePrimary}/primary`);
            await refreshProfile();
            router.replace('/(tabs)/home');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setSaving(false);
        }
    };

    return (
        <View style={styles.root}>
            <LinearGradient colors={Gradients.hero} style={styles.header}>
                <Text style={styles.title}>Choose Your Target Exams</Text>
                <Text style={styles.subtitle}>
                    Aap ek se zyada exams select kar sakte hain. Star wala exam aapka Primary Dashboard exam hoga.
                </Text>
            </LinearGradient>

            {loading ? (
                <View style={styles.center}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                </View>
            ) : (
                <ScrollView contentContainerStyle={styles.list}>
                    {exams.map((exam) => {
                        const isSelected = selectedIds.includes(exam.id);
                        const isPrimary = primaryId === exam.id;
                        return (
                            <TouchableOpacity
                                key={exam.id}
                                activeOpacity={0.8}
                                onPress={() => toggleExam(exam.id)}
                                style={[styles.examCard, isSelected && styles.examCardActive]}
                            >
                                <View style={styles.examTop}>
                                    <View style={styles.badge}>
                                        <Text style={styles.badgeText}>{exam.category || 'Exam'}</Text>
                                    </View>
                                    {isSelected && (
                                        <TouchableOpacity
                                            onPress={() => setPrimaryId(exam.id)}
                                            style={[styles.primaryChip, isPrimary && styles.primaryChipActive]}
                                        >
                                            <Ionicons
                                                name={isPrimary ? 'star' : 'star-outline'}
                                                size={14}
                                                color={isPrimary ? Colors.white : Colors.warning}
                                            />
                                            <Text
                                                style={[
                                                    styles.primaryChipText,
                                                    isPrimary && { color: Colors.white },
                                                ]}
                                            >
                                                {isPrimary ? 'Primary' : 'Set Primary'}
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                </View>

                                <Text style={styles.examName}>{exam.name}</Text>
                                {exam.description && (
                                    <Text style={styles.examDesc} numberOfLines={2}>
                                        {exam.description}
                                    </Text>
                                )}

                                <View style={styles.examMeta}>
                                    <Text style={styles.metaText}>{exam.subjectsCount} Subjects</Text>
                                    <Ionicons
                                        name={isSelected ? 'checkmark-circle' : 'ellipse-outline'}
                                        size={24}
                                        color={isSelected ? Colors.primary : Colors.textMuted}
                                    />
                                </View>
                            </TouchableOpacity>
                        );
                    })}
                </ScrollView>
            )}

            <View style={styles.bottomBar}>
                <TouchableOpacity
                    activeOpacity={0.85}
                    disabled={saving || selectedIds.length === 0}
                    onPress={handleSave}
                    style={[styles.saveBtnWrap, selectedIds.length === 0 && { opacity: 0.5 }]}
                >
                    <LinearGradient colors={Gradients.hero} style={styles.saveBtn}>
                        {saving ? (
                            <ActivityIndicator color={Colors.white} />
                        ) : (
                            <Text style={styles.saveBtnText}>
                                Continue ({selectedIds.length} Selected)
                            </Text>
                        )}
                    </LinearGradient>
                </TouchableOpacity>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    header: {
        paddingTop: 60,
        paddingBottom: 28,
        paddingHorizontal: 22,
        borderBottomLeftRadius: 28,
        borderBottomRightRadius: 28,
    },
    title: { fontSize: 24, fontWeight: '800', color: Colors.white },
    subtitle: { fontSize: 13, color: '#E0E7FF', marginTop: 6, lineHeight: 19 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    list: { padding: 18, paddingBottom: 100, gap: 14 },
    examCard: {
        backgroundColor: Colors.surface,
        borderRadius: 18,
        padding: 16,
        borderWidth: 2,
        borderColor: Colors.border,
        ...Shadows.card,
    },
    examCardActive: {
        borderColor: Colors.primary,
        backgroundColor: '#F5F7FF',
    },
    examTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
    badge: { backgroundColor: Colors.primaryLight, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
    badgeText: { fontSize: 11, fontWeight: '700', color: Colors.primary, textTransform: 'uppercase' },
    primaryChip: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 20,
        backgroundColor: Colors.warningLight,
    },
    primaryChipActive: { backgroundColor: Colors.warning },
    primaryChipText: { fontSize: 11, fontWeight: '700', color: '#B45309' },
    examName: { fontSize: 18, fontWeight: '700', color: Colors.text },
    examDesc: { fontSize: 13, color: Colors.textSecondary, marginTop: 4, lineHeight: 18 },
    examMeta: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 12,
        paddingTop: 10,
        borderTopWidth: 1,
        borderTopColor: Colors.border,
    },
    metaText: { fontSize: 12, fontWeight: '600', color: Colors.textSecondary },
    bottomBar: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        padding: 16,
        backgroundColor: Colors.surface,
        borderTopWidth: 1,
        borderTopColor: Colors.border,
    },
    saveBtnWrap: { borderRadius: 14, overflow: 'hidden', ...Shadows.button },
    saveBtn: { height: 50, alignItems: 'center', justifyContent: 'center' },
    saveBtnText: { color: Colors.white, fontSize: 15, fontWeight: '700' },
});