import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    KeyboardAvoidingView,
    Platform,
    ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Link, useRouter } from 'expo-router';
import { useAuthStore } from '../../src/store/authStore';
import { getApiErrorMessage } from '../../src/services/api';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

export default function RegisterScreen() {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const register = useAuthStore((s) => s.register);
    const router = useRouter();

    const handleRegister = async () => {
        if (!firstName.trim() || !email.trim() || !password) {
            setError('First name, email and password are required.');
            return;
        }
        if (password !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }

        setError(null);
        setLoading(true);
        try {
            await register({
                firstName: firstName.trim(),
                lastName: lastName.trim() || undefined,
                email: email.trim(),
                phone: phone.trim() || undefined,
                password,
                confirmPassword,
            });
            router.replace('/(auth)/select-exam');
        } catch (err) {
            setError(getApiErrorMessage(err, 'Registration failed.'));
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.root}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
                <LinearGradient colors={Gradients.study} style={styles.header}>
                    <Text style={styles.title}>Create Student Account</Text>
                    <Text style={styles.subtitle}>
                        Track your daily study hours, targets &amp; weak topics
                    </Text>
                </LinearGradient>

                <View style={styles.card}>
                    {error && (
                        <View style={styles.errorBox}>
                            <Ionicons name="alert-circle" size={18} color={Colors.danger} />
                            <Text style={styles.errorText}>{error}</Text>
                        </View>
                    )}

                    <View style={styles.row2}>
                        <View style={styles.col}>
                            <Text style={styles.label}>First Name *</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="Anurag"
                                value={firstName}
                                onChangeText={setFirstName}
                            />
                        </View>
                        <View style={styles.col}>
                            <Text style={styles.label}>Last Name</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="Yadav"
                                value={lastName}
                                onChangeText={setLastName}
                            />
                        </View>
                    </View>

                    <Text style={styles.label}>Email Address *</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="you@example.com"
                        autoCapitalize="none"
                        keyboardType="email-address"
                        value={email}
                        onChangeText={setEmail}
                    />

                    <Text style={styles.label}>Phone Number (Optional)</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="+919876543210"
                        keyboardType="phone-pad"
                        value={phone}
                        onChangeText={setPhone}
                    />

                    <Text style={styles.label}>Password *</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Min 8 chars, A-Z, a-z, 0-9, @#$"
                        secureTextEntry
                        value={password}
                        onChangeText={setPassword}
                    />

                    <Text style={styles.label}>Confirm Password *</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Re-enter password"
                        secureTextEntry
                        value={confirmPassword}
                        onChangeText={setConfirmPassword}
                    />

                    <TouchableOpacity
                        activeOpacity={0.85}
                        disabled={loading}
                        onPress={handleRegister}
                        style={styles.btnWrap}
                    >
                        <LinearGradient colors={Gradients.study} style={styles.btn}>
                            {loading ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <Text style={styles.btnText}>Create Account &amp; Select Exam</Text>
                            )}
                        </LinearGradient>
                    </TouchableOpacity>

                    <View style={styles.footerRow}>
                        <Text style={styles.footerText}>Already have an account? </Text>
                        <Link href="/(auth)/login" asChild>
                            <TouchableOpacity>
                                <Text style={styles.footerLink}>Sign In</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    scroll: { flexGrow: 1 },
    header: {
        paddingTop: 64,
        paddingBottom: 48,
        paddingHorizontal: 24,
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
    },
    title: { fontSize: 25, fontWeight: '800', color: Colors.white },
    subtitle: { fontSize: 13, color: '#E0F2FE', marginTop: 6 },
    card: {
        backgroundColor: Colors.surface,
        marginHorizontal: 20,
        marginTop: -24,
        marginBottom: 32,
        borderRadius: 24,
        padding: 22,
        ...Shadows.card,
    },
    row2: { flexDirection: 'row', gap: 10 },
    col: { flex: 1 },
    errorBox: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        backgroundColor: Colors.dangerLight,
        padding: 12,
        borderRadius: 12,
        marginBottom: 12,
    },
    errorText: { flex: 1, color: Colors.danger, fontSize: 13, fontWeight: '500' },
    label: { fontSize: 12, fontWeight: '600', color: Colors.text, marginTop: 12, marginBottom: 6 },
    input: {
        backgroundColor: Colors.surfaceAlt,
        borderWidth: 1,
        borderColor: Colors.border,
        borderRadius: 12,
        paddingHorizontal: 14,
        height: 46,
        fontSize: 14,
        color: Colors.text,
    },
    btnWrap: { marginTop: 22, borderRadius: 14, overflow: 'hidden', ...Shadows.button },
    btn: { height: 50, alignItems: 'center', justifyContent: 'center' },
    btnText: { color: Colors.white, fontSize: 15, fontWeight: '700' },
    footerRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 18 },
    footerText: { fontSize: 14, color: Colors.textSecondary },
    footerLink: { fontSize: 14, fontWeight: '700', color: Colors.primary },
});