import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    ActivityIndicator,
    Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Link } from 'expo-router';
import { useAuthStore } from '../../src/store/authStore';
import { api, getApiErrorMessage } from '../../src/services/api';
import { Colors, Gradients, Shadows } from '../../src/theme/colors';

export default function LoginScreen() {
    const [email, setEmail] = useState('student@studyapp.com');
    const [password, setPassword] = useState('Student@2026');
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const login = useAuthStore((s) => s.login);

    const handleLogin = async () => {
        if (!email.trim() || !password) {
            setError('Please enter both email and password.');
            return;
        }
        setError(null);
        setLoading(true);
        try {
            await login(email, password);
        } catch (err) {
            setError(getApiErrorMessage(err, 'Invalid email or password.'));
        } finally {
            setLoading(false);
        }
    };

    const handleForgotPassword = async () => {
        if (!email.trim()) {
            Alert.alert('Enter Email', 'Pehle apna registered email upar box mein likhein.');
            return;
        }
        try {
            const res = await api.post('/auth/forgot-password', { email: email.trim().toLowerCase() });
            const devToken = res.data?.data?.devResetToken;
            Alert.alert(
                'Reset Request Sent',
                devToken
                    ? `Password reset link sent.\n(Dev Token: ${devToken.slice(0, 12)}...)`
                    : 'Agar ye email registered hai, toh password reset instructions bhej di gayi hain.'
            );
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.root}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
                <LinearGradient colors={Gradients.hero} style={styles.header}>
                    <View style={styles.logoCircle}>
                        <Ionicons name="school" size={38} color={Colors.primary} />
                    </View>
                    <Text style={styles.brandTitle}>ExamPro Study</Text>
                    <Text style={styles.brandSub}>
                        Smart syllabus, daily targets &amp; distraction-free practice
                    </Text>
                </LinearGradient>

                <View style={styles.card}>
                    <Text style={styles.cardTitle}>Welcome Back!</Text>
                    <Text style={styles.cardSubtitle}>Sign in to continue your preparation</Text>

                    {error && (
                        <View style={styles.errorBox}>
                            <Ionicons name="alert-circle" size={18} color={Colors.danger} />
                            <Text style={styles.errorText}>{error}</Text>
                        </View>
                    )}

                    <Text style={styles.label}>Email Address</Text>
                    <View style={styles.inputRow}>
                        <Ionicons name="mail-outline" size={20} color={Colors.textMuted} />
                        <TextInput
                            style={styles.input}
                            placeholder="student@example.com"
                            placeholderTextColor={Colors.textMuted}
                            autoCapitalize="none"
                            keyboardType="email-address"
                            value={email}
                            onChangeText={setEmail}
                        />
                    </View>

                    <Text style={styles.label}>Password</Text>
                    <View style={styles.inputRow}>
                        <Ionicons name="lock-closed-outline" size={20} color={Colors.textMuted} />
                        <TextInput
                            style={styles.input}
                            placeholder="Enter your password"
                            placeholderTextColor={Colors.textMuted}
                            secureTextEntry={!showPassword}
                            value={password}
                            onChangeText={setPassword}
                        />
                        <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                            <Ionicons
                                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                                size={20}
                                color={Colors.textMuted}
                            />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity onPress={handleForgotPassword} style={styles.forgotBtn}>
                        <Text style={styles.forgotText}>Forgot Password?</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        activeOpacity={0.85}
                        disabled={loading}
                        onPress={handleLogin}
                        style={styles.primaryBtnWrap}
                    >
                        <LinearGradient colors={Gradients.hero} style={styles.primaryBtn}>
                            {loading ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <Text style={styles.primaryBtnText}>Sign In</Text>
                            )}
                        </LinearGradient>
                    </TouchableOpacity>

                    <View style={styles.footerRow}>
                        <Text style={styles.footerText}>New student? </Text>
                        <Link href="/(auth)/register" asChild>
                            <TouchableOpacity>
                                <Text style={styles.footerLink}>Create Free Account</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    scroll: { flexGrow: 1 },
    header: {
        paddingTop: 72,
        paddingBottom: 56,
        paddingHorizontal: 24,
        alignItems: 'center',
        borderBottomLeftRadius: 32,
        borderBottomRightRadius: 32,
    },
    logoCircle: {
        width: 72,
        height: 72,
        borderRadius: 24,
        backgroundColor: Colors.white,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 14,
        ...Shadows.card,
    },
    brandTitle: { fontSize: 28, fontWeight: '800', color: Colors.white, letterSpacing: 0.3 },
    brandSub: {
        fontSize: 13,
        color: '#E0E7FF',
        marginTop: 6,
        textAlign: 'center',
    },
    card: {
        backgroundColor: Colors.surface,
        marginHorizontal: 20,
        marginTop: -28,
        marginBottom: 32,
        borderRadius: 24,
        padding: 24,
        ...Shadows.card,
    },
    cardTitle: { fontSize: 22, fontWeight: '700', color: Colors.text },
    cardSubtitle: { fontSize: 13, color: Colors.textSecondary, marginTop: 4, marginBottom: 20 },
    errorBox: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        backgroundColor: Colors.dangerLight,
        borderColor: '#FECACA',
        borderWidth: 1,
        padding: 12,
        borderRadius: 12,
        marginBottom: 16,
    },
    errorText: { flex: 1, fontSize: 13, color: Colors.danger, fontWeight: '500' },
    label: {
        fontSize: 13,
        fontWeight: '600',
        color: Colors.text,
        marginBottom: 6,
        marginTop: 10,
    },
    inputRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        backgroundColor: Colors.surfaceAlt,
        borderRadius: 14,
        paddingHorizontal: 14,
        height: 50,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    input: { flex: 1, fontSize: 15, color: Colors.text },
    forgotBtn: { alignSelf: 'flex-end', marginTop: 10, marginBottom: 18 },
    forgotText: { fontSize: 13, fontWeight: '600', color: Colors.primary },
    primaryBtnWrap: { borderRadius: 14, overflow: 'hidden', ...Shadows.button },
    primaryBtn: { height: 52, alignItems: 'center', justifyContent: 'center' },
    primaryBtnText: { color: Colors.white, fontSize: 16, fontWeight: '700' },
    footerRow: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: 22,
    },
    footerText: { fontSize: 14, color: Colors.textSecondary },
    footerLink: { fontSize: 14, fontWeight: '700', color: Colors.primary },
});