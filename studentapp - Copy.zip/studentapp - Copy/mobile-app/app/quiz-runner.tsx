import React, { useEffect, useRef, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    ActivityIndicator,
    Alert,
    Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { api, createIdempotencyKey, getApiErrorMessage } from '../src/services/api';
import { Colors, Gradients, Shadows } from '../src/theme/colors';

interface QuizOption {
    id: string;
    optionTextEn: string;
    optionTextHi: string | null;
    optionImageUrl: string | null;
}

interface QuizQuestionItem {
    id: string;
    displayOrder: number;
    questionTextEn: string;
    questionTextHi: string | null;
    questionImageUrl: string | null;
    options: QuizOption[];
}

interface QuizStartData {
    attemptId: string;
    quizId: string;
    title: string;
    attemptNumber: number;
    totalQuestions: number;
    durationMinutes: number | null;
    marksPerQuestion: number;
    negativeMarksPerQuestion: number;
    questions: QuizQuestionItem[];
}

interface QuizReviewItem {
    questionId: string;
    selectedOptionId: string | null;
    correctOptionId: string | null;
    isCorrect: boolean;
    marksAwarded: number;
    explanationEn: string | null;
    explanationHi: string | null;
}

interface QuizSubmitResult {
    attemptId: string;
    attemptNumber: number;
    totalQuestions: number;
    attemptedQuestions: number;
    correctAnswers: number;
    incorrectAnswers: number;
    unattemptedQuestions: number;
    scoreObtained: number;
    totalMarks: number;
    accuracyPercentage: number;
    totalTimeSeconds: number;
    resultsReview: QuizReviewItem[];
}

type ReviewFilter = 'all' | 'correct' | 'incorrect' | 'skipped';

function formatTimerClock(secs: number): string {
    const safe = Math.max(0, secs);
    const h = Math.floor(safe / 3600);
    const m = Math.floor((safe % 3600) / 60);
    const s = safe % 60;
    if (h > 0) {
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default function QuizRunnerScreen() {
    const params = useLocalSearchParams();
    const router = useRouter();
    const quizId = Array.isArray(params.quizId) ? params.quizId[0] : params.quizId;

    const [quizData, setQuizData] = useState<QuizStartData | null>(null);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [answersMap, setAnswersMap] = useState<Record<string, string | null>>({});
    const [markedMap, setMarkedMap] = useState<Record<string, boolean>>({});
    const [lang, setLang] = useState<'en' | 'hi'>('en');
    const [reviewFilter, setReviewFilter] = useState<ReviewFilter>('all');
    const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [result, setResult] = useState<QuizSubmitResult | null>(null);

    const startedAtMsRef = useRef<number>(Date.now());
    const questionStartMsRef = useRef<number>(Date.now());
    const questionTimeMapRef = useRef<Record<string, number>>({});
    const submittedRef = useRef<boolean>(false);

    useEffect(() => {
        const startQuiz = async () => {
            if (!quizId) {
                router.back();
                return;
            }
            try {
                const res = await api.post(
                    `/quizzes/${quizId}/start`,
                    {},
                    { headers: { 'Idempotency-Key': createIdempotencyKey() } }
                );
                const payload: QuizStartData = res.data.data;
                setQuizData(payload);
                startedAtMsRef.current = Date.now();
                questionStartMsRef.current = Date.now();
                if (payload.durationMinutes && payload.durationMinutes > 0) {
                    setSecondsLeft(payload.durationMinutes * 60);
                }
            } catch (err) {
                Alert.alert('Error', getApiErrorMessage(err, 'Test start nahi ho paaya.'), [
                    { text: 'OK', onPress: () => router.back() },
                ]);
            } finally {
                setLoading(false);
            }
        };
        startQuiz();
    }, [quizId]);

    const recordQuestionTime = () => {
        if (!quizData) return;
        const curr = quizData.questions[currentIndex];
        if (!curr) return;
        const delta = Math.max(1, Math.round((Date.now() - questionStartMsRef.current) / 1000));
        questionTimeMapRef.current[curr.id] = (questionTimeMapRef.current[curr.id] || 0) + delta;
        questionStartMsRef.current = Date.now();
    };

    const goToQuestion = (nextIdx: number) => {
        recordQuestionTime();
        setCurrentIndex(nextIdx);
    };

    const submitQuiz = async () => {
        if (!quizData || submittedRef.current) return;
        recordQuestionTime();
        submittedRef.current = true;
        setSubmitting(true);
        try {
            const totalTimeSeconds = Math.max(
                1,
                Math.round((Date.now() - startedAtMsRef.current) / 1000)
            );
            const answers = quizData.questions.map((q) => ({
                questionId: q.id,
                selectedOptionId: answersMap[q.id] || null,
                timeTakenSeconds: questionTimeMapRef.current[q.id] || 0,
            }));

            const res = await api.post(
                `/quizzes/${quizData.quizId}/attempts/${quizData.attemptId}/submit`,
                { totalTimeSeconds, answers },
                { headers: { 'Idempotency-Key': createIdempotencyKey() } }
            );
            setResult(res.data.data);
        } catch (err) {
            submittedRef.current = false;
            Alert.alert('Submit Failed', getApiErrorMessage(err));
        } finally {
            setSubmitting(false);
        }
    };

    // Countdown Timer with Auto-Submit at 0
    useEffect(() => {
        if (secondsLeft === null || result) return;
        if (secondsLeft <= 0) {
            submitQuiz();
            return;
        }
        const id = setInterval(() => {
            setSecondsLeft((prev) => (prev !== null ? Math.max(0, prev - 1) : null));
        }, 1000);
        return () => clearInterval(id);
    }, [secondsLeft, result]);

    const confirmSubmit = () => {
        if (!quizData) return;
        const answeredCount = quizData.questions.filter((item) => Boolean(answersMap[item.id])).length;
        const markedCount = quizData.questions.filter((item) => Boolean(markedMap[item.id])).length;
        const unattemptedCount = quizData.totalQuestions - answeredCount;

        Alert.alert(
            'Final Submit Test?',
            `Answered: ${answeredCount}\nUnanswered: ${unattemptedCount}\nMarked for Review: ${markedCount}\n\nSubmit karne par aapka poora Testbook-style Result & Solution Report banega.`,
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Submit Now', onPress: submitQuiz },
            ]
        );
    };

    if (loading || !quizData) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color={Colors.primary} />
                <Text style={styles.loadingText}>Starting test session...</Text>
            </View>
        );
    }

    // Testbook-Style Final Result & Solution Analysis Screen
    if (result) {
        const reviewMap = new Map(result.resultsReview.map((r) => [r.questionId, r]));
        const scorePct =
            result.totalMarks > 0
                ? Math.max(0, Math.round((result.scoreObtained / result.totalMarks) * 100))
                : 0;
        const avgSecPerQ =
            result.attemptedQuestions > 0
                ? Math.round(result.totalTimeSeconds / result.attemptedQuestions)
                : 0;
        const positiveMarks = Number((result.correctAnswers * quizData.marksPerQuestion).toFixed(2));
        const negativeDeducted = Number(
            (result.incorrectAnswers * quizData.negativeMarksPerQuestion).toFixed(2)
        );

        const filteredQuestions = quizData.questions.filter((item) => {
            const rev = reviewMap.get(item.id);
            if (reviewFilter === 'correct') return Boolean(rev?.isCorrect);
            if (reviewFilter === 'incorrect') return Boolean(rev?.selectedOptionId && !rev.isCorrect);
            if (reviewFilter === 'skipped') return !rev?.selectedOptionId;
            return true;
        });

        return (
            <View style={styles.root}>
                <LinearGradient colors={Gradients.hero} style={styles.resHeader}>
                    <View style={styles.resTopRow}>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.resTitle} numberOfLines={1}>
                                {quizData.title}
                            </Text>
                            <Text style={styles.resSub}>Attempt #{result.attemptNumber} • Complete Analysis</Text>
                        </View>
                        <TouchableOpacity
                            onPress={() => setLang(lang === 'en' ? 'hi' : 'en')}
                            style={styles.langPill}
                        >
                            <Text style={styles.langPillText}>{lang === 'en' ? 'EN → हिं' : 'हिं → EN'}</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.scoreHero}>
                        <Text style={styles.scoreBig}>
                            {result.scoreObtained} / {result.totalMarks}
                        </Text>
                        <Text style={styles.scoreMeta}>
                            Score: {scorePct}% • Accuracy: {result.accuracyPercentage}% • Time:{' '}
                            {formatTimerClock(result.totalTimeSeconds)}
                        </Text>
                        <Text style={styles.scoreSubMeta}>
                            +{positiveMarks} Positive • -{negativeDeducted} Negative • Avg {avgSecPerQ}s / Q
                        </Text>
                    </View>

                    <View style={styles.resStatsRow}>
                        <View style={styles.resPill}>
                            <Text style={[styles.resPillNum, { color: '#86EFAC' }]}>{result.correctAnswers}</Text>
                            <Text style={styles.resPillLbl}>Correct</Text>
                        </View>
                        <View style={styles.resPill}>
                            <Text style={[styles.resPillNum, { color: '#FCA5A5' }]}>
                                {result.incorrectAnswers}
                            </Text>
                            <Text style={styles.resPillLbl}>Wrong</Text>
                        </View>
                        <View style={styles.resPill}>
                            <Text style={[styles.resPillNum, { color: '#E2E8F0' }]}>
                                {result.unattemptedQuestions}
                            </Text>
                            <Text style={styles.resPillLbl}>Skipped</Text>
                        </View>
                    </View>
                </LinearGradient>

                <ScrollView contentContainerStyle={styles.reviewList}>
                    {/* Breakdown Bar */}
                    <View style={styles.breakdownCard}>
                        <Text style={styles.breakdownTitle}>Question Breakdown</Text>
                        <View style={styles.breakdownTrack}>
                            {result.correctAnswers > 0 && (
                                <View
                                    style={{
                                        flex: result.correctAnswers,
                                        backgroundColor: Colors.success,
                                    }}
                                />
                            )}
                            {result.incorrectAnswers > 0 && (
                                <View
                                    style={{
                                        flex: result.incorrectAnswers,
                                        backgroundColor: Colors.danger,
                                    }}
                                />
                            )}
                            {result.unattemptedQuestions > 0 && (
                                <View
                                    style={{
                                        flex: result.unattemptedQuestions,
                                        backgroundColor: Colors.textMuted,
                                    }}
                                />
                            )}
                        </View>
                    </View>

                    {/* Solution Filter Chips */}
                    <View style={styles.filterRow}>
                        {(
                            [
                                { k: 'all', l: `All (${result.totalQuestions})` },
                                { k: 'correct', l: `Correct (${result.correctAnswers})` },
                                { k: 'incorrect', l: `Wrong (${result.incorrectAnswers})` },
                                { k: 'skipped', l: `Skipped (${result.unattemptedQuestions})` },
                            ] as const
                        ).map((tab) => (
                            <TouchableOpacity
                                key={tab.k}
                                onPress={() => setReviewFilter(tab.k)}
                                style={[styles.revFilterBtn, reviewFilter === tab.k && styles.revFilterActive]}
                            >
                                <Text
                                    style={[
                                        styles.revFilterText,
                                        reviewFilter === tab.k && { color: Colors.white },
                                    ]}
                                >
                                    {tab.l}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>

                    {filteredQuestions.map((q) => {
                        const qNum = quizData.questions.findIndex((item) => item.id === q.id) + 1;
                        const rev = reviewMap.get(q.id);
                        const selectedOpt = q.options.find((o) => o.id === rev?.selectedOptionId);
                        const correctOpt = q.options.find((o) => o.id === rev?.correctOptionId);

                        return (
                            <View key={q.id} style={styles.reviewCard}>
                                <View style={styles.reviewTop}>
                                    <Text style={styles.reviewQNum}>Q{qNum}</Text>
                                    <Text
                                        style={[
                                            styles.reviewStatus,
                                            {
                                                color: !rev?.selectedOptionId
                                                    ? Colors.textSecondary
                                                    : rev.isCorrect
                                                        ? Colors.success
                                                        : Colors.danger,
                                            },
                                        ]}
                                    >
                                        {!rev?.selectedOptionId
                                            ? 'Skipped (0)'
                                            : rev.isCorrect
                                                ? `Correct (+${rev.marksAwarded})`
                                                : `Wrong (${rev.marksAwarded})`}
                                    </Text>
                                </View>

                                <Text style={styles.reviewQText}>
                                    {lang === 'hi' ? q.questionTextHi || q.questionTextEn : q.questionTextEn}
                                </Text>

                                {selectedOpt && (
                                    <Text
                                        style={[
                                            styles.reviewAnsLine,
                                            { color: rev?.isCorrect ? '#047857' : '#B91C1C' },
                                        ]}
                                    >
                                        Your Answer:{' '}
                                        {lang === 'hi'
                                            ? selectedOpt.optionTextHi || selectedOpt.optionTextEn
                                            : selectedOpt.optionTextEn}
                                    </Text>
                                )}

                                {correctOpt && (
                                    <Text style={[styles.reviewAnsLine, { color: '#047857', fontWeight: '700' }]}>
                                        Correct Answer:{' '}
                                        {lang === 'hi'
                                            ? correctOpt.optionTextHi || correctOpt.optionTextEn
                                            : correctOpt.optionTextEn}
                                    </Text>
                                )}

                                {(rev?.explanationEn || rev?.explanationHi) && (
                                    <View style={styles.expMini}>
                                        <Text style={styles.expMiniTitle}>Solution / Explanation</Text>
                                        <Text style={styles.expMiniText}>
                                            {lang === 'hi'
                                                ? rev.explanationHi || rev.explanationEn
                                                : rev.explanationEn || rev.explanationHi}
                                        </Text>
                                    </View>
                                )}
                            </View>
                        );
                    })}

                    <TouchableOpacity onPress={() => router.back()} style={styles.exitReviewBtn}>
                        <Text style={styles.exitReviewText}>Done &amp; Return to Test Series</Text>
                    </TouchableOpacity>
                </ScrollView>
            </View>
        );
    }

    const q = quizData.questions[currentIndex];
    const selectedId = answersMap[q.id] || null;
    const isMarked = Boolean(markedMap[q.id]);
    const qText = lang === 'hi' ? q.questionTextHi || q.questionTextEn : q.questionTextEn;

    return (
        <View style={styles.root}>
            {/* Test Top Bar */}
            <LinearGradient colors={Gradients.dark} style={styles.topBar}>
                <TouchableOpacity
                    onPress={() =>
                        Alert.alert('Leave Test?', 'Kya aap bina submit kiye test chhodna chahte hain?', [
                            { text: 'Cancel', style: 'cancel' },
                            { text: 'Leave', style: 'destructive', onPress: () => router.back() },
                        ])
                    }
                    style={styles.iconBtn}
                >
                    <Ionicons name="close" size={22} color={Colors.white} />
                </TouchableOpacity>

                <View style={{ flex: 1 }}>
                    <Text style={styles.topTitle} numberOfLines={1}>
                        {quizData.title}
                    </Text>
                    <Text style={styles.topSub}>
                        Attempt #{quizData.attemptNumber} • +{quizData.marksPerQuestion}/-
                        {quizData.negativeMarksPerQuestion}
                    </Text>
                </View>

                {secondsLeft !== null && (
                    <View
                        style={[
                            styles.timerPill,
                            secondsLeft <= 120 && { backgroundColor: Colors.danger },
                        ]}
                    >
                        <Ionicons name="time" size={14} color={Colors.white} />
                        <Text style={styles.timerText}>{formatTimerClock(secondsLeft)}</Text>
                    </View>
                )}

                <TouchableOpacity
                    onPress={() => setLang(lang === 'en' ? 'hi' : 'en')}
                    style={styles.langPill}
                >
                    <Text style={styles.langPillText}>{lang === 'en' ? 'EN' : 'हिं'}</Text>
                </TouchableOpacity>
            </LinearGradient>

            {/* Question Number Palette (Testbook Colour Legend) */}
            <View style={styles.paletteBar}>
                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.paletteContent}
                >
                    {quizData.questions.map((item, idx) => {
                        const isCurrent = idx === currentIndex;
                        const isAnswered = Boolean(answersMap[item.id]);
                        const isMark = Boolean(markedMap[item.id]);
                        return (
                            <TouchableOpacity
                                key={item.id}
                                onPress={() => goToQuestion(idx)}
                                style={[
                                    styles.paletteNum,
                                    isAnswered && styles.paletteAnswered,
                                    isMark && styles.paletteMarked,
                                    isCurrent && styles.paletteCurrent,
                                ]}
                            >
                                <Text
                                    style={[
                                        styles.paletteText,
                                        (isAnswered || isMark || isCurrent) && { color: Colors.white },
                                    ]}
                                >
                                    {idx + 1}
                                </Text>
                            </TouchableOpacity>
                        );
                    })}
                </ScrollView>
            </View>

            <ScrollView contentContainerStyle={styles.body}>
                <View style={styles.qCard}>
                    <View style={styles.qHeaderRow}>
                        <Text style={styles.qNum}>
                            Question {currentIndex + 1} of {quizData.totalQuestions}
                        </Text>
                        <TouchableOpacity
                            onPress={() =>
                                setMarkedMap((prev) => ({
                                    ...prev,
                                    [q.id]: !prev[q.id],
                                }))
                            }
                            style={[styles.markBtn, isMarked && styles.markBtnActive]}
                        >
                            <Ionicons
                                name={isMarked ? 'flag' : 'flag-outline'}
                                size={13}
                                color={isMarked ? Colors.white : Colors.secondary}
                            />
                            <Text style={[styles.markBtnText, isMarked && { color: Colors.white }]}>
                                {isMarked ? 'Marked for Review' : 'Mark for Review'}
                            </Text>
                        </TouchableOpacity>
                    </View>

                    <Text style={styles.qText}>{qText}</Text>

                    {q.questionImageUrl && (
                        <Image
                            source={{ uri: q.questionImageUrl }}
                            style={styles.qImage}
                            resizeMode="contain"
                        />
                    )}
                </View>

                <View style={{ gap: 10 }}>
                    {q.options.map((opt, idx) => {
                        const label = String.fromCharCode(65 + idx);
                        const isPicked = selectedId === opt.id;
                        const optText = lang === 'hi' ? opt.optionTextHi || opt.optionTextEn : opt.optionTextEn;

                        return (
                            <TouchableOpacity
                                key={opt.id}
                                activeOpacity={0.8}
                                onPress={() =>
                                    setAnswersMap((prev) => ({
                                        ...prev,
                                        [q.id]: opt.id,
                                    }))
                                }
                                style={[
                                    styles.optionCard,
                                    isPicked && { borderColor: Colors.primary, backgroundColor: Colors.primaryLight },
                                ]}
                            >
                                <View style={[styles.optBadge, isPicked && { backgroundColor: Colors.primary }]}>
                                    <Text style={[styles.optBadgeText, isPicked && { color: Colors.white }]}>
                                        {label}
                                    </Text>
                                </View>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.optText}>{optText}</Text>
                                    {opt.optionImageUrl && (
                                        <Image
                                            source={{ uri: opt.optionImageUrl }}
                                            style={styles.optImage}
                                            resizeMode="contain"
                                        />
                                    )}
                                </View>
                            </TouchableOpacity>
                        );
                    })}
                </View>

                {selectedId && (
                    <TouchableOpacity
                        onPress={() =>
                            setAnswersMap((prev) => ({
                                ...prev,
                                [q.id]: null,
                            }))
                        }
                        style={styles.clearBtn}
                    >
                        <Ionicons name="refresh-outline" size={15} color={Colors.textSecondary} />
                        <Text style={styles.clearBtnText}>Clear Response</Text>
                    </TouchableOpacity>
                )}
            </ScrollView>

            {/* Bottom Bar */}
            <View style={styles.footer}>
                <TouchableOpacity
                    disabled={currentIndex === 0}
                    onPress={() => goToQuestion(Math.max(0, currentIndex - 1))}
                    style={[styles.navBtn, currentIndex === 0 && { opacity: 0.4 }]}
                >
                    <Ionicons name="chevron-back" size={18} color={Colors.text} />
                    <Text style={styles.navBtnText}>Prev</Text>
                </TouchableOpacity>

                {currentIndex < quizData.questions.length - 1 ? (
                    <TouchableOpacity
                        onPress={() => goToQuestion(currentIndex + 1)}
                        style={styles.nextBtn}
                    >
                        <Text style={styles.nextBtnText}>Save &amp; Next →</Text>
                    </TouchableOpacity>
                ) : null}

                <TouchableOpacity
                    disabled={submitting}
                    onPress={confirmSubmit}
                    style={[
                        styles.submitBtn,
                        currentIndex === quizData.questions.length - 1 && { flex: 1 },
                    ]}
                >
                    {submitting ? (
                        <ActivityIndicator color={Colors.white} />
                    ) : (
                        <Text style={styles.submitBtnText}>Submit Test</Text>
                    )}
                </TouchableOpacity>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.bg },
    loadingText: { marginTop: 12, fontSize: 14, color: Colors.textSecondary, fontWeight: '600' },
    topBar: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        paddingTop: 52,
        paddingBottom: 14,
        paddingHorizontal: 14,
    },
    iconBtn: {
        width: 36,
        height: 36,
        borderRadius: 11,
        backgroundColor: 'rgba(255,255,255,0.18)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    topTitle: { fontSize: 15, fontWeight: '800', color: Colors.white },
    topSub: { fontSize: 11, color: '#C7D2FE', marginTop: 2 },
    timerPill: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: 'rgba(255,255,255,0.2)',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 10,
    },
    timerText: {
        color: Colors.white,
        fontSize: 12,
        fontWeight: '800',
        fontVariant: ['tabular-nums'],
    },
    langPill: {
        backgroundColor: 'rgba(255,255,255,0.2)',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 10,
    },
    langPillText: { color: Colors.white, fontSize: 11, fontWeight: '800' },
    paletteBar: { backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border },
    paletteContent: { paddingHorizontal: 14, paddingVertical: 10, gap: 8 },
    paletteNum: {
        width: 34,
        height: 34,
        borderRadius: 10,
        backgroundColor: Colors.surfaceAlt,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: Colors.border,
    },
    paletteAnswered: { backgroundColor: Colors.success, borderColor: Colors.success },
    paletteMarked: { backgroundColor: Colors.secondary, borderColor: Colors.secondary },
    paletteCurrent: { backgroundColor: Colors.primary, borderColor: Colors.primary },
    paletteText: { fontSize: 13, fontWeight: '800', color: Colors.text },
    body: { padding: 16, gap: 14, paddingBottom: 32 },
    qCard: { backgroundColor: Colors.surface, borderRadius: 20, padding: 18, ...Shadows.card },
    qHeaderRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
        gap: 8,
    },
    qNum: { fontSize: 12, fontWeight: '800', color: Colors.primary },
    markBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        paddingHorizontal: 9,
        paddingVertical: 5,
        borderRadius: 8,
        backgroundColor: '#F3E8FF',
    },
    markBtnActive: { backgroundColor: Colors.secondary },
    markBtnText: { fontSize: 11, fontWeight: '700', color: Colors.secondary },
    qText: { fontSize: 16, fontWeight: '700', color: Colors.text, lineHeight: 24 },
    qImage: { width: '100%', height: 180, marginTop: 12, borderRadius: 10 },
    optionCard: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        padding: 14,
        borderRadius: 16,
        borderWidth: 2,
        borderColor: Colors.border,
        backgroundColor: Colors.surface,
    },
    optBadge: {
        width: 32,
        height: 32,
        borderRadius: 10,
        backgroundColor: Colors.surfaceAlt,
        alignItems: 'center',
        justifyContent: 'center',
    },
    optBadgeText: { fontSize: 13, fontWeight: '800', color: Colors.text },
    optText: { fontSize: 14, fontWeight: '600', color: Colors.text, lineHeight: 20 },
    optImage: { width: '100%', height: 110, marginTop: 8, borderRadius: 8 },
    clearBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-end',
        gap: 5,
        paddingVertical: 6,
        paddingHorizontal: 10,
    },
    clearBtnText: { fontSize: 12, fontWeight: '700', color: Colors.textSecondary },
    footer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        padding: 14,
        backgroundColor: Colors.surface,
        borderTopWidth: 1,
        borderTopColor: Colors.border,
    },
    navBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 3,
        paddingHorizontal: 12,
        height: 46,
        borderRadius: 12,
        backgroundColor: Colors.surfaceAlt,
    },
    navBtnText: { fontSize: 13, fontWeight: '700', color: Colors.text },
    nextBtn: {
        flex: 1,
        height: 46,
        borderRadius: 12,
        backgroundColor: Colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
    },
    nextBtnText: { color: Colors.white, fontSize: 14, fontWeight: '800' },
    submitBtn: {
        paddingHorizontal: 18,
        height: 46,
        borderRadius: 12,
        backgroundColor: Colors.success,
        alignItems: 'center',
        justifyContent: 'center',
    },
    submitBtnText: { color: Colors.white, fontSize: 14, fontWeight: '800' },
    resHeader: {
        paddingTop: 54,
        paddingBottom: 20,
        paddingHorizontal: 18,
        borderBottomLeftRadius: 28,
        borderBottomRightRadius: 28,
    },
    resTopRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    resTitle: { fontSize: 19, fontWeight: '800', color: Colors.white },
    resSub: { fontSize: 12, color: '#E0E7FF', marginTop: 2 },
    scoreHero: {
        marginTop: 14,
        backgroundColor: 'rgba(255,255,255,0.18)',
        borderRadius: 18,
        paddingVertical: 14,
        paddingHorizontal: 18,
        alignItems: 'center',
    },
    scoreBig: { fontSize: 28, fontWeight: '900', color: '#FEF08A' },
    scoreMeta: { fontSize: 12, color: Colors.white, marginTop: 4, fontWeight: '600' },
    scoreSubMeta: { fontSize: 11, color: '#E0E7FF', marginTop: 3 },
    resStatsRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
    resPill: {
        flex: 1,
        backgroundColor: 'rgba(255,255,255,0.16)',
        borderRadius: 14,
        paddingVertical: 10,
        alignItems: 'center',
    },
    resPillNum: { fontSize: 18, fontWeight: '800', color: Colors.white },
    resPillLbl: { fontSize: 11, color: '#E0E7FF', fontWeight: '600' },
    reviewList: { padding: 16, gap: 12, paddingBottom: 36 },
    breakdownCard: {
        backgroundColor: Colors.surface,
        borderRadius: 16,
        padding: 14,
        gap: 8,
        ...Shadows.card,
    },
    breakdownTitle: { fontSize: 13, fontWeight: '800', color: Colors.text },
    breakdownTrack: {
        flexDirection: 'row',
        height: 10,
        borderRadius: 8,
        overflow: 'hidden',
        backgroundColor: Colors.surfaceAlt,
    },
    filterRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
    revFilterBtn: {
        paddingHorizontal: 11,
        paddingVertical: 7,
        borderRadius: 10,
        backgroundColor: Colors.surface,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    revFilterActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
    revFilterText: { fontSize: 11, fontWeight: '700', color: Colors.textSecondary },
    reviewCard: {
        backgroundColor: Colors.surface,
        borderRadius: 16,
        padding: 16,
        gap: 6,
        ...Shadows.card,
    },
    reviewTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    reviewQNum: { fontSize: 13, fontWeight: '800', color: Colors.primary },
    reviewStatus: { fontSize: 12, fontWeight: '800' },
    reviewQText: { fontSize: 14, fontWeight: '700', color: Colors.text, lineHeight: 21 },
    reviewAnsLine: { fontSize: 12, color: Colors.textSecondary },
    expMini: { backgroundColor: Colors.surfaceAlt, padding: 10, borderRadius: 10, marginTop: 4 },
    expMiniTitle: { fontSize: 11, fontWeight: '800', color: Colors.primary, marginBottom: 2 },
    expMiniText: { fontSize: 12, color: Colors.text, lineHeight: 18 },
    exitReviewBtn: {
        marginTop: 10,
        backgroundColor: Colors.primary,
        paddingVertical: 14,
        borderRadius: 14,
        alignItems: 'center',
    },
    exitReviewText: { color: Colors.white, fontSize: 15, fontWeight: '800' },
});