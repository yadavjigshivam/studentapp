import React, { useEffect, useRef, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    ActivityIndicator,
    Alert,
    Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { api, createIdempotencyKey, getApiErrorMessage } from '../src/services/api';
import { Colors, Gradients, Shadows } from '../src/theme/colors';

interface QuestionOption {
    id: string;
    optionTextEn: string;
    optionTextHi: string | null;
    optionImageUrl: string | null;
    displayOrder: number;
}

interface PracticeQuestion {
    id: string;
    questionTextEn: string;
    questionTextHi: string | null;
    questionImageUrl: string | null;
    difficultyLevel: string;
    marks: number;
    negativeMarks: number;
    options: QuestionOption[];
}

interface EvaluatedAnswer {
    selectedOptionId: string;
    correctOptionId: string | null;
    isCorrect: boolean;
    explanationEn: string | null;
    explanationHi: string | null;
    explanationImageUrl: string | null;
}

interface PracticeResult {
    totalQuestions: number;
    attempted: number;
    correct: number;
    incorrect: number;
    unattempted: number;
    accuracy: number | null;
    totalTimeSeconds: number;
}

type ReviewFilter = 'all' | 'correct' | 'incorrect' | 'skipped';

function unwrap(val?: string | string[]): string | undefined {
    const s = Array.isArray(val) ? val[0] : val;
    return s && s.trim().length > 0 ? s.trim() : undefined;
}

function formatClock(secs: number): string {
    const safe = Math.max(0, secs);
    const h = Math.floor(safe / 3600);
    const m = Math.floor((safe % 3600) / 60);
    const s = safe % 60;
    if (h > 0) {
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default function PracticeRunnerScreen() {
    const params = useLocalSearchParams();
    const router = useRouter();

    const runnerMode: 'test' | 'quiz' = unwrap(params.mode) === 'quiz' ? 'quiz' : 'test';
    const title = unwrap(params.title) || (runnerMode === 'test' ? 'Practice Test' : 'Quick Quiz');
    const practiceType = unwrap(params.practiceType) || 'random_drill';
    const examinationId = unwrap(params.examinationId);
    const subjectId = unwrap(params.subjectId);
    const chapterId = unwrap(params.chapterId);
    const topicId = unwrap(params.topicId);
    const questionCount = Number(unwrap(params.questionCount)) || 10;

    const [sessionId, setSessionId] = useState<string | null>(null);
    const [questions, setQuestions] = useState<PracticeQuestion[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);

    // Selected answers across all questions (used in Test Mode & Quiz Mode)
    const [selectedMap, setSelectedMap] = useState<Record<string, string | null>>({});
    const [markedMap, setMarkedMap] = useState<Record<string, boolean>>({});
    const [evaluatedMap, setEvaluatedMap] = useState<Record<string, EvaluatedAnswer>>({});
    const [bookmarkMap, setBookmarkMap] = useState<Record<string, string>>({});
    const [lang, setLang] = useState<'en' | 'hi'>('en');
    const [reviewFilter, setReviewFilter] = useState<ReviewFilter>('all');

    const [elapsedSeconds, setElapsedSeconds] = useState(0);
    const [loading, setLoading] = useState(true);
    const [loadError, setLoadError] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);
    const [result, setResult] = useState<PracticeResult | null>(null);

    const startedAtMsRef = useRef<number>(Date.now());
    const questionStartMsRef = useRef<number>(Date.now());
    const questionTimeMapRef = useRef<Record<string, number>>({});

    useEffect(() => {
        const startSession = async () => {
            try {
                const res = await api.post(
                    '/practice-sessions',
                    {
                        practiceType,
                        ...(examinationId ? { examinationId } : {}),
                        ...(subjectId ? { subjectId } : {}),
                        ...(chapterId ? { chapterId } : {}),
                        ...(topicId ? { topicId } : {}),
                        questionCount,
                    },
                    { headers: { 'Idempotency-Key': createIdempotencyKey() } }
                );
                const payload = res.data.data;
                setSessionId(payload.sessionId);
                setQuestions(payload.questions || []);
                startedAtMsRef.current = Date.now();
                questionStartMsRef.current = Date.now();
            } catch (err) {
                setLoadError(getApiErrorMessage(err, 'No questions available for this selection.'));
            } finally {
                setLoading(false);
            }
        };
        startSession();
    }, []);

    // Elapsed timer
    useEffect(() => {
        if (loading || result || questions.length === 0) return;
        const id = setInterval(() => {
            setElapsedSeconds(Math.floor((Date.now() - startedAtMsRef.current) / 1000));
        }, 1000);
        return () => clearInterval(id);
    }, [loading, result, questions.length]);

    const recordCurrentQuestionTime = () => {
        const curr = questions[currentIndex];
        if (!curr) return;
        const spent = Math.max(1, Math.round((Date.now() - questionStartMsRef.current) / 1000));
        questionTimeMapRef.current[curr.id] = (questionTimeMapRef.current[curr.id] || 0) + spent;
        questionStartMsRef.current = Date.now();
    };

    const goToIndex = (nextIdx: number) => {
        recordCurrentQuestionTime();
        setCurrentIndex(nextIdx);
    };

    const currentQuestion = questions[currentIndex];
    const currentSelectedId = currentQuestion ? selectedMap[currentQuestion.id] || null : null;
    const currentEval = currentQuestion ? evaluatedMap[currentQuestion.id] : undefined;

    // Quick Quiz Mode: evaluate single question immediately
    const handleQuizCheckAnswer = async () => {
        if (!sessionId || !currentQuestion || !currentSelectedId || currentEval) return;
        setSubmitting(true);
        try {
            const timeTakenSeconds = Math.max(
                1,
                Math.round((Date.now() - questionStartMsRef.current) / 1000)
            );
            const res = await api.post(
                `/practice-sessions/${sessionId}/answer`,
                {
                    questionId: currentQuestion.id,
                    selectedOptionId: currentSelectedId,
                    timeTakenSeconds,
                },
                { headers: { 'Idempotency-Key': createIdempotencyKey() } }
            );
            const d = res.data.data;
            setEvaluatedMap((prev) => ({
                ...prev,
                [currentQuestion.id]: {
                    selectedOptionId: d.selectedOptionId,
                    correctOptionId: d.correctOptionId,
                    isCorrect: d.isCorrect,
                    explanationEn: d.explanationEn,
                    explanationHi: d.explanationHi,
                    explanationImageUrl: d.explanationImageUrl,
                },
            }));
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setSubmitting(false);
        }
    };

    // Finalize & Submit (Works for both Test Mode and Quiz Mode)
    const submitAllAndFinish = async () => {
        if (!sessionId) {
            router.back();
            return;
        }
        recordCurrentQuestionTime();
        setSubmitting(true);
        try {
            const nextEvaluated: Record<string, EvaluatedAnswer> = { ...evaluatedMap };

            // In Test Mode, submit all selected (not-yet-evaluated) answers sequentially so server counters stay exact
            for (const q of questions) {
                const picked = selectedMap[q.id];
                if (picked && !nextEvaluated[q.id]) {
                    const timeTakenSeconds = Math.max(1, questionTimeMapRef.current[q.id] || 5);
                    const ansRes = await api.post(
                        `/practice-sessions/${sessionId}/answer`,
                        {
                            questionId: q.id,
                            selectedOptionId: picked,
                            timeTakenSeconds,
                        },
                        { headers: { 'Idempotency-Key': createIdempotencyKey() } }
                    );
                    const d = ansRes.data.data;
                    nextEvaluated[q.id] = {
                        selectedOptionId: d.selectedOptionId,
                        correctOptionId: d.correctOptionId,
                        isCorrect: d.isCorrect,
                        explanationEn: d.explanationEn,
                        explanationHi: d.explanationHi,
                        explanationImageUrl: d.explanationImageUrl,
                    };
                }
            }

            setEvaluatedMap(nextEvaluated);

            const completeRes = await api.post(`/practice-sessions/${sessionId}/complete`);
            const finalData = completeRes.data.data;
            setResult({
                ...finalData,
                totalTimeSeconds: Math.max(
                    finalData.totalTimeSeconds || 0,
                    Math.floor((Date.now() - startedAtMsRef.current) / 1000)
                ),
            });
        } catch (err) {
            Alert.alert('Submit Failed', getApiErrorMessage(err));
        } finally {
            setSubmitting(false);
        }
    };

    const confirmSubmitTest = () => {
        const answeredCount = questions.filter((q) => Boolean(selectedMap[q.id])).length;
        const markedCount = questions.filter((q) => Boolean(markedMap[q.id])).length;
        const unattemptedCount = questions.length - answeredCount;

        Alert.alert(
            'Submit Test?',
            `Answered: ${answeredCount}\nUnanswered: ${unattemptedCount}\nMarked for Review: ${markedCount}\n\nSubmit karne ke baad aapko poora result aur solutions dikhenge.`,
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Submit Test', onPress: submitAllAndFinish },
            ]
        );
    };

    const handleToggleBookmark = async () => {
        if (!currentQuestion) return;
        const existingBookmarkId = bookmarkMap[currentQuestion.id];
        try {
            if (existingBookmarkId) {
                await api.delete(`/bookmarks/${existingBookmarkId}`);
                setBookmarkMap((prev) => {
                    const copy = { ...prev };
                    delete copy[currentQuestion.id];
                    return copy;
                });
            } else {
                const res = await api.post('/bookmarks', {
                    bookmarkType: 'question',
                    questionId: currentQuestion.id,
                });
                setBookmarkMap((prev) => ({
                    ...prev,
                    [currentQuestion.id]: res.data.data.bookmarkId,
                }));
            }
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        }
    };

    if (loading) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color={Colors.primary} />
                <Text style={styles.loadingText}>Preparing questions...</Text>
            </View>
        );
    }

    if (loadError || questions.length === 0) {
        return (
            <View style={styles.center}>
                <Ionicons name="help-buoy-outline" size={52} color={Colors.textMuted} />
                <Text style={styles.errTitle}>No Questions Found</Text>
                <Text style={styles.errSub}>
                    {loadError || 'Is selection ke liye abhi questions available nahi hain.'}
                </Text>
                <TouchableOpacity onPress={() => router.back()} style={styles.backFallbackBtn}>
                    <Text style={styles.backFallbackText}>Go Back</Text>
                </TouchableOpacity>
            </View>
        );
    }

    // Testbook-Style Complete Result & Solution Analysis Screen
    if (result) {
        const avgSecPerQ =
            result.attempted > 0 ? Math.round(result.totalTimeSeconds / result.attempted) : 0;
        const filteredQuestions = questions.filter((q) => {
            const ev = evaluatedMap[q.id];
            if (reviewFilter === 'correct') return Boolean(ev?.isCorrect);
            if (reviewFilter === 'incorrect') return Boolean(ev && !ev.isCorrect);
            if (reviewFilter === 'skipped') return !ev;
            return true;
        });

        return (
            <View style={styles.root}>
                <LinearGradient colors={Gradients.hero} style={styles.resHeader}>
                    <View style={styles.resTopRow}>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.resTitle} numberOfLines={1}>
                                {title}
                            </Text>
                            <Text style={styles.resSub}>
                                {runnerMode === 'test' ? 'Test Analysis Report' : 'Quick Quiz Report'}
                            </Text>
                        </View>
                        <TouchableOpacity
                            onPress={() => setLang(lang === 'en' ? 'hi' : 'en')}
                            style={styles.langPill}
                        >
                            <Text style={styles.langPillText}>{lang === 'en' ? 'EN → हिं' : 'हिं → EN'}</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.scoreHero}>
                        <Text style={styles.scoreBig}>
                            {result.correct} / {result.totalQuestions}
                        </Text>
                        <Text style={styles.scoreMeta}>
                            Accuracy: {result.accuracy !== null ? `${Math.round(result.accuracy)}%` : '0%'} • Time:{' '}
                            {formatClock(result.totalTimeSeconds)} • Avg: {avgSecPerQ}s/Q
                        </Text>
                    </View>

                    <View style={styles.resStatsRow}>
                        <View style={styles.resPill}>
                            <Text style={[styles.resPillNum, { color: '#86EFAC' }]}>{result.correct}</Text>
                            <Text style={styles.resPillLbl}>Correct</Text>
                        </View>
                        <View style={styles.resPill}>
                            <Text style={[styles.resPillNum, { color: '#FCA5A5' }]}>{result.incorrect}</Text>
                            <Text style={styles.resPillLbl}>Wrong</Text>
                        </View>
                        <View style={styles.resPill}>
                            <Text style={[styles.resPillNum, { color: '#E2E8F0' }]}>{result.unattempted}</Text>
                            <Text style={styles.resPillLbl}>Skipped</Text>
                        </View>
                    </View>
                </LinearGradient>

                <ScrollView contentContainerStyle={styles.reviewList}>
                    {/* Filter Tabs */}
                    <View style={styles.filterRow}>
                        {(
                            [
                                { k: 'all', l: `All (${questions.length})` },
                                { k: 'correct', l: `Correct (${result.correct})` },
                                { k: 'incorrect', l: `Wrong (${result.incorrect})` },
                                { k: 'skipped', l: `Skipped (${result.unattempted})` },
                            ] as const
                        ).map((tab) => (
                            <TouchableOpacity
                                key={tab.k}
                                onPress={() => setReviewFilter(tab.k)}
                                style={[styles.revFilterBtn, reviewFilter === tab.k && styles.revFilterActive]}
                            >
                                <Text
                                    style={[
                                        styles.revFilterText,
                                        reviewFilter === tab.k && { color: Colors.white },
                                    ]}
                                >
                                    {tab.l}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </View>

                    {filteredQuestions.map((q) => {
                        const qNum = questions.findIndex((item) => item.id === q.id) + 1;
                        const ev = evaluatedMap[q.id];
                        const selectedOpt = q.options.find((o) => o.id === ev?.selectedOptionId);
                        const correctOpt = q.options.find((o) => o.id === ev?.correctOptionId);

                        return (
                            <View key={q.id} style={styles.reviewCard}>
                                <View style={styles.reviewTop}>
                                    <Text style={styles.reviewQNum}>Q{qNum}</Text>
                                    <Text
                                        style={[
                                            styles.reviewStatus,
                                            {
                                                color: !ev
                                                    ? Colors.textSecondary
                                                    : ev.isCorrect
                                                        ? Colors.success
                                                        : Colors.danger,
                                            },
                                        ]}
                                    >
                                        {!ev ? 'Skipped' : ev.isCorrect ? 'Correct' : 'Incorrect'}
                                    </Text>
                                </View>

                                <Text style={styles.reviewQText}>
                                    {lang === 'hi' ? q.questionTextHi || q.questionTextEn : q.questionTextEn}
                                </Text>

                                {selectedOpt && (
                                    <Text
                                        style={[
                                            styles.reviewAnsLine,
                                            { color: ev?.isCorrect ? '#047857' : '#B91C1C' },
                                        ]}
                                    >
                                        Your Answer:{' '}
                                        {lang === 'hi'
                                            ? selectedOpt.optionTextHi || selectedOpt.optionTextEn
                                            : selectedOpt.optionTextEn}
                                    </Text>
                                )}

                                {correctOpt && (
                                    <Text style={[styles.reviewAnsLine, { color: '#047857', fontWeight: '700' }]}>
                                        Correct Answer:{' '}
                                        {lang === 'hi'
                                            ? correctOpt.optionTextHi || correctOpt.optionTextEn
                                            : correctOpt.optionTextEn}
                                    </Text>
                                )}

                                {!ev && (
                                    <Text style={styles.skippedHint}>
                                        Is question ko aapne attempt nahi kiya tha.
                                    </Text>
                                )}

                                {(ev?.explanationEn || ev?.explanationHi) && (
                                    <View style={styles.expMini}>
                                        <Text style={styles.expMiniTitle}>Explanation</Text>
                                        <Text style={styles.expMiniText}>
                                            {lang === 'hi'
                                                ? ev.explanationHi || ev.explanationEn
                                                : ev.explanationEn || ev.explanationHi}
                                        </Text>
                                    </View>
                                )}
                            </View>
                        );
                    })}

                    <TouchableOpacity onPress={() => router.back()} style={styles.doneBtn}>
                        <Text style={styles.doneBtnText}>Back to Practice &amp; Tests</Text>
                    </TouchableOpacity>
                </ScrollView>
            </View>
        );
    }

    const isBookmarked = Boolean(bookmarkMap[currentQuestion.id]);
    const isMarked = Boolean(markedMap[currentQuestion.id]);
    const questionText =
        lang === 'hi'
            ? currentQuestion.questionTextHi || currentQuestion.questionTextEn
            : currentQuestion.questionTextEn;

    return (
        <View style={styles.root}>
            {/* Top Bar */}
            <LinearGradient
                colors={runnerMode === 'test' ? Gradients.dark : Gradients.hero}
                style={styles.topBar}
            >
                <TouchableOpacity
                    onPress={() =>
                        Alert.alert(
                            runnerMode === 'test' ? 'Exit Test?' : 'Exit Quiz?',
                            'Kya aap submit karke result dekhna chahte hain ya exit karna chahte hain?',
                            [
                                { text: 'Stay', style: 'cancel' },
                                { text: 'Submit & See Result', onPress: submitAllAndFinish },
                                { text: 'Exit', style: 'destructive', onPress: () => router.back() },
                            ]
                        )
                    }
                    style={styles.iconBtn}
                >
                    <Ionicons name="close" size={22} color={Colors.white} />
                </TouchableOpacity>

                <View style={{ flex: 1 }}>
                    <Text style={styles.topTitle} numberOfLines={1}>
                        {title}
                    </Text>
                    <Text style={styles.topSub}>
                        {runnerMode === 'test' ? 'Test Mode' : 'Quick Quiz'} • Q{currentIndex + 1}/
                        {questions.length}
                    </Text>
                </View>

                <View style={styles.timerPill}>
                    <Ionicons name="time-outline" size={14} color={Colors.white} />
                    <Text style={styles.timerText}>{formatClock(elapsedSeconds)}</Text>
                </View>

                <TouchableOpacity
                    onPress={() => setLang(lang === 'en' ? 'hi' : 'en')}
                    style={styles.langPill}
                >
                    <Text style={styles.langPillText}>{lang === 'en' ? 'EN' : 'हिं'}</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={handleToggleBookmark} style={styles.iconBtn}>
                    <Ionicons
                        name={isBookmarked ? 'bookmark' : 'bookmark-outline'}
                        size={19}
                        color={isBookmarked ? '#FDE047' : Colors.white}
                    />
                </TouchableOpacity>
            </LinearGradient>

            {/* Question Palette (Testbook Style) */}
            <View style={styles.paletteBar}>
                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.paletteContent}
                >
                    {questions.map((item, idx) => {
                        const isCurrent = idx === currentIndex;
                        const isAnswered = Boolean(selectedMap[item.id]);
                        const isMark = Boolean(markedMap[item.id]);
                        return (
                            <TouchableOpacity
                                key={item.id}
                                onPress={() => goToIndex(idx)}
                                style={[
                                    styles.paletteNum,
                                    isAnswered && styles.paletteAnswered,
                                    isMark && styles.paletteMarked,
                                    isCurrent && styles.paletteCurrent,
                                ]}
                            >
                                <Text
                                    style={[
                                        styles.paletteText,
                                        (isAnswered || isMark || isCurrent) && { color: Colors.white },
                                    ]}
                                >
                                    {idx + 1}
                                </Text>
                            </TouchableOpacity>
                        );
                    })}
                </ScrollView>
            </View>

            <ScrollView contentContainerStyle={styles.body}>
                {/* Question Card */}
                <View style={styles.qCard}>
                    <View style={styles.qBadgeRow}>
                        <Text style={styles.qNumBadge}>Question {currentIndex + 1}</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                            {runnerMode === 'test' && (
                                <TouchableOpacity
                                    onPress={() =>
                                        setMarkedMap((prev) => ({
                                            ...prev,
                                            [currentQuestion.id]: !prev[currentQuestion.id],
                                        }))
                                    }
                                    style={[styles.markBtn, isMarked && styles.markBtnActive]}
                                >
                                    <Ionicons
                                        name={isMarked ? 'flag' : 'flag-outline'}
                                        size={13}
                                        color={isMarked ? Colors.white : Colors.secondary}
                                    />
                                    <Text
                                        style={[styles.markBtnText, isMarked && { color: Colors.white }]}
                                    >
                                        {isMarked ? 'Marked' : 'Review'}
                                    </Text>
                                </TouchableOpacity>
                            )}
                            <Text style={styles.diffBadge}>{currentQuestion.difficultyLevel.toUpperCase()}</Text>
                        </View>
                    </View>

                    <Text style={styles.qText}>{questionText}</Text>

                    {currentQuestion.questionImageUrl && (
                        <Image
                            source={{ uri: currentQuestion.questionImageUrl }}
                            style={styles.qImage}
                            resizeMode="contain"
                        />
                    )}
                </View>

                {/* Options */}
                <View style={{ gap: 10 }}>
                    {currentQuestion.options.map((opt, idx) => {
                        const label = String.fromCharCode(65 + idx);
                        const optText = lang === 'hi' ? opt.optionTextHi || opt.optionTextEn : opt.optionTextEn;
                        const isSelected = currentSelectedId === opt.id;

                        let borderColor: string = Colors.border;
                        let bgColor: string = Colors.surface;

                        // Show green/red ONLY in Quick Quiz Mode after checking answer
                        if (runnerMode === 'quiz' && currentEval) {
                            if (opt.id === currentEval.correctOptionId) {
                                borderColor = Colors.success;
                                bgColor = Colors.successLight;
                            } else if (opt.id === currentEval.selectedOptionId && !currentEval.isCorrect) {
                                borderColor = Colors.danger;
                                bgColor = Colors.dangerLight;
                            }
                        } else if (isSelected) {
                            borderColor = Colors.primary;
                            bgColor = Colors.primaryLight;
                        }

                        return (
                            <TouchableOpacity
                                key={opt.id}
                                disabled={runnerMode === 'quiz' && Boolean(currentEval)}
                                activeOpacity={0.8}
                                onPress={() =>
                                    setSelectedMap((prev) => ({
                                        ...prev,
                                        [currentQuestion.id]: opt.id,
                                    }))
                                }
                                style={[styles.optionCard, { borderColor, backgroundColor: bgColor }]}
                            >
                                <View
                                    style={[
                                        styles.optBadge,
                                        isSelected && !(runnerMode === 'quiz' && currentEval) && {
                                            backgroundColor: Colors.primary,
                                        },
                                        runnerMode === 'quiz' &&
                                        currentEval &&
                                        opt.id === currentEval.correctOptionId && { backgroundColor: Colors.success },
                                        runnerMode === 'quiz' &&
                                        currentEval &&
                                        opt.id === currentEval.selectedOptionId &&
                                        !currentEval.isCorrect && { backgroundColor: Colors.danger },
                                    ]}
                                >
                                    <Text
                                        style={[
                                            styles.optBadgeText,
                                            (isSelected ||
                                                (runnerMode === 'quiz' &&
                                                    currentEval &&
                                                    (opt.id === currentEval.correctOptionId ||
                                                        opt.id === currentEval.selectedOptionId))) && {
                                                color: Colors.white,
                                            },
                                        ]}
                                    >
                                        {label}
                                    </Text>
                                </View>

                                <View style={{ flex: 1 }}>
                                    <Text style={styles.optText}>{optText}</Text>
                                    {opt.optionImageUrl && (
                                        <Image
                                            source={{ uri: opt.optionImageUrl }}
                                            style={styles.optImage}
                                            resizeMode="contain"
                                        />
                                    )}
                                </View>
                            </TouchableOpacity>
                        );
                    })}
                </View>

                {/* Clear Response in Test Mode */}
                {runnerMode === 'test' && currentSelectedId && (
                    <TouchableOpacity
                        onPress={() =>
                            setSelectedMap((prev) => ({
                                ...prev,
                                [currentQuestion.id]: null,
                            }))
                        }
                        style={styles.clearBtn}
                    >
                        <Ionicons name="refresh-outline" size={15} color={Colors.textSecondary} />
                        <Text style={styles.clearBtnText}>Clear Response</Text>
                    </TouchableOpacity>
                )}

                {/* Instant Explanation Box — ONLY in Quick Quiz Mode */}
                {runnerMode === 'quiz' && currentEval && (
                    <View
                        style={[
                            styles.feedbackBox,
                            {
                                backgroundColor: currentEval.isCorrect ? Colors.successLight : Colors.dangerLight,
                                borderColor: currentEval.isCorrect ? '#A7F3D0' : '#FECACA',
                            },
                        ]}
                    >
                        <View style={styles.feedbackTitleRow}>
                            <Ionicons
                                name={currentEval.isCorrect ? 'checkmark-circle' : 'close-circle'}
                                size={22}
                                color={currentEval.isCorrect ? Colors.success : Colors.danger}
                            />
                            <Text
                                style={[
                                    styles.feedbackTitle,
                                    { color: currentEval.isCorrect ? '#047857' : '#B91C1C' },
                                ]}
                            >
                                {currentEval.isCorrect ? 'Correct Answer!' : 'Incorrect Answer'}
                            </Text>
                        </View>

                        {(currentEval.explanationEn || currentEval.explanationHi) && (
                            <Text style={styles.explanationText}>
                                {lang === 'hi'
                                    ? currentEval.explanationHi || currentEval.explanationEn
                                    : currentEval.explanationEn || currentEval.explanationHi}
                            </Text>
                        )}
                    </View>
                )}
            </ScrollView>

            {/* Bottom Action Footer */}
            <View style={styles.footer}>
                <TouchableOpacity
                    disabled={currentIndex === 0}
                    onPress={() => goToIndex(currentIndex - 1)}
                    style={[styles.navBtn, currentIndex === 0 && { opacity: 0.4 }]}
                >
                    <Ionicons name="chevron-back" size={18} color={Colors.text} />
                    <Text style={styles.navBtnText}>Prev</Text>
                </TouchableOpacity>

                {runnerMode === 'test' ? (
                    <>
                        {currentIndex < questions.length - 1 && (
                            <TouchableOpacity
                                onPress={() => goToIndex(currentIndex + 1)}
                                style={styles.nextBtn}
                            >
                                <Text style={styles.nextBtnText}>Save &amp; Next →</Text>
                            </TouchableOpacity>
                        )}
                        <TouchableOpacity
                            disabled={submitting}
                            onPress={confirmSubmitTest}
                            style={[
                                styles.submitBtn,
                                currentIndex === questions.length - 1 && { flex: 1 },
                            ]}
                        >
                            {submitting ? (
                                <ActivityIndicator color={Colors.white} />
                            ) : (
                                <Text style={styles.submitBtnText}>Submit Test</Text>
                            )}
                        </TouchableOpacity>
                    </>
                ) : !currentEval ? (
                    <TouchableOpacity
                        disabled={!currentSelectedId || submitting}
                        onPress={handleQuizCheckAnswer}
                        style={[
                            styles.nextBtn,
                            (!currentSelectedId || submitting) && { opacity: 0.5 },
                        ]}
                    >
                        {submitting ? (
                            <ActivityIndicator color={Colors.white} />
                        ) : (
                            <Text style={styles.nextBtnText}>Check Answer</Text>
                        )}
                    </TouchableOpacity>
                ) : currentIndex < questions.length - 1 ? (
                    <TouchableOpacity onPress={() => goToIndex(currentIndex + 1)} style={styles.nextBtn}>
                        <Text style={styles.nextBtnText}>Next Question →</Text>
                    </TouchableOpacity>
                ) : (
                    <TouchableOpacity
                        disabled={submitting}
                        onPress={submitAllAndFinish}
                        style={[styles.submitBtn, { flex: 1 }]}
                    >
                        {submitting ? (
                            <ActivityIndicator color={Colors.white} />
                        ) : (
                            <Text style={styles.submitBtnText}>Finish &amp; See Result</Text>
                        )}
                    </TouchableOpacity>
                )}
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1, backgroundColor: Colors.bg },
    center: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 28,
        backgroundColor: Colors.bg,
    },
    loadingText: { marginTop: 12, fontSize: 14, color: Colors.textSecondary, fontWeight: '600' },
    errTitle: { fontSize: 19, fontWeight: '800', color: Colors.text, marginTop: 12 },
    errSub: {
        fontSize: 13,
        color: Colors.textSecondary,
        textAlign: 'center',
        marginTop: 6,
        lineHeight: 20,
    },
    backFallbackBtn: {
        marginTop: 20,
        backgroundColor: Colors.primary,
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 12,
    },
    backFallbackText: { color: Colors.white, fontWeight: '700' },
    topBar: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        paddingTop: 52,
        paddingBottom: 14,
        paddingHorizontal: 14,
    },
    iconBtn: {
        width: 36,
        height: 36,
        borderRadius: 11,
        backgroundColor: 'rgba(255,255,255,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    topTitle: { fontSize: 15, fontWeight: '800', color: Colors.white },
    topSub: { fontSize: 11, color: '#E0E7FF', marginTop: 2 },
    timerPill: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: 'rgba(255,255,255,0.2)',
        paddingHorizontal: 9,
        paddingVertical: 6,
        borderRadius: 10,
    },
    timerText: {
        color: Colors.white,
        fontSize: 12,
        fontWeight: '800',
        fontVariant: ['tabular-nums'],
    },
    langPill: {
        backgroundColor: 'rgba(255,255,255,0.22)',
        paddingHorizontal: 9,
        paddingVertical: 6,
        borderRadius: 10,
    },
    langPillText: { color: Colors.white, fontSize: 11, fontWeight: '800' },
    paletteBar: { backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border },
    paletteContent: { paddingHorizontal: 14, paddingVertical: 10, gap: 8 },
    paletteNum: {
        width: 34,
        height: 34,
        borderRadius: 10,
        backgroundColor: Colors.surfaceAlt,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: Colors.border,
    },
    paletteAnswered: { backgroundColor: Colors.success, borderColor: Colors.success },
    paletteMarked: { backgroundColor: Colors.secondary, borderColor: Colors.secondary },
    paletteCurrent: { backgroundColor: Colors.primary, borderColor: Colors.primary },
    paletteText: { fontSize: 13, fontWeight: '800', color: Colors.text },
    body: { padding: 16, gap: 14, paddingBottom: 32 },
    qCard: { backgroundColor: Colors.surface, borderRadius: 20, padding: 18, ...Shadows.card },
    qBadgeRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    qNumBadge: {
        backgroundColor: Colors.primaryLight,
        color: Colors.primary,
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 8,
        fontSize: 12,
        fontWeight: '800',
    },
    markBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        paddingHorizontal: 9,
        paddingVertical: 4,
        borderRadius: 8,
        backgroundColor: '#F3E8FF',
    },
    markBtnActive: { backgroundColor: Colors.secondary },
    markBtnText: { fontSize: 11, fontWeight: '700', color: Colors.secondary },
    diffBadge: { fontSize: 11, fontWeight: '700', color: Colors.textMuted },
    qText: { fontSize: 16, fontWeight: '700', color: Colors.text, lineHeight: 24 },
    qImage: { width: '100%', height: 180, marginTop: 12, borderRadius: 12 },
    optionCard: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        padding: 14,
        borderRadius: 16,
        borderWidth: 2,
    },
    optBadge: {
        width: 32,
        height: 32,
        borderRadius: 10,
        backgroundColor: Colors.surfaceAlt,
        alignItems: 'center',
        justifyContent: 'center',
    },
    optBadgeText: { fontSize: 13, fontWeight: '800', color: Colors.text },
    optText: { fontSize: 14, fontWeight: '600', color: Colors.text, lineHeight: 21 },
    optImage: { width: '100%', height: 110, marginTop: 8, borderRadius: 8 },
    clearBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-end',
        gap: 5,
        paddingVertical: 6,
        paddingHorizontal: 10,
    },
    clearBtnText: { fontSize: 12, fontWeight: '700', color: Colors.textSecondary },
    feedbackBox: { borderRadius: 16, padding: 16, borderWidth: 1, gap: 8 },
    feedbackTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    feedbackTitle: { fontSize: 15, fontWeight: '800' },
    explanationText: { fontSize: 13, color: Colors.text, lineHeight: 21 },
    footer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        padding: 14,
        backgroundColor: Colors.surface,
        borderTopWidth: 1,
        borderTopColor: Colors.border,
    },
    navBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 3,
        paddingHorizontal: 12,
        height: 46,
        borderRadius: 12,
        backgroundColor: Colors.surfaceAlt,
    },
    navBtnText: { fontSize: 13, fontWeight: '700', color: Colors.text },
    nextBtn: {
        flex: 1,
        height: 46,
        borderRadius: 12,
        backgroundColor: Colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
    },
    nextBtnText: { color: Colors.white, fontSize: 14, fontWeight: '800' },
    submitBtn: {
        paddingHorizontal: 18,
        height: 46,
        borderRadius: 12,
        backgroundColor: Colors.success,
        alignItems: 'center',
        justifyContent: 'center',
    },
    submitBtnText: { color: Colors.white, fontSize: 14, fontWeight: '800' },
    resHeader: {
        paddingTop: 54,
        paddingBottom: 20,
        paddingHorizontal: 18,
        borderBottomLeftRadius: 28,
        borderBottomRightRadius: 28,
    },
    resTopRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    resTitle: { fontSize: 19, fontWeight: '800', color: Colors.white },
    resSub: { fontSize: 12, color: '#E0E7FF', marginTop: 2 },
    scoreHero: {
        marginTop: 14,
        backgroundColor: 'rgba(255,255,255,0.18)',
        borderRadius: 18,
        paddingVertical: 14,
        paddingHorizontal: 18,
        alignItems: 'center',
    },
    scoreBig: { fontSize: 28, fontWeight: '900', color: '#FEF08A' },
    scoreMeta: { fontSize: 12, color: Colors.white, marginTop: 4, fontWeight: '600' },
    resStatsRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
    resPill: {
        flex: 1,
        backgroundColor: 'rgba(255,255,255,0.16)',
        borderRadius: 14,
        paddingVertical: 10,
        alignItems: 'center',
    },
    resPillNum: { fontSize: 18, fontWeight: '800', color: Colors.white },
    resPillLbl: { fontSize: 11, color: '#E0E7FF', fontWeight: '600' },
    reviewList: { padding: 16, gap: 12, paddingBottom: 36 },
    filterRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
    revFilterBtn: {
        paddingHorizontal: 11,
        paddingVertical: 7,
        borderRadius: 10,
        backgroundColor: Colors.surface,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    revFilterActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
    revFilterText: { fontSize: 11, fontWeight: '700', color: Colors.textSecondary },
    reviewCard: {
        backgroundColor: Colors.surface,
        borderRadius: 16,
        padding: 16,
        gap: 6,
        ...Shadows.card,
    },
    reviewTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    reviewQNum: { fontSize: 13, fontWeight: '800', color: Colors.primary },
    reviewStatus: { fontSize: 12, fontWeight: '800' },
    reviewQText: { fontSize: 14, fontWeight: '700', color: Colors.text, lineHeight: 21 },
    reviewAnsLine: { fontSize: 12, color: Colors.textSecondary },
    skippedHint: { fontSize: 11, color: Colors.textMuted, fontStyle: 'italic' },
    expMini: { backgroundColor: Colors.surfaceAlt, padding: 10, borderRadius: 10, marginTop: 4 },
    expMiniTitle: { fontSize: 11, fontWeight: '800', color: Colors.primary, marginBottom: 2 },
    expMiniText: { fontSize: 12, color: Colors.text, lineHeight: 18 },
    doneBtn: {
        marginTop: 8,
        backgroundColor: Colors.primary,
        paddingVertical: 14,
        borderRadius: 14,
        alignItems: 'center',
    },
    doneBtnText: { color: Colors.white, fontSize: 15, fontWeight: '800' },
});