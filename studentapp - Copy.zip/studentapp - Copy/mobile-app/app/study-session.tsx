import React, { useEffect, useRef, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    TextInput,
    Switch,
    Alert,
    AppState,
    AppStateStatus,
    ActivityIndicator,
    Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { api, createIdempotencyKey, getApiErrorMessage } from '../src/services/api';
import { Colors, Gradients, Shadows } from '../src/theme/colors';

type SessionPhase = 'ready' | 'active' | 'paused' | 'completed';

interface SessionSummary {
    actualDurationSeconds: number;
    pausedDurationSeconds: number;
    topicMarkedCompleted: boolean;
    minutesAdded: number;
    distractionsCount: number;
}

function cleanUuid(val?: string | string[]): string | undefined {
    const str = Array.isArray(val) ? val[0] : val;
    if (!str || str.trim().length < 10) return undefined;
    return str.trim();
}

function formatClock(totalSeconds: number): string {
    const safe = Math.max(0, totalSeconds);
    const hrs = Math.floor(safe / 3600);
    const mins = Math.floor((safe % 3600) / 60);
    const secs = safe % 60;
    return [hrs, mins, secs].map((n) => String(n).padStart(2, '0')).join(':');
}

export default function StudySessionScreen() {
    const params = useLocalSearchParams();
    const router = useRouter();

    const subjectId = cleanUuid(params.subjectId);
    const chapterId = cleanUuid(params.chapterId);
    const topicId = cleanUuid(params.topicId);
    const resumeSessionId = cleanUuid(params.resumeSessionId);
    const subjectName = (Array.isArray(params.subjectName) ? params.subjectName[0] : params.subjectName) || 'Self Study';
    const topicName = (Array.isArray(params.topicName) ? params.topicName[0] : params.topicName) || 'Focused Study Session';
    const initialFocus = params.isFocusMode === '1';

    const [sessionId, setSessionId] = useState<string | null>(resumeSessionId || null);
    const [phase, setPhase] = useState<SessionPhase>('ready');
    const [elapsedSeconds, setElapsedSeconds] = useState(0);
    const [focusMode, setFocusMode] = useState(initialFocus);
    const [plannedFocusMin, setPlannedFocusMin] = useState(25);
    const [blockedAppsCount, setBlockedAppsCount] = useState(0);
    const [distractionsCount, setDistractionsCount] = useState(0);

    const [notes, setNotes] = useState('');
    const [markTopicCompleted, setMarkTopicCompleted] = useState(false);
    const [topicNotePreview, setTopicNotePreview] = useState<string | null>(null);
    const [showTopicNotes, setShowTopicNotes] = useState(false);

    const [busy, setBusy] = useState(false);
    const [summary, setSummary] = useState<SessionSummary | null>(null);

    // Accurate timestamp refs (survive app backgrounding)
    const startedAtMsRef = useRef<number>(Date.now());
    const totalPausedMsRef = useRef<number>(0);
    const pauseStartedAtMsRef = useRef<number | null>(null);
    const appStateRef = useRef<AppStateStatus>((AppState.currentState ?? 'active') as AppStateStatus);
    const computeElapsedSeconds = (): number => {
        const now = Date.now();
        const activePauseMs = pauseStartedAtMsRef.current ? now - pauseStartedAtMsRef.current : 0;
        const activeMs = now - startedAtMsRef.current - totalPausedMsRef.current - activePauseMs;
        return Math.min(12 * 3600, Math.max(0, Math.floor(activeMs / 1000)));
    };

    // Load Focus Mode config & optional topic note preview + resume active session if passed
    useEffect(() => {
        const init = async () => {
            try {
                const focusRes = await api.get('/focus-mode/settings');
                const cfg = focusRes.data.data;
                if (cfg) {
                    setPlannedFocusMin(cfg.focusDurationMinutes || 25);
                    setBlockedAppsCount(Array.isArray(cfg.blockedApps) ? cfg.blockedApps.length : 0);
                }
            } catch {
                // Default settings remain active
            }

            if (topicId) {
                try {
                    const noteRes = await api.get(`/topics/${topicId}/notes`);
                    const n = noteRes.data.data?.note;
                    if (n) {
                        setTopicNotePreview(n.contentEn || n.contentHi || n.summary || null);
                    }
                } catch {
                    // Optional preview
                }
            }

            if (resumeSessionId) {
                try {
                    const activeRes = await api.get('/study-sessions/active');
                    const active = activeRes.data.data?.session;
                    if (active && active.id === resumeSessionId) {
                        const approx = active.approximateElapsedSeconds || 0;
                        startedAtMsRef.current = Date.now() - approx * 1000;
                        totalPausedMsRef.current = 0;
                        setSessionId(active.id);
                        setFocusMode(Boolean(active.isFocusMode));
                        setElapsedSeconds(approx);
                        if (active.status === 'paused') {
                            pauseStartedAtMsRef.current = Date.now();
                            setPhase('paused');
                        } else {
                            setPhase('active');
                        }
                    }
                } catch {
                    // Fallback to ready
                }
            }
        };
        init();
    }, [resumeSessionId, topicId]);

    // 1-second timestamp tick
    useEffect(() => {
        if (phase !== 'active') return;
        const timer = setInterval(() => {
            setElapsedSeconds(computeElapsedSeconds());
        }, 1000);
        return () => clearInterval(timer);
    }, [phase]);

    // Periodic 30-second server heartbeat for crash/kill resilience
    useEffect(() => {
        if (phase !== 'active' || !sessionId) return;
        const hb = setInterval(() => {
            api
                .post(`/study-sessions/${sessionId}/heartbeat`, {
                    deviceTimestamp: new Date().toISOString(),
                    eventType: 'heartbeat',
                    elapsedSeconds: computeElapsedSeconds(),
                })
                .catch(() => {
                    // Ignore intermittent offline heartbeat
                });
        }, 30000);
        return () => clearInterval(hb);
    }, [phase, sessionId]);

    // Background / Foreground tracking (recalculates timer + detects Focus Mode app switches)
    useEffect(() => {
        const subscription = AppState.addEventListener('change', (nextState) => {
            const prevState = appStateRef.current;
            appStateRef.current = nextState;

            if (phase === 'active') {
                if (prevState === 'active' && (nextState === 'background' || nextState === 'inactive')) {
                    if (sessionId) {
                        api
                            .post(`/study-sessions/${sessionId}/heartbeat`, {
                                deviceTimestamp: new Date().toISOString(),
                                eventType: 'app_backgrounded',
                                elapsedSeconds: computeElapsedSeconds(),
                            })
                            .catch(() => { });
                    }
                }

                if ((prevState === 'background' || prevState === 'inactive') && nextState === 'active') {
                    setElapsedSeconds(computeElapsedSeconds());
                    if (focusMode) {
                        setDistractionsCount((c) => c + 1);
                        Alert.alert(
                            'Focus Mode Reminder',
                            'Aap study session ke dauran app se bahar gaye the. Focus banaye rakhein — distraction count +1 record ho gaya hai.'
                        );
                    }
                }
            }
        });

        return () => subscription.remove();
    }, [phase, focusMode, sessionId]);

    const handleStart = async () => {
        setBusy(true);
        try {
            const localSessionId = createIdempotencyKey();
            const res = await api.post(
                '/study-sessions',
                {
                    subjectId,
                    chapterId,
                    topicId,
                    isFocusMode: focusMode,
                    deviceId: `mobile_${Platform.OS}`,
                    localSessionId,
                },
                { headers: { 'Idempotency-Key': localSessionId } }
            );

            startedAtMsRef.current = Date.now();
            totalPausedMsRef.current = 0;
            pauseStartedAtMsRef.current = null;
            setElapsedSeconds(0);
            setSessionId(res.data.data.sessionId);
            setPhase('active');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setBusy(false);
        }
    };

    const handlePause = async () => {
        if (!sessionId) return;
        setBusy(true);
        try {
            await api.patch(`/study-sessions/${sessionId}/pause`);
            pauseStartedAtMsRef.current = Date.now();
            setPhase('paused');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setBusy(false);
        }
    };

    const handleResume = async () => {
        if (!sessionId) return;
        setBusy(true);
        try {
            await api.patch(`/study-sessions/${sessionId}/resume`);
            if (pauseStartedAtMsRef.current) {
                totalPausedMsRef.current += Date.now() - pauseStartedAtMsRef.current;
                pauseStartedAtMsRef.current = null;
            }
            setElapsedSeconds(computeElapsedSeconds());
            setPhase('active');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setBusy(false);
        }
    };

    const finalizeSession = async (exitReason: 'completed' | 'emergency_exit') => {
        if (!sessionId) {
            router.back();
            return;
        }
        setBusy(true);
        try {
            const res = await api.patch(`/study-sessions/${sessionId}/end`, {
                notes: notes.trim() || undefined,
                markTopicCompleted: Boolean(topicId && markTopicCompleted),
            });

            const d = res.data.data;

            if (focusMode) {
                await api
                    .post('/focus-sessions', {
                        studySessionId: sessionId,
                        deviceId: `mobile_${Platform.OS}`,
                        plannedDurationMinutes: plannedFocusMin,
                        actualDurationSeconds: d.actualDurationSeconds || elapsedSeconds,
                        distractionsCount,
                        wasCompleted: exitReason === 'completed',
                        exitReason,
                        permissionGranted: { awareness_mode: true },
                        blockingMethodUsed: 'awareness_reminder',
                    })
                    .catch(() => { });
            }

            setSummary({
                actualDurationSeconds: d.actualDurationSeconds || elapsedSeconds,
                pausedDurationSeconds: d.pausedDurationSeconds || 0,
                topicMarkedCompleted: Boolean(d.topicMarkedCompleted),
                minutesAdded: d.dailyTargetUpdated?.minutesAdded || 0,
                distractionsCount,
            });
            setPhase('completed');
        } catch (err) {
            Alert.alert('Error', getApiErrorMessage(err));
        } finally {
            setBusy(false);
        }
    };

    const confirmEnd = (isEmergency = false) => {
        Alert.alert(
            isEmergency ? 'Emergency Exit Focus Mode?' : 'End Study Session?',
            isEmergency
                ? 'Aap Focus Mode se turant bahar nikal sakte hain. Ab tak ka study time save ho jayega.'
                : 'Kya aap ye study session khatam karke progress save karna chahte hain?',
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: isEmergency ? 'Exit & Save' : 'End & Save',
                    style: 'destructive',
                    onPress: () => finalizeSession(isEmergency ? 'emergency_exit' : 'completed'),
                },
            ]
        );
    };

    const handleBackPress = () => {
        if (phase === 'active' || phase === 'paused') {
            confirmEnd(false);
            return;
        }
        router.back();
    };

    if (phase === 'completed' && summary) {
        return (
            <View style={styles.summaryRoot}>
                <LinearGradient colors={Gradients.practice} style={styles.summaryCard}>
                    <View style={styles.summaryIcon}>
                        <Ionicons name="checkmark-done" size={40} color={Colors.success} />
                    </View>
                    <Text style={styles.summaryTitle}>Great Study Session!</Text>
                    <Text style={styles.summarySub}>{topicName}</Text>

                    <View style={styles.summaryStats}>
                        <View style={styles.summaryStatBox}>
                            <Text style={styles.summaryVal}>{formatClock(summary.actualDurationSeconds)}</Text>
                            <Text style={styles.summaryLbl}>Focused Time</Text>
                        </View>
                        <View style={styles.summaryStatBox}>
                            <Text style={styles.summaryVal}>+{summary.minutesAdded} min</Text>
                            <Text style={styles.summaryLbl}>Target Added</Text>
                        </View>
                        {focusMode && (
                            <View style={styles.summaryStatBox}>
                                <Text style={styles.summaryVal}>{summary.distractionsCount}</Text>
                                <Text style={styles.summaryLbl}>Distractions</Text>
                            </View>
                        )}
                    </View>

                    {summary.topicMarkedCompleted && (
                        <View style={styles.completedPill}>
                            <Ionicons name="ribbon" size={16} color="#FEF08A" />
                            <Text style={styles.completedPillText}>Topic marked as Completed!</Text>
                        </View>
                    )}

                    <TouchableOpacity onPress={() => router.back()} style={styles.doneBtn}>
                        <Text style={styles.doneBtnText}>Back to Study Dashboard</Text>
                    </TouchableOpacity>
                </LinearGradient>
            </View>
        );
    }

    return (
        <LinearGradient
            colors={focusMode ? Gradients.focus : Gradients.dark}
            style={styles.root}
        >
            {/* Top Bar */}
            <View style={styles.topBar}>
                <TouchableOpacity onPress={handleBackPress} style={styles.iconBtn}>
                    <Ionicons name="arrow-back" size={22} color={Colors.white} />
                </TouchableOpacity>
                <View style={{ flex: 1, alignItems: 'center' }}>
                    <Text style={styles.subjectTag} numberOfLines={1}>
                        {subjectName}
                    </Text>
                    <Text style={styles.topicTitle} numberOfLines={1}>
                        {topicName}
                    </Text>
                </View>
                <View style={styles.statusChip}>
                    <View
                        style={[
                            styles.liveDot,
                            {
                                backgroundColor:
                                    phase === 'active' ? '#4ADE80' : phase === 'paused' ? '#FBBF24' : '#CBD5E1',
                            },
                        ]}
                    />
                    <Text style={styles.statusChipText}>{phase.toUpperCase()}</Text>
                </View>
            </View>

            <ScrollView contentContainerStyle={styles.body}>
                {/* Main Circular Timer Display */}
                <View style={styles.timerCircle}>
                    <Text style={styles.timerCaption}>
                        {focusMode ? 'FOCUS MODE TIMER' : 'STUDY TIMER'}
                    </Text>
                    <Text style={styles.timerDigits}>{formatClock(elapsedSeconds)}</Text>
                    {focusMode && (
                        <View style={styles.focusBadge}>
                            <Ionicons name="shield-checkmark" size={14} color="#FDE047" />
                            <Text style={styles.focusBadgeText}>
                                Goal: {plannedFocusMin}m • Distractions: {distractionsCount}
                            </Text>
                        </View>
                    )}
                </View>

                {/* Controls */}
                <View style={styles.controlsRow}>
                    {phase === 'ready' ? (
                        <TouchableOpacity
                            disabled={busy}
                            onPress={handleStart}
                            style={styles.bigPrimaryBtn}
                        >
                            {busy ? (
                                <ActivityIndicator color={Colors.primary} />
                            ) : (
                                <>
                                    <Ionicons name="play" size={22} color={Colors.primary} />
                                    <Text style={styles.bigPrimaryText}>Start Studying Now</Text>
                                </>
                            )}
                        </TouchableOpacity>
                    ) : (
                        <>
                            <TouchableOpacity
                                disabled={busy}
                                onPress={phase === 'active' ? handlePause : handleResume}
                                style={styles.controlBtn}
                            >
                                <Ionicons
                                    name={phase === 'active' ? 'pause' : 'play'}
                                    size={22}
                                    color={Colors.white}
                                />
                                <Text style={styles.controlText}>
                                    {phase === 'active' ? 'Pause' : 'Resume'}
                                </Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                disabled={busy}
                                onPress={() => confirmEnd(false)}
                                style={[styles.controlBtn, styles.endBtn]}
                            >
                                <Ionicons name="stop" size={22} color={Colors.white} />
                                <Text style={styles.controlText}>End &amp; Save</Text>
                            </TouchableOpacity>
                        </>
                    )}
                </View>

                {/* Focus Mode Toggle (Before Start) */}
                {phase === 'ready' && (
                    <View style={styles.glassCard}>
                        <View style={styles.switchRow}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.glassTitle}>Enable Focus Mode</Text>
                                <Text style={styles.glassSub}>
                                    App switch hone par distraction reminder aur focus analytics track karega ({blockedAppsCount} apps configured).
                                </Text>
                            </View>
                            <Switch
                                value={focusMode}
                                onValueChange={setFocusMode}
                                trackColor={{ false: 'rgba(255,255,255,0.25)', true: '#4ADE80' }}
                                thumbColor={Colors.white}
                            />
                        </View>
                    </View>
                )}

                {/* Emergency Exit (Always visible in active Focus Mode per Play Store ethics) */}
                {focusMode && (phase === 'active' || phase === 'paused') && (
                    <TouchableOpacity
                        onPress={() => confirmEnd(true)}
                        style={styles.emergencyBtn}
                    >
                        <Ionicons name="alert-circle-outline" size={18} color="#FECACA" />
                        <Text style={styles.emergencyText}>Emergency Exit Focus Mode</Text>
                    </TouchableOpacity>
                )}

                {/* Mark Topic Completed Toggle */}
                {topicId && (
                    <View style={styles.glassCard}>
                        <View style={styles.switchRow}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.glassTitle}>Mark Topic Completed on End</Text>
                                <Text style={styles.glassSub}>
                                    Session save hote hi syllabus aur daily topic target update ho jayega.
                                </Text>
                            </View>
                            <Switch
                                value={markTopicCompleted}
                                onValueChange={setMarkTopicCompleted}
                                trackColor={{ false: 'rgba(255,255,255,0.25)', true: '#4ADE80' }}
                                thumbColor={Colors.white}
                            />
                        </View>
                    </View>
                )}

                {/* Inline Topic Notes Reader */}
                {topicNotePreview && (
                    <View style={styles.glassCard}>
                        <TouchableOpacity
                            onPress={() => setShowTopicNotes(!showTopicNotes)}
                            style={styles.switchRow}
                        >
                            <Text style={styles.glassTitle}>Topic Study Notes</Text>
                            <Ionicons
                                name={showTopicNotes ? 'chevron-up' : 'chevron-down'}
                                size={20}
                                color={Colors.white}
                            />
                        </TouchableOpacity>
                        {showTopicNotes && <Text style={styles.notePreview}>{topicNotePreview}</Text>}
                    </View>
                )}

                {/* Session Quick Notes */}
                <View style={styles.glassCard}>
                    <Text style={styles.glassTitle}>Session Notes (Optional)</Text>
                    <TextInput
                        multiline
                        numberOfLines={3}
                        placeholder="Aaj kya revise kiya? Important points likh lein..."
                        placeholderTextColor="rgba(255,255,255,0.55)"
                        value={notes}
                        onChangeText={setNotes}
                        style={styles.notesInput}
                    />
                </View>
            </ScrollView>
        </LinearGradient>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1 },
    topBar: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingTop: 54,
        paddingHorizontal: 16,
        paddingBottom: 12,
        gap: 10,
    },
    iconBtn: {
        width: 40,
        height: 40,
        borderRadius: 14,
        backgroundColor: 'rgba(255,255,255,0.16)',
        alignItems: 'center',
        justifyContent: 'center',
    },
    subjectTag: { fontSize: 11, fontWeight: '700', color: '#C7D2FE', textTransform: 'uppercase' },
    topicTitle: { fontSize: 16, fontWeight: '800', color: Colors.white, marginTop: 2 },
    statusChip: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: 'rgba(255,255,255,0.15)',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 20,
    },
    liveDot: { width: 8, height: 8, borderRadius: 4 },
    statusChipText: { fontSize: 10, fontWeight: '800', color: Colors.white },
    body: { padding: 20, gap: 16, paddingBottom: 40 },
    timerCircle: {
        alignSelf: 'center',
        width: 244,
        height: 244,
        borderRadius: 122,
        borderWidth: 6,
        borderColor: 'rgba(255,255,255,0.32)',
        backgroundColor: 'rgba(255,255,255,0.1)',
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 10,
    },
    timerCaption: { fontSize: 11, fontWeight: '700', color: '#E0E7FF', letterSpacing: 1.2 },
    timerDigits: {
        fontSize: 44,
        fontWeight: '800',
        color: Colors.white,
        marginTop: 6,
        fontVariant: ['tabular-nums'],
    },
    focusBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        marginTop: 10,
        backgroundColor: 'rgba(0,0,0,0.25)',
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 14,
    },
    focusBadgeText: { fontSize: 11, color: '#FEF08A', fontWeight: '700' },
    controlsRow: { flexDirection: 'row', gap: 12, justifyContent: 'center' },
    bigPrimaryBtn: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        backgroundColor: Colors.white,
        height: 54,
        borderRadius: 16,
        ...Shadows.card,
    },
    bigPrimaryText: { fontSize: 16, fontWeight: '800', color: Colors.primary },
    controlBtn: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        backgroundColor: 'rgba(255,255,255,0.2)',
        height: 52,
        borderRadius: 16,
    },
    endBtn: { backgroundColor: '#EF4444' },
    controlText: { color: Colors.white, fontSize: 15, fontWeight: '700' },
    glassCard: {
        backgroundColor: 'rgba(255,255,255,0.13)',
        borderRadius: 18,
        padding: 16,
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.18)',
    },
    switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
    glassTitle: { fontSize: 14, fontWeight: '700', color: Colors.white },
    glassSub: { fontSize: 12, color: 'rgba(255,255,255,0.78)', marginTop: 3, lineHeight: 17 },
    emergencyBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        paddingVertical: 10,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: 'rgba(254,202,202,0.4)',
    },
    emergencyText: { color: '#FECACA', fontSize: 13, fontWeight: '700' },
    notePreview: {
        marginTop: 12,
        color: '#F1F5F9',
        fontSize: 13,
        lineHeight: 21,
    },
    notesInput: {
        marginTop: 10,
        backgroundColor: 'rgba(0,0,0,0.2)',
        borderRadius: 12,
        padding: 12,
        color: Colors.white,
        fontSize: 13,
        textAlignVertical: 'top',
        minHeight: 74,
    },
    summaryRoot: {
        flex: 1,
        backgroundColor: Colors.bg,
        justifyContent: 'center',
        padding: 20,
    },
    summaryCard: {
        borderRadius: 28,
        padding: 26,
        alignItems: 'center',
        ...Shadows.card,
    },
    summaryIcon: {
        width: 72,
        height: 72,
        borderRadius: 24,
        backgroundColor: Colors.white,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 14,
    },
    summaryTitle: { fontSize: 24, fontWeight: '800', color: Colors.white },
    summarySub: { fontSize: 14, color: '#D1FAE5', marginTop: 4 },
    summaryStats: {
        flexDirection: 'row',
        gap: 10,
        marginTop: 22,
        width: '100%',
    },
    summaryStatBox: {
        flex: 1,
        backgroundColor: 'rgba(255,255,255,0.2)',
        borderRadius: 16,
        paddingVertical: 14,
        alignItems: 'center',
    },
    summaryVal: { fontSize: 17, fontWeight: '800', color: Colors.white },
    summaryLbl: { fontSize: 11, color: '#ECFDF5', marginTop: 3, fontWeight: '600' },
    completedPill: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        marginTop: 16,
        backgroundColor: 'rgba(0,0,0,0.2)',
        paddingHorizontal: 14,
        paddingVertical: 7,
        borderRadius: 20,
    },
    completedPillText: { color: '#FEF08A', fontSize: 13, fontWeight: '700' },
    doneBtn: {
        marginTop: 24,
        backgroundColor: Colors.white,
        paddingHorizontal: 28,
        paddingVertical: 14,
        borderRadius: 14,
        width: '100%',
        alignItems: 'center',
    },
    doneBtnText: { color: '#047857', fontSize: 15, fontWeight: '800' },
});