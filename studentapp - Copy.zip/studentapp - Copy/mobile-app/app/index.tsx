import React from 'react';
import { Redirect } from 'expo-router';
import { useAuthStore } from '../src/store/authStore';

export default function IndexScreen() {
    const { isAuthenticated, user } = useAuthStore();

    if (!isAuthenticated) {
        return <Redirect href="/(auth)/login" />;
    }

    if ((user?.enrolledExaminations?.length || 0) === 0) {
        return <Redirect href="/(auth)/select-exam" />;
    }

    return <Redirect href="/(tabs)/home" />;
}