import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../src/store/authStore';
import { api } from '../src/services/api';
import { Colors } from '../src/theme/colors';

interface RemoteAppConfig {
    minAppVersion: string;
    latestAppVersion: string;
    forceUpdate: boolean;
    maintenanceMode: boolean;
    maintenanceMessage: string | null;
}

function isVersionOlder(current: string, minRequired: string): boolean {
    const c = current.split('.').map(Number);
    const m = minRequired.split('.').map(Number);
    for (let i = 0; i < Math.max(c.length, m.length); i++) {
        const cv = c[i] || 0;
        const mv = m[i] || 0;
        if (cv < mv) return true;
        if (cv > mv) return false;
    }
    return false;
}

export default function RootLayout() {
    const { isAuthenticated, isBootstrapping, user, bootstrap } = useAuthStore();
    const segments = useSegments();
    const router = useRouter();
    const [appBlock, setAppBlock] = useState<{ title: string; message: string } | null>(null);

    const checkRemoteConfig = async () => {
        try {
            const res = await api.get('/app/config');
            const cfg: RemoteAppConfig = res.data.data;
            const currentVersion = process.env.EXPO_PUBLIC_APP_VERSION || '1.0.0';

            if (cfg.maintenanceMode) {
                setAppBlock({
                    title: 'App Under Maintenance',
                    message: cfg.maintenanceMessage || 'We are upgrading our servers. Please check back shortly.',
                });
                return;
            }

            if (cfg.forceUpdate && isVersionOlder(currentVersion, cfg.minAppVersion)) {
                setAppBlock({
                    title: 'Update Required',
                    message: `A new version (${cfg.latestAppVersion}) is available. Please update the app to continue studying.`,
                });
                return;
            }

            setAppBlock(null);
        } catch {
            // Allow app to continue if config endpoint is temporarily unreachable
        }
    };

    useEffect(() => {
        checkRemoteConfig();
        bootstrap();
    }, []);

    useEffect(() => {
        if (isBootstrapping || appBlock) return;

        const rootSegment = segments[0];
        const inAuthGroup = rootSegment === '(auth)';

        if (!isAuthenticated && !inAuthGroup) {
            router.replace('/(auth)/login');
        } else if (isAuthenticated && inAuthGroup) {
            const hasExams = (user?.enrolledExaminations?.length || 0) > 0;
            if (!hasExams) {
                router.replace('/(auth)/select-exam');
            } else {
                router.replace('/(tabs)/home');
            }
        }
    }, [isAuthenticated, isBootstrapping, segments, appBlock, user]);

    if (appBlock) {
        return (
            <View style={styles.centerBox}>
                <StatusBar style="dark" />
                <View style={styles.blockIcon}>
                    <Ionicons name="construct" size={40} color={Colors.primary} />
                </View>
                <Text style={styles.blockTitle}>{appBlock.title}</Text>
                <Text style={styles.blockMsg}>{appBlock.message}</Text>
                <TouchableOpacity style={styles.retryBtn} onPress={checkRemoteConfig}>
                    <Text style={styles.retryText}>Check Again</Text>
                </TouchableOpacity>
            </View>
        );
    }

    if (isBootstrapping) {
        return (
            <View style={styles.centerBox}>
                <StatusBar style="dark" />
                <ActivityIndicator size="large" color={Colors.primary} />
                <Text style={styles.loadingText}>Loading your study workspace...</Text>
            </View>
        );
    }

    return (
        <>
            <StatusBar style="light" />
            <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="index" />
                <Stack.Screen name="(auth)" />
                <Stack.Screen name="(tabs)" />
                <Stack.Screen name="study-session" options={{ presentation: 'fullScreenModal' }} />
                <Stack.Screen name="daily-targets" options={{ presentation: 'card' }} />
                <Stack.Screen name="practice-runner" options={{ presentation: 'fullScreenModal' }} />
                <Stack.Screen name="quiz-runner" options={{ presentation: 'fullScreenModal' }} />
                <Stack.Screen name="focus-settings" options={{ presentation: 'card' }} />
            </Stack>
        </>
    );
}

const styles = StyleSheet.create({
    centerBox: {
        flex: 1,
        backgroundColor: Colors.bg,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
    },
    loadingText: {
        marginTop: 14,
        fontSize: 15,
        color: Colors.textSecondary,
        fontWeight: '500',
    },
    blockIcon: {
        width: 76,
        height: 76,
        borderRadius: 24,
        backgroundColor: Colors.primaryLight,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 16,
    },
    blockTitle: {
        fontSize: 22,
        fontWeight: '700',
        color: Colors.text,
        marginBottom: 8,
    },
    blockMsg: {
        fontSize: 14,
        color: Colors.textSecondary,
        textAlign: 'center',
        lineHeight: 22,
        marginBottom: 24,
    },
    retryBtn: {
        backgroundColor: Colors.primary,
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 12,
    },
    retryText: {
        color: Colors.white,
        fontWeight: '600',
        fontSize: 15,
    },
});