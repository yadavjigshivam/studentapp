import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import * as Crypto from 'expo-crypto';
import { Platform } from 'react-native';
import {
    deleteSecureItem,
    getSecureItem,
    setSecureItem,
    TOKEN_KEYS,
} from '../utils/storage';

const DEFAULT_API =
    Platform.OS === 'android'
        ? 'http://10.0.2.2:3000/api/v1'
        : 'http://localhost:3000/api/v1';

export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || DEFAULT_API;

export const api = axios.create({
    baseURL: API_BASE_URL,
    timeout: 15000,
    headers: {
        'Content-Type': 'application/json',
    },
});

interface RetryConfig extends InternalAxiosRequestConfig {
    _retry?: boolean;
}

export function createIdempotencyKey(): string {
    return Crypto.randomUUID();
}

let onUnauthorizedCallback: (() => void) | null = null;
export function setUnauthorizedHandler(cb: () => void): void {
    onUnauthorizedCallback = cb;
}

api.interceptors.request.use(async (config) => {
    const token = await getSecureItem(TOKEN_KEYS.ACCESS);
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

api.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
        const original = error.config as RetryConfig | undefined;

        if (
            error.response?.status === 401 &&
            original &&
            !original._retry &&
            !original.url?.includes('/auth/login') &&
            !original.url?.includes('/auth/register') &&
            !original.url?.includes('/auth/refresh-token')
        ) {
            original._retry = true;
            const refreshToken = await getSecureItem(TOKEN_KEYS.REFRESH);

            if (refreshToken) {
                try {
                    const res = await axios.post(`${API_BASE_URL}/auth/refresh-token`, {
                        refreshToken,
                    });
                    const { accessToken, refreshToken: newRefreshToken } = res.data.data;

                    await setSecureItem(TOKEN_KEYS.ACCESS, accessToken);
                    await setSecureItem(TOKEN_KEYS.REFRESH, newRefreshToken);

                    original.headers.Authorization = `Bearer ${accessToken}`;
                    return api(original);
                } catch {
                    await deleteSecureItem(TOKEN_KEYS.ACCESS);
                    await deleteSecureItem(TOKEN_KEYS.REFRESH);
                    if (onUnauthorizedCallback) onUnauthorizedCallback();
                }
            } else if (onUnauthorizedCallback) {
                onUnauthorizedCallback();
            }
        }

        return Promise.reject(error);
    }
);

export function getApiErrorMessage(err: unknown, fallback = 'Something went wrong.'): string {
    if (err instanceof AxiosError) {
        const apiErr = err.response?.data?.error;
        if (apiErr?.details?.length) {
            return apiErr.details[0].issue || apiErr.message || fallback;
        }
        if (apiErr?.message) return apiErr.message;
        if (err.code === 'ECONNABORTED' || err.message === 'Network Error') {
            return 'Server se connection nahi ho paa raha. Check karein ki backend chal raha hai aur IP sahi hai.';
        }
    }
    if (err instanceof Error) return err.message;
    return fallback;
}