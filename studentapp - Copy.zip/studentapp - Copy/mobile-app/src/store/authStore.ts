import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { api, setUnauthorizedHandler } from '../services/api';
import {
    deleteSecureItem,
    getSecureItem,
    setSecureItem,
    TOKEN_KEYS,
} from '../utils/storage';

export interface EnrolledExam {
    enrollmentId: string;
    examinationId: string;
    name: string;
    slug: string;
    category: string | null;
    logoUrl: string | null;
    isPrimary: boolean;
    enrolledAt: string;
}

export interface StudentProfile {
    id: string;
    email: string;
    firstName: string;
    lastName?: string | null;
    displayName?: string | null;
    phone?: string | null;
    avatarUrl?: string | null;
    role: string;
    streak?: {
        currentStreak: number;
        longestStreak: number;
        lastActiveDate: string | null;
    };
    enrolledExaminations: EnrolledExam[];
}

interface RegisterPayload {
    firstName: string;
    lastName?: string;
    email: string;
    phone?: string;
    password: string;
    confirmPassword: string;
}

interface AuthState {
    user: StudentProfile | null;
    isAuthenticated: boolean;
    isBootstrapping: boolean;
    bootstrap: () => Promise<void>;
    refreshProfile: () => Promise<StudentProfile | null>;
    login: (email: string, password: string) => Promise<void>;
    register: (payload: RegisterPayload) => Promise<void>;
    logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => {
    setUnauthorizedHandler(() => {
        AsyncStorage.removeItem(TOKEN_KEYS.USER);
        set({ user: null, isAuthenticated: false });
    });

    return {
        user: null,
        isAuthenticated: false,
        isBootstrapping: true,

        bootstrap: async () => {
            try {
                const token = await getSecureItem(TOKEN_KEYS.ACCESS);
                if (!token) {
                    set({ user: null, isAuthenticated: false, isBootstrapping: false });
                    return;
                }
                const profile = await get().refreshProfile();
                set({
                    user: profile,
                    isAuthenticated: Boolean(profile),
                    isBootstrapping: false,
                });
            } catch {
                set({ user: null, isAuthenticated: false, isBootstrapping: false });
            }
        },

        refreshProfile: async () => {
            const res = await api.get('/users/me');
            const profile: StudentProfile = res.data.data;
            await AsyncStorage.setItem(TOKEN_KEYS.USER, JSON.stringify(profile));
            set({ user: profile, isAuthenticated: true });
            return profile;
        },

        login: async (email: string, password: string) => {
            const res = await api.post('/auth/login', {
                email: email.trim().toLowerCase(),
                password,
                deviceInfo: `Mobile App (${Platform.OS})`,
            });
            const { tokens } = res.data.data;
            await setSecureItem(TOKEN_KEYS.ACCESS, tokens.accessToken);
            await setSecureItem(TOKEN_KEYS.REFRESH, tokens.refreshToken);
            await get().refreshProfile();
        },

        register: async (payload: RegisterPayload) => {
            const res = await api.post('/auth/register', {
                ...payload,
                email: payload.email.trim().toLowerCase(),
                phone: payload.phone?.trim() || undefined,
                lastName: payload.lastName?.trim() || undefined,
            });
            const { tokens } = res.data.data;
            await setSecureItem(TOKEN_KEYS.ACCESS, tokens.accessToken);
            await setSecureItem(TOKEN_KEYS.REFRESH, tokens.refreshToken);
            await get().refreshProfile();
        },

        logout: async () => {
            const refreshToken = await getSecureItem(TOKEN_KEYS.REFRESH);
            try {
                if (refreshToken) {
                    await api.post('/auth/logout', { refreshToken });
                }
            } catch {
                // Ignore network errors during logout
            } finally {
                await deleteSecureItem(TOKEN_KEYS.ACCESS);
                await deleteSecureItem(TOKEN_KEYS.REFRESH);
                await AsyncStorage.removeItem(TOKEN_KEYS.USER);
                set({ user: null, isAuthenticated: false });
            }
        },
    };
});