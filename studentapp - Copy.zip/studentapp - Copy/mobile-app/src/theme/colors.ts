export const Colors = {
    // Brand & Gradients
    primary: '#4F46E5',       // Royal Indigo
    primaryDark: '#3730A3',
    primaryLight: '#EEF2FF',
    secondary: '#7C3AED',     // Vibrant Violet
    accentCyan: '#06B6D4',    // Fresh Cyan
    accentPink: '#EC4899',    // Bright Pink

    // Semantic Status
    success: '#10B981',       // Emerald Green
    successLight: '#ECFDF5',
    warning: '#F59E0B',       // Warm Amber
    warningLight: '#FFFBEB',
    danger: '#EF4444',        // Crisp Coral Red
    dangerLight: '#FEF2F2',

    // Neutrals
    bg: '#F8FAFC',
    surface: '#FFFFFF',
    surfaceAlt: '#F1F5F9',
    border: '#E2E8F0',
    text: '#0F172A',
    textSecondary: '#475569',
    textMuted: '#94A3B8',
    white: '#FFFFFF',
} as const;

export const Gradients = {
    hero: ['#4F46E5', '#7C3AED'] as readonly [string, string],
    study: ['#0284C7', '#06B6D4'] as readonly [string, string],
    practice: ['#059669', '#10B981'] as readonly [string, string],
    focus: ['#7C3AED', '#EC4899'] as readonly [string, string],
    streak: ['#EA580C', '#F59E0B'] as readonly [string, string],
    dark: ['#1E1B4B', '#312E81'] as readonly [string, string],
};

export const Shadows = {
    card: {
        shadowColor: '#1E293B',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.07,
        shadowRadius: 12,
        elevation: 3,
    },
    button: {
        shadowColor: '#4F46E5',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.25,
        shadowRadius: 10,
        elevation: 4,
    },
};