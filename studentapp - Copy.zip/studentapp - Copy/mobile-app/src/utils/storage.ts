import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const TOKEN_KEYS = {
    ACCESS: 'student_access_token',
    REFRESH: 'student_refresh_token',
    USER: 'student_user_profile',
    LOCAL_TIMER: 'student_local_study_timer',
} as const;

export async function setSecureItem(key: string, value: string): Promise<void> {
    if (Platform.OS === 'web') {
        await AsyncStorage.setItem(key, value);
        return;
    }
    await SecureStore.setItemAsync(key, value);
}

export async function getSecureItem(key: string): Promise<string | null> {
    if (Platform.OS === 'web') {
        return AsyncStorage.getItem(key);
    }
    return SecureStore.getItemAsync(key);
}

export async function deleteSecureItem(key: string): Promise<void> {
    if (Platform.OS === 'web') {
        await AsyncStorage.removeItem(key);
        return;
    }
    await SecureStore.deleteItemAsync(key);
}