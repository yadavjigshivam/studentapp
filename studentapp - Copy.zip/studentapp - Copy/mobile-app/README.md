# 📱 Mobile App — Multi-Exam Study Platform

> **Status:** Documentation Phase — No code yet.

## Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Framework | React Native + Expo | SDK 52+ |
| Language | TypeScript | 5.x |
| Navigation | expo-router | 4.x |
| State Management | Zustand | 5.x |
| HTTP Client | Axios | 1.x |
| Forms | React Hook Form + Zod | — |
| UI Library | React Native Paper | 5.x |
| Charts | react-native-chart-kit | — |
| Secure Storage | expo-secure-store | — |
| Background Tasks | expo-task-manager | — |
| Notifications | expo-notifications (future) | — |

## Project Structure (Planned)

```
mobile-app/
├── app/                           # expo-router file-based routing
│   ├── _layout.tsx                # Root layout
│   ├── index.tsx                  # Entry / splash
│   │
│   ├── (auth)/                    # Auth screens (unauthenticated)
│   │   ├── _layout.tsx
│   │   ├── login.tsx
│   │   ├── register.tsx
│   │   ├── forgot-password.tsx
│   │   └── reset-password.tsx
│   │
│   ├── (onboarding)/              # First-time setup
│   │   ├── _layout.tsx
│   │   ├── welcome.tsx
│   │   └── select-exam.tsx
│   │
│   ├── (tabs)/                    # Main tab navigator
│   │   ├── _layout.tsx            # Tab bar config
│   │   │
│   │   ├── home/                  # 🏠 Home Tab
│   │   │   ├── index.tsx          # Dashboard
│   │   │   └── daily-targets.tsx
│   │   │
│   │   ├── study/                 # 📖 Study Tab
│   │   │   ├── index.tsx          # Subject list
│   │   │   ├── [subjectId].tsx    # Chapters list
│   │   │   ├── chapter/
│   │   │   │   └── [chapterId].tsx  # Topics list
│   │   │   ├── topic/
│   │   │   │   └── [topicId].tsx  # Topic detail + notes
│   │   │   └── session/
│   │   │       └── [sessionId].tsx  # Active study session
│   │   │
│   │   ├── practice/              # ✏️ Practice Tab
│   │   │   ├── index.tsx          # Practice type selection
│   │   │   ├── configure.tsx      # Configure practice (select subject/topic/count)
│   │   │   ├── session/
│   │   │   │   └── [sessionId].tsx  # Question screen
│   │   │   ├── result/
│   │   │   │   └── [sessionId].tsx  # Practice results
│   │   │   └── review/
│   │   │       └── [sessionId].tsx  # Review answers
│   │   │
│   │   ├── performance/           # 📊 Performance Tab
│   │   │   ├── index.tsx          # Analytics overview
│   │   │   ├── subjects.tsx       # Subject-wise analysis
│   │   │   ├── topics.tsx         # Topic-wise analysis
│   │   │   ├── weak-areas.tsx     # Weak subjects/topics
│   │   │   └── history.tsx        # Daily progress history
│   │   │
│   │   └── profile/               # 👤 Profile Tab
│   │       ├── index.tsx          # Profile overview
│   │       ├── edit.tsx           # Edit profile
│   │       ├── examinations.tsx   # Manage selected exams
│   │       ├── bookmarks.tsx      # Bookmarked items
│   │       ├── focus-settings.tsx # Focus mode configuration
│   │       └── settings.tsx       # App settings
│   │
│   └── focus-mode/                # 🎯 Focus Mode (modal/overlay)
│       └── active.tsx             # Active focus session
│
├── components/                    # Reusable UI components
│   ├── ui/                        # Base UI elements
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Input.tsx
│   │   ├── Modal.tsx
│   │   ├── Badge.tsx
│   │   ├── ProgressBar.tsx
│   │   └── EmptyState.tsx
│   ├── dashboard/                 # Dashboard-specific components
│   │   ├── DailyStatsCard.tsx
│   │   ├── StreakBadge.tsx
│   │   ├── TargetProgress.tsx
│   │   └── QuickActions.tsx
│   ├── study/                     # Study-specific components
│   │   ├── StudyTimer.tsx
│   │   ├── SubjectCard.tsx
│   │   ├── TopicItem.tsx
│   │   └── SessionControls.tsx
│   ├── practice/                  # Practice-specific components
│   │   ├── QuestionCard.tsx
│   │   ├── OptionButton.tsx
│   │   ├── ExplanationBox.tsx
│   │   └── ResultSummary.tsx
│   └── charts/                    # Chart components
│       ├── AccuracyChart.tsx
│       ├── StudyTimeChart.tsx
│       └── StreakCalendar.tsx
│
├── hooks/                         # Custom React hooks
│   ├── useAuth.ts
│   ├── useStudyTimer.ts
│   ├── useFocusMode.ts
│   ├── usePracticeSession.ts
│   └── useDailyTargets.ts
│
├── services/                      # API service layer
│   ├── api.ts                     # Axios instance with interceptors
│   ├── auth.service.ts
│   ├── examination.service.ts
│   ├── subject.service.ts
│   ├── question.service.ts
│   ├── practice.service.ts
│   ├── studySession.service.ts
│   ├── dailyTarget.service.ts
│   ├── progress.service.ts
│   ├── bookmark.service.ts
│   └── focusMode.service.ts
│
├── store/                         # Zustand state stores
│   ├── authStore.ts
│   ├── examStore.ts
│   ├── studyStore.ts
│   ├── practiceStore.ts
│   ├── targetStore.ts
│   └── settingsStore.ts
│
├── types/                         # TypeScript type definitions
│   ├── auth.types.ts
│   ├── exam.types.ts
│   ├── question.types.ts
│   ├── study.types.ts
│   ├── progress.types.ts
│   └── api.types.ts
│
├── utils/                         # Utility functions
│   ├── formatters.ts              # Date, time, number formatting
│   ├── validators.ts              # Client-side validation
│   ├── storage.ts                 # Secure storage helpers
│   └── constants.ts               # App-wide constants
│
├── assets/                        # Static assets
│   ├── images/
│   ├── fonts/
│   └── icons/
│
├── app.json                       # Expo configuration
├── tsconfig.json
├── babel.config.js
├── package.json
└── README.md
```

## Setup Instructions (To Be Executed After Plan Approval)

### Prerequisites

- Node.js 20 LTS
- pnpm
- Expo CLI (`npx expo`)
- Android Studio (for emulator) or physical Android device with Expo Go
- Git

### Installation Steps

```bash
# 1. Navigate to mobile-app directory
cd mobile-app

# 2. Install dependencies
pnpm install

# 3. Create environment configuration
cp .env.example .env

# 4. Update .env with backend API URL
#    EXPO_PUBLIC_API_URL="http://localhost:3000/api/v1"

# 5. Start Expo development server
pnpm start

# 6. Press 'a' to open on Android emulator
#    OR scan QR code with Expo Go on physical device
```

### Available Scripts

| Script | Description |
|--------|-------------|
| `pnpm start` | Start Expo development server |
| `pnpm android` | Start on Android emulator |
| `pnpm test` | Run test suite |
| `pnpm lint` | Run ESLint |
| `pnpm build:apk` | Build Android APK (via EAS) |
| `pnpm build:aab` | Build Android App Bundle (via EAS) |

### Bottom Tab Navigation

| Tab | Icon | Primary Screen |
|-----|------|---------------|
| 🏠 Home | `home` | Daily dashboard & targets |
| 📖 Study | `book-open` | Subjects → Chapters → Topics |
| ✏️ Practice | `edit-3` | Practice questions & quizzes |
| 📊 Performance | `bar-chart-2` | Analytics & weak areas |
| 👤 Profile | `user` | Settings, bookmarks, exams |

### Key Design Patterns

1. **Study Timer** — Timestamp-based (not interval-based) for accuracy across app states
2. **API Layer** — Axios interceptors auto-refresh expired JWT tokens
3. **Token Storage** — expo-secure-store for production, AsyncStorage for dev
4. **State** — Zustand stores with persist middleware for offline resilience
5. **Navigation** — expo-router with typed routes and deep linking support

### Focus Mode Native Modules (Planned)

The Focus Mode feature requires custom native Android modules for:
- `UsageStatsManager` — detecting foreground app
- `SYSTEM_ALERT_WINDOW` — showing overlay reminders
- `NotificationManager` — enabling DND mode

See [Focus Mode Feasibility](../docs/05-focus-mode-feasibility.md) for implementation details.

## Documentation

- [Product Requirements](../docs/01-product-requirements.md)
- [UI/UX Specifications](../docs/04-tech-stack-architecture.md)
- [Focus Mode Feasibility](../docs/05-focus-mode-feasibility.md)
- [Testing Plan](../docs/06-testing-and-security.md)

