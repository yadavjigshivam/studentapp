import { PrismaClient, UserRole, DifficultyLevel, QuestionType } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
    console.log('🌱 Starting database seeding...');

    // 1. Seed App Configurations
    const configs = [
        { configKey: 'min_app_version', configValue: '1.0.0', configType: 'string', description: 'Minimum supported Android version' },
        { configKey: 'latest_app_version', configValue: '1.0.0', configType: 'string', description: 'Latest available Android version' },
        { configKey: 'force_update', configValue: 'false', configType: 'boolean', description: 'Force app update dialog' },
        { configKey: 'maintenance_mode', configValue: 'false', configType: 'boolean', description: 'Global maintenance mode' },
        { configKey: 'maintenance_message', configValue: 'We are upgrading our servers. Please check back shortly.', configType: 'string', description: 'Maintenance banner text' },
        { configKey: 'support_email', configValue: 'support@studyplatform.in', configType: 'string', description: 'Student helpdesk email' },
    ];

    for (const cfg of configs) {
        await prisma.appConfig.upsert({
            where: { configKey: cfg.configKey },
            update: cfg,
            create: cfg,
        });
    }
    console.log('✅ App configurations seeded.');

    // 2. Seed Super Admin & Sample Student
    const adminPasswordHash = await bcrypt.hash('Admin@2026', 12);
    const studentPasswordHash = await bcrypt.hash('Student@2026', 12);

    const superAdmin = await prisma.user.upsert({
        where: { email: 'admin@studyapp.com' },
        update: {},
        create: {
            email: 'admin@studyapp.com',
            passwordHash: adminPasswordHash,
            firstName: 'Super',
            lastName: 'Admin',
            displayName: 'Platform Super Admin',
            role: UserRole.super_admin,
            isActive: true,
            isEmailVerified: true,
        },
    });

    const sampleStudent = await prisma.user.upsert({
        where: { email: 'student@studyapp.com' },
        update: {},
        create: {
            email: 'student@studyapp.com',
            passwordHash: studentPasswordHash,
            firstName: 'Rahul',
            lastName: 'Sharma',
            displayName: 'Rahul Sharma',
            role: UserRole.student,
            isActive: true,
            isEmailVerified: true,
        },
    });
    console.log('✅ Users seeded (Admin: admin@studyapp.com / Admin@2026 | Student: student@studyapp.com / Student@2026)');

    // 3. Seed Examinations
    const superTet = await prisma.examination.upsert({
        where: { slug: 'up-super-tet' },
        update: {},
        create: {
            name: 'UP Super TET',
            slug: 'up-super-tet',
            description: 'Uttar Pradesh Assistant Teacher Recruitment Examination',
            category: 'Teaching',
            language: 'bilingual',
            instructions: '150 Questions, 150 Marks, No Negative Marking.',
            isActive: true,
            displayOrder: 1,
        },
    });

    const rrbNtpc = await prisma.examination.upsert({
        where: { slug: 'rrb-ntpc' },
        update: {},
        create: {
            name: 'RRB NTPC',
            slug: 'rrb-ntpc',
            description: 'Railway Recruitment Board Non-Technical Popular Categories',
            category: 'Railway',
            language: 'bilingual',
            instructions: '100 Questions, 90 Minutes, 1/3 Negative Marking.',
            isActive: true,
            displayOrder: 2,
        },
    });

    // Enroll sample student in UP Super TET as primary
    await prisma.userExamination.upsert({
        where: {
            userId_examinationId: {
                userId: sampleStudent.id,
                examinationId: superTet.id,
            },
        },
        update: { isPrimary: true },
        create: {
            userId: sampleStudent.id,
            examinationId: superTet.id,
            isPrimary: true,
        },
    });

    // 4. Seed Syllabus Version
    await prisma.syllabusVersion.upsert({
        where: {
            examinationId_versionCode: {
                examinationId: superTet.id,
                versionCode: '2026.1',
            },
        },
        update: {},
        create: {
            examinationId: superTet.id,
            versionCode: '2026.1',
            title: 'UP Super TET Official Syllabus 2026',
            changelog: 'Initial comprehensive syllabus structure.',
            isActive: true,
            publishedAt: new Date(),
            createdBy: superAdmin.id,
        },
    });

    // 5. Seed Subjects, Chapters, Topics & Study Notes for UP Super TET
    const cdpSubject = await prisma.subject.upsert({
        where: { examinationId_slug: { examinationId: superTet.id, slug: 'child-development-pedagogy' } },
        update: {},
        create: {
            examinationId: superTet.id,
            name: 'Child Development & Pedagogy',
            slug: 'child-development-pedagogy',
            description: 'Child psychology, learning theories, and inclusive pedagogy.',
            displayOrder: 1,
            isActive: true,
        },
    });

    const hindiSubject = await prisma.subject.upsert({
        where: { examinationId_slug: { examinationId: superTet.id, slug: 'hindi-language' } },
        update: {},
        create: {
            examinationId: superTet.id,
            name: 'Hindi (हिन्दी)',
            slug: 'hindi-language',
            description: 'हिन्दी व्याकरण एवं अपठित गद्यांश',
            displayOrder: 2,
            isActive: true,
        },
    });

    const cdpChapter1 = await prisma.chapter.upsert({
        where: { subjectId_slug: { subjectId: cdpSubject.id, slug: 'theories-of-child-development' } },
        update: {},
        create: {
            subjectId: cdpSubject.id,
            name: 'Theories of Child Development',
            slug: 'theories-of-child-development',
            description: 'Piaget, Vygotsky, and Kohlberg developmental theories.',
            displayOrder: 1,
            isActive: true,
        },
    });

    const cdpTopic1 = await prisma.topic.upsert({
        where: { chapterId_slug: { chapterId: cdpChapter1.id, slug: 'piagets-cognitive-development' } },
        update: {},
        create: {
            chapterId: cdpChapter1.id,
            name: "Piaget's Cognitive Development Theory",
            slug: 'piagets-cognitive-development',
            description: 'Four stages of cognitive development and schemas.',
            estimatedStudyTimeMinutes: 45,
            displayOrder: 1,
            isActive: true,
        },
    });

    // Seed Study Note
    const existingNote = await prisma.studyNote.findFirst({ where: { topicId: cdpTopic1.id } });
    if (!existingNote) {
        await prisma.studyNote.create({
            data: {
                topicId: cdpTopic1.id,
                title: "Piaget's 4 Stages of Cognitive Development",
                summary: 'Quick revision note on Sensorimotor, Preoperational, Concrete Operational, and Formal Operational stages.',
                contentEn: '### 1. Sensorimotor Stage (0–2 Years)\n- Infants learn through senses and motor actions.\n- **Object Permanence** develops around 8–9 months.\n\n### 2. Preoperational Stage (2–7 Years)\n- Symbolic thought develops; egocentrism is prominent; lack of conservation.',
                contentHi: '### 1. संवेदी-गामक अवस्था (0–2 वर्ष)\n- शिशु अपनी इंद्रियों और शारीरिक क्रियाओं के माध्यम से सीखते हैं।\n- **वस्तु स्थायित्व (Object Permanence)** लगभग 8-9 महीने में विकसित होता है।\n\n### 2. पूर्व-संक्रियात्मक अवस्था (2–7 वर्ष)\n- प्रतीकात्मक विचार विकसित होता है; अहं-केंद्रितता (Egocentrism) प्रमुख होती है।',
                isPublished: true,
                displayOrder: 1,
            },
        });
    }

    // 6. Seed Sample Questions
    const existingQuestions = await prisma.question.count({ where: { topicId: cdpTopic1.id } });
    if (existingQuestions === 0) {
        await prisma.question.create({
            data: {
                examinationId: superTet.id,
                subjectId: cdpSubject.id,
                chapterId: cdpChapter1.id,
                topicId: cdpTopic1.id,
                questionTextEn: 'At which stage of cognitive development does a child develop object permanence according to Jean Piaget?',
                questionTextHi: 'जीन पियाजे के अनुसार संज्ञानात्मक विकास के किस चरण में बच्चा वस्तु स्थायित्व (Object Permanence) विकसित करता है?',
                questionType: QuestionType.single_correct_mcq,
                difficultyLevel: DifficultyLevel.easy,
                explanationEn: 'Object permanence—the understanding that objects continue to exist even when they cannot be seen—develops during the Sensorimotor stage (0–2 years).',
                explanationHi: 'वस्तु स्थायित्व का विकास संवेदी-गामक अवस्था (0–2 वर्ष) के दौरान होता है।',
                source: 'UP Super TET Previous Year',
                isPublished: true,
                createdBy: superAdmin.id,
                options: {
                    create: [
                        { optionTextEn: 'Sensorimotor Stage', optionTextHi: 'संवेदी-गामक अवस्था', isCorrect: true, displayOrder: 1 },
                        { optionTextEn: 'Preoperational Stage', optionTextHi: 'पूर्व-संक्रियात्मक अवस्था', isCorrect: false, displayOrder: 2 },
                        { optionTextEn: 'Concrete Operational Stage', optionTextHi: 'मूर्त-संक्रियात्मक अवस्था', isCorrect: false, displayOrder: 3 },
                        { optionTextEn: 'Formal Operational Stage', optionTextHi: 'औपचारिक संक्रियात्मक अवस्था', isCorrect: false, displayOrder: 4 },
                    ],
                },
            },
        });

        await prisma.question.create({
            data: {
                examinationId: superTet.id,
                subjectId: cdpSubject.id,
                chapterId: cdpChapter1.id,
                topicId: cdpTopic1.id,
                questionTextEn: 'Who proposed the Socio-Cultural Theory of cognitive development?',
                questionTextHi: 'संज्ञानात्मक विकास का सामाजिक-सांस्कृतिक सिद्धांत किसने प्रतिपादित किया?',
                questionType: QuestionType.single_correct_mcq,
                difficultyLevel: DifficultyLevel.easy,
                explanationEn: 'Lev Vygotsky proposed the Socio-Cultural Theory emphasizing ZPD (Zone of Proximal Development) and Scaffolding.',
                explanationHi: 'लेव वायगोत्स्की ने सामाजिक-सांस्कृतिक सिद्धांत प्रतिपादित किया जिसमें ZPD और पाड़ (Scaffolding) पर जोर दिया गया है।',
                source: 'CTET 2024',
                isPublished: true,
                createdBy: superAdmin.id,
                options: {
                    create: [
                        { optionTextEn: 'Jean Piaget', optionTextHi: 'जीन पियाजे', isCorrect: false, displayOrder: 1 },
                        { optionTextEn: 'Lev Vygotsky', optionTextHi: 'लेव वायगोत्स्की', isCorrect: true, displayOrder: 2 },
                        { optionTextEn: 'Lawrence Kohlberg', optionTextHi: 'लॉरेंस कोहलबर्ग', isCorrect: false, displayOrder: 3 },
                        { optionTextEn: 'B.F. Skinner', optionTextHi: 'बी.एफ. स्किनर', isCorrect: false, displayOrder: 4 },
                    ],
                },
            },
        });
    }

    console.log('🎉 Database seeding completed successfully!');
}

main()
    .catch((e) => {
        console.error('❌ Seeding failed:', e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });