import app from './app';
import { env } from './config/env';
import { prisma } from './config/database';
import { logger } from './shared/utils/logger';

async function bootstrap() {
    try {
        await prisma.$connect();
        logger.info('✅ Connected to PostgreSQL database successfully.');

        const server = app.listen(env.PORT, () => {
            logger.info(`🚀 Multi-Exam Study Platform API running on http://localhost:${env.PORT}/api/v1`);
            logger.info(`🩺 Health check available at http://localhost:${env.PORT}/health`);
        });

        const shutdown = async (signal: string) => {
            logger.info(`Received ${signal}. Closing HTTP server and database connection...`);
            server.close(async () => {
                await prisma.$disconnect();
                process.exit(0);
            });
        };

        process.on('SIGINT', () => shutdown('SIGINT'));
        process.on('SIGTERM', () => shutdown('SIGTERM'));
    } catch (error) {
        logger.error('❌ Failed to start server:', error);
        await prisma.$disconnect();
        process.exit(1);
    }
}

bootstrap();