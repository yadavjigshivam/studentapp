import { Router, Request, Response } from 'express';
import multer from 'multer';
import * as XLSX from 'xlsx';
import {
    UserRole,
    DifficultyLevel,
    QuestionType,
    QuizType,
    ImportJobStatus,
    Prisma,
} from '@prisma/client';
import bcrypt from 'bcrypt';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { authorize } from '../../middleware/authorize';
import { asyncHandler, buildPagination, sendSuccess } from '../../shared/utils/response';
import { BadRequestError, ConflictError, NotFoundError } from '../../shared/errors/AppError';

const router = Router();

const bulkUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 },
});

// Helper to record admin actions in admin_audit_logs
async function logAdminAudit(params: {
    req: Request;
    action: string;
    entityType: string;
    entityId?: string | null;
    oldValues?: unknown;
    newValues?: unknown;
}): Promise<void> {
    if (!params.req.user) return;
    await prisma.adminAuditLog.create({
        data: {
            adminUserId: params.req.user.id,
            action: params.action,
            entityType: params.entityType,
            entityId: params.entityId || null,
            oldValues: params.oldValues ? (params.oldValues as Prisma.InputJsonValue) : Prisma.DbNull,
            newValues: params.newValues ? (params.newValues as Prisma.InputJsonValue) : Prisma.DbNull,
            ipAddress: params.req.ip || null,
        },
    });
}

// Require authentication on all admin routes
router.use(authenticate);

// ==========================================
// 1. ADMIN DASHBOARD OVERVIEW
// ==========================================
router.get(
    '/dashboard',
    authorize([
        UserRole.super_admin,
        UserRole.content_admin,
        UserRole.question_manager,
        UserRole.student_support,
    ]),
    asyncHandler(async (_req: Request, res: Response) => {
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

        const [
            totalStudents,
            activeStudentsPast30Days,
            totalExaminations,
            totalSubjects,
            totalTopics,
            totalQuestions,
            totalStudyNotes,
            totalQuizzes,
            pendingImportJobs,
            recentLogs,
        ] = await Promise.all([
            prisma.user.count({ where: { role: UserRole.student } }),
            prisma.user.count({
                where: { role: UserRole.student, lastLoginAt: { gte: thirtyDaysAgo } },
            }),
            prisma.examination.count(),
            prisma.subject.count(),
            prisma.topic.count(),
            prisma.question.count(),
            prisma.studyNote.count(),
            prisma.quiz.count(),
            prisma.contentImportJob.count({
                where: { status: { in: [ImportJobStatus.pending, ImportJobStatus.processing] } },
            }),
            prisma.userActivityLog.findMany({
                take: 15,
                orderBy: { createdAt: 'desc' },
                include: {
                    user: { select: { id: true, displayName: true, email: true } },
                },
            }),
        ]);

        sendSuccess(res, {
            summaryCounts: {
                totalStudents,
                activeStudentsPast30Days,
                totalExaminations,
                totalSubjects,
                totalTopics,
                totalQuestions,
                totalStudyNotes,
                totalQuizzes,
                pendingImportJobs,
            },
            recentActivity: recentLogs.map((log) => ({
                id: log.id,
                type: log.activityType,
                studentName: log.user.displayName || log.user.email,
                metadata: log.metadata,
                timestamp: log.createdAt,
            })),
        });
    })
);

// ==========================================
// 2. EXAMINATION MANAGEMENT
// ==========================================
router.get(
    '/examinations',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (_req: Request, res: Response) => {
        const exams = await prisma.examination.findMany({
            include: {
                _count: {
                    select: { subjects: true, questions: true, userExaminations: true },
                },
            },
            orderBy: [{ displayOrder: 'asc' }, { createdAt: 'desc' }],
        });
        sendSuccess(res, exams);
    })
);

router.post(
    '/examinations',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { name, slug, description, logoUrl, category, language, instructions, isActive, displayOrder } = req.body;
        if (!name || !slug) {
            throw new BadRequestError('Examination name and slug are required.');
        }

        const exam = await prisma.examination.create({
            data: {
                name: String(name).trim(),
                slug: String(slug).trim().toLowerCase(),
                description: description || null,
                logoUrl: logoUrl || null,
                category: category || null,
                language: language || 'bilingual',
                instructions: instructions || null,
                isActive: isActive !== false,
                displayOrder: Number(displayOrder) || 0,
            },
        });

        await logAdminAudit({
            req,
            action: 'create',
            entityType: 'examination',
            entityId: exam.id,
            newValues: exam,
        });

        sendSuccess(res, exam, 'Examination created successfully', 201);
    })
);

router.put(
    '/examinations/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.examination.findUnique({ where: { id } });
        if (!existing) throw new NotFoundError('Examination not found.');

        const updated = await prisma.examination.update({
            where: { id },
            data: {
                name: req.body.name !== undefined ? String(req.body.name).trim() : existing.name,
                slug: req.body.slug !== undefined ? String(req.body.slug).trim().toLowerCase() : existing.slug,
                description: req.body.description !== undefined ? req.body.description : existing.description,
                logoUrl: req.body.logoUrl !== undefined ? req.body.logoUrl : existing.logoUrl,
                category: req.body.category !== undefined ? req.body.category : existing.category,
                language: req.body.language !== undefined ? req.body.language : existing.language,
                instructions: req.body.instructions !== undefined ? req.body.instructions : existing.instructions,
                isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : existing.isActive,
                displayOrder:
                    req.body.displayOrder !== undefined ? Number(req.body.displayOrder) : existing.displayOrder,
            },
        });

        await logAdminAudit({
            req,
            action: 'update',
            entityType: 'examination',
            entityId: updated.id,
            oldValues: existing,
            newValues: updated,
        });

        sendSuccess(res, updated, 'Examination updated successfully');
    })
);

router.delete(
    '/examinations/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const enrolledCount = await prisma.userExamination.count({ where: { examinationId: id } });
        if (enrolledCount > 0) {
            throw new ConflictError(
                `Cannot delete examination because ${enrolledCount} students are enrolled. Deactivate it instead.`
            );
        }

        const deleted = await prisma.examination.delete({ where: { id } });
        await logAdminAudit({
            req,
            action: 'delete',
            entityType: 'examination',
            entityId: id,
            oldValues: deleted,
        });

        sendSuccess(res, null, 'Examination deleted successfully');
    })
);

// ==========================================
// 3. SUBJECT, CHAPTER, TOPIC & NOTES CRUD
// ==========================================
router.get(
    '/subjects',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const examinationId =
            typeof req.query.examinationId === 'string' ? req.query.examinationId : undefined;
        const subjects = await prisma.subject.findMany({
            where: { ...(examinationId ? { examinationId } : {}) },
            include: {
                examination: { select: { id: true, name: true } },
                _count: { select: { chapters: true, questions: true } },
            },
            orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }],
        });
        sendSuccess(res, subjects);
    })
);

router.post(
    '/subjects',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { examinationId, name, slug, description, iconUrl, displayOrder, isActive } = req.body;
        if (!examinationId || !name || !slug) {
            throw new BadRequestError('examinationId, name, and slug are required.');
        }

        const subject = await prisma.subject.create({
            data: {
                examinationId: String(examinationId),
                name: String(name).trim(),
                slug: String(slug).trim().toLowerCase(),
                description: description || null,
                iconUrl: iconUrl || null,
                displayOrder: Number(displayOrder) || 0,
                isActive: isActive !== false,
            },
        });

        await logAdminAudit({ req, action: 'create', entityType: 'subject', entityId: subject.id, newValues: subject });
        sendSuccess(res, subject, 'Subject created successfully', 201);
    })
);

router.put(
    '/subjects/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.subject.findUnique({ where: { id } });
        if (!existing) throw new NotFoundError('Subject not found.');

        const updated = await prisma.subject.update({
            where: { id },
            data: {
                name: req.body.name !== undefined ? String(req.body.name).trim() : existing.name,
                slug: req.body.slug !== undefined ? String(req.body.slug).trim().toLowerCase() : existing.slug,
                description: req.body.description !== undefined ? req.body.description : existing.description,
                iconUrl: req.body.iconUrl !== undefined ? req.body.iconUrl : existing.iconUrl,
                displayOrder: req.body.displayOrder !== undefined ? Number(req.body.displayOrder) : existing.displayOrder,
                isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : existing.isActive,
            },
        });

        await logAdminAudit({ req, action: 'update', entityType: 'subject', entityId: id, oldValues: existing, newValues: updated });
        sendSuccess(res, updated, 'Subject updated successfully');
    })
);

router.delete(
    '/subjects/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        await prisma.subject.delete({ where: { id } });
        await logAdminAudit({ req, action: 'delete', entityType: 'subject', entityId: id });
        sendSuccess(res, null, 'Subject deleted');
    })
);

// CHAPTERS
router.get(
    '/chapters',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const subjectId = typeof req.query.subjectId === 'string' ? req.query.subjectId : undefined;
        const chapters = await prisma.chapter.findMany({
            where: { ...(subjectId ? { subjectId } : {}) },
            include: {
                subject: { select: { id: true, name: true, examinationId: true } },
                _count: { select: { topics: true, questions: true } },
            },
            orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }],
        });
        sendSuccess(res, chapters);
    })
);

router.post(
    '/chapters',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { subjectId, name, slug, description, displayOrder, isActive } = req.body;
        if (!subjectId || !name || !slug) {
            throw new BadRequestError('subjectId, name, and slug are required.');
        }

        const chapter = await prisma.chapter.create({
            data: {
                subjectId: String(subjectId),
                name: String(name).trim(),
                slug: String(slug).trim().toLowerCase(),
                description: description || null,
                displayOrder: Number(displayOrder) || 0,
                isActive: isActive !== false,
            },
        });

        await logAdminAudit({ req, action: 'create', entityType: 'chapter', entityId: chapter.id, newValues: chapter });
        sendSuccess(res, chapter, 'Chapter created successfully', 201);
    })
);

router.put(
    '/chapters/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.chapter.findUnique({ where: { id } });
        if (!existing) throw new NotFoundError('Chapter not found.');

        const updated = await prisma.chapter.update({
            where: { id },
            data: {
                name: req.body.name !== undefined ? String(req.body.name).trim() : existing.name,
                slug: req.body.slug !== undefined ? String(req.body.slug).trim().toLowerCase() : existing.slug,
                description: req.body.description !== undefined ? req.body.description : existing.description,
                displayOrder: req.body.displayOrder !== undefined ? Number(req.body.displayOrder) : existing.displayOrder,
                isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : existing.isActive,
            },
        });

        await logAdminAudit({ req, action: 'update', entityType: 'chapter', entityId: id, oldValues: existing, newValues: updated });
        sendSuccess(res, updated, 'Chapter updated');
    })
);

router.delete(
    '/chapters/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        await prisma.chapter.delete({ where: { id } });
        await logAdminAudit({ req, action: 'delete', entityType: 'chapter', entityId: id });
        sendSuccess(res, null, 'Chapter deleted');
    })
);

// TOPICS
router.get(
    '/topics',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const chapterId = typeof req.query.chapterId === 'string' ? req.query.chapterId : undefined;
        const topics = await prisma.topic.findMany({
            where: { ...(chapterId ? { chapterId } : {}) },
            include: {
                chapter: { select: { id: true, name: true, subjectId: true } },
                _count: { select: { studyNotes: true, questions: true } },
            },
            orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }],
        });
        sendSuccess(res, topics);
    })
);

router.post(
    '/topics',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { chapterId, name, slug, description, estimatedStudyTimeMinutes, displayOrder, isActive } = req.body;
        if (!chapterId || !name || !slug) {
            throw new BadRequestError('chapterId, name, and slug are required.');
        }

        const topic = await prisma.topic.create({
            data: {
                chapterId: String(chapterId),
                name: String(name).trim(),
                slug: String(slug).trim().toLowerCase(),
                description: description || null,
                estimatedStudyTimeMinutes: estimatedStudyTimeMinutes ? Number(estimatedStudyTimeMinutes) : null,
                displayOrder: Number(displayOrder) || 0,
                isActive: isActive !== false,
            },
        });

        await logAdminAudit({ req, action: 'create', entityType: 'topic', entityId: topic.id, newValues: topic });
        sendSuccess(res, topic, 'Topic created successfully', 201);
    })
);

router.put(
    '/topics/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.topic.findUnique({ where: { id } });
        if (!existing) throw new NotFoundError('Topic not found.');

        const updated = await prisma.topic.update({
            where: { id },
            data: {
                name: req.body.name !== undefined ? String(req.body.name).trim() : existing.name,
                slug: req.body.slug !== undefined ? String(req.body.slug).trim().toLowerCase() : existing.slug,
                description: req.body.description !== undefined ? req.body.description : existing.description,
                estimatedStudyTimeMinutes:
                    req.body.estimatedStudyTimeMinutes !== undefined
                        ? Number(req.body.estimatedStudyTimeMinutes)
                        : existing.estimatedStudyTimeMinutes,
                displayOrder: req.body.displayOrder !== undefined ? Number(req.body.displayOrder) : existing.displayOrder,
                isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : existing.isActive,
            },
        });

        await logAdminAudit({ req, action: 'update', entityType: 'topic', entityId: id, oldValues: existing, newValues: updated });
        sendSuccess(res, updated, 'Topic updated');
    })
);

router.delete(
    '/topics/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        await prisma.topic.delete({ where: { id } });
        await logAdminAudit({ req, action: 'delete', entityType: 'topic', entityId: id });
        sendSuccess(res, null, 'Topic deleted');
    })
);

// STUDY NOTES CRUD
router.get(
    '/notes',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const topicId = typeof req.query.topicId === 'string' ? req.query.topicId : undefined;
        const notes = await prisma.studyNote.findMany({
            where: { ...(topicId ? { topicId } : {}) },
            include: { topic: { select: { id: true, name: true } } },
            orderBy: [{ displayOrder: 'asc' }, { createdAt: 'desc' }],
        });
        sendSuccess(res, notes);
    })
);

router.post(
    '/notes',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { topicId, title, contentEn, contentHi, summary, imageUrls, isPublished, displayOrder } = req.body;
        if (!topicId || !title) {
            throw new BadRequestError('topicId and title are required.');
        }

        const note = await prisma.studyNote.create({
            data: {
                topicId: String(topicId),
                title: String(title).trim(),
                contentEn: contentEn || null,
                contentHi: contentHi || null,
                summary: summary || null,
                imageUrls: imageUrls || [],
                isPublished: Boolean(isPublished),
                displayOrder: Number(displayOrder) || 0,
            },
        });

        await logAdminAudit({ req, action: 'create', entityType: 'study_note', entityId: note.id, newValues: note });
        sendSuccess(res, note, 'Study note created', 201);
    })
);

router.put(
    '/notes/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.studyNote.findUnique({ where: { id } });
        if (!existing) throw new NotFoundError('Study note not found.');

        const updated = await prisma.studyNote.update({
            where: { id },
            data: {
                title: req.body.title !== undefined ? String(req.body.title).trim() : existing.title,
                contentEn: req.body.contentEn !== undefined ? req.body.contentEn : existing.contentEn,
                contentHi: req.body.contentHi !== undefined ? req.body.contentHi : existing.contentHi,
                summary: req.body.summary !== undefined ? req.body.summary : existing.summary,
                imageUrls: req.body.imageUrls !== undefined ? req.body.imageUrls : (existing.imageUrls ?? []),
                isPublished: req.body.isPublished !== undefined ? Boolean(req.body.isPublished) : existing.isPublished,
                displayOrder: req.body.displayOrder !== undefined ? Number(req.body.displayOrder) : existing.displayOrder,
            },
        });

        await logAdminAudit({ req, action: 'update', entityType: 'study_note', entityId: id, oldValues: existing, newValues: updated });
        sendSuccess(res, updated, 'Study note updated');
    })
);

router.delete(
    '/notes/:id',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        await prisma.studyNote.delete({ where: { id } });
        await logAdminAudit({ req, action: 'delete', entityType: 'study_note', entityId: id });
        sendSuccess(res, null, 'Study note deleted');
    })
);

// SYLLABUS VERSION CRUD
router.post(
    '/syllabus',
    authorize([UserRole.super_admin, UserRole.content_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { examinationId, versionCode, title, changelog, fileUrl, isActive } = req.body;
        if (!examinationId || !versionCode || !title) {
            throw new BadRequestError('examinationId, versionCode, and title are required.');
        }

        const syllabus = await prisma.syllabusVersion.create({
            data: {
                examinationId: String(examinationId),
                versionCode: String(versionCode).trim(),
                title: String(title).trim(),
                changelog: changelog || null,
                fileUrl: fileUrl || null,
                isActive: isActive !== false,
                publishedAt: isActive !== false ? new Date() : null,
                createdBy: req.user!.id,
            },
        });

        await logAdminAudit({ req, action: 'create', entityType: 'syllabus', entityId: syllabus.id, newValues: syllabus });
        sendSuccess(res, syllabus, 'Syllabus version created', 201);
    })
);

// ==========================================
// 4. QUESTION BANK & BULK CSV/XLSX IMPORT
// ==========================================
router.get(
    '/questions',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const page = Math.max(1, Number(req.query.page) || 1);
        const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
        const examinationId = typeof req.query.examinationId === 'string' ? req.query.examinationId : undefined;
        const subjectId = typeof req.query.subjectId === 'string' ? req.query.subjectId : undefined;
        const topicId = typeof req.query.topicId === 'string' ? req.query.topicId : undefined;
        const isPublished =
            req.query.isPublished === 'true' ? true : req.query.isPublished === 'false' ? false : undefined;

        const where = {
            ...(examinationId ? { examinationId } : {}),
            ...(subjectId ? { subjectId } : {}),
            ...(topicId ? { topicId } : {}),
            ...(isPublished !== undefined ? { isPublished } : {}),
        };

        const [totalRecords, questions] = await Promise.all([
            prisma.question.count({ where }),
            prisma.question.findMany({
                where,
                include: {
                    options: { orderBy: { displayOrder: 'asc' } },
                    subject: { select: { id: true, name: true } },
                    topic: { select: { id: true, name: true } },
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);

        sendSuccess(
            res,
            questions,
            'Questions fetched',
            200,
            buildPagination(page, limit, totalRecords)
        );
    })
);

router.post(
    '/questions',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const {
            examinationId,
            subjectId,
            chapterId,
            topicId,
            questionTextEn,
            questionTextHi,
            questionImageUrl,
            questionType = QuestionType.single_correct_mcq,
            difficultyLevel = DifficultyLevel.medium,
            explanationEn,
            explanationHi,
            explanationImageUrl,
            source,
            language = 'bilingual',
            marks = 1.0,
            negativeMarks = 0.0,
            options,
            isPublished = false,
        } = req.body;

        if (!subjectId || !questionTextEn || !Array.isArray(options) || options.length < 2) {
            throw new BadRequestError('subjectId, questionTextEn, and at least 2 options are required.');
        }

        const correctCount = options.filter((o: { isCorrect?: boolean }) => Boolean(o.isCorrect)).length;
        if (questionType === QuestionType.single_correct_mcq && correctCount !== 1) {
            throw new BadRequestError('Exactly one option must be marked correct for single_correct_mcq.');
        }

        const question = await prisma.question.create({
            data: {
                examinationId: examinationId || null,
                subjectId: String(subjectId),
                chapterId: chapterId || null,
                topicId: topicId || null,
                questionTextEn: String(questionTextEn).trim(),
                questionTextHi: questionTextHi ? String(questionTextHi).trim() : null,
                questionImageUrl: questionImageUrl || null,
                questionType,
                difficultyLevel,
                explanationEn: explanationEn || null,
                explanationHi: explanationHi || null,
                explanationImageUrl: explanationImageUrl || null,
                source: source || null,
                language,
                marks: Number(marks),
                negativeMarks: Number(negativeMarks),
                isPublished: Boolean(isPublished),
                createdBy: req.user!.id,
                options: {
                    create: options.map(
                        (
                            opt: {
                                optionTextEn: string;
                                optionTextHi?: string;
                                optionImageUrl?: string;
                                isCorrect?: boolean;
                                displayOrder?: number;
                            },
                            idx: number
                        ) => ({
                            optionTextEn: String(opt.optionTextEn).trim(),
                            optionTextHi: opt.optionTextHi ? String(opt.optionTextHi).trim() : null,
                            optionImageUrl: opt.optionImageUrl || null,
                            isCorrect: Boolean(opt.isCorrect),
                            displayOrder: opt.displayOrder ?? idx + 1,
                        })
                    ),
                },
            },
            include: { options: true },
        });

        await logAdminAudit({
            req,
            action: 'create',
            entityType: 'question',
            entityId: question.id,
            newValues: { questionId: question.id, isPublished: question.isPublished },
        });

        sendSuccess(
            res,
            {
                questionId: question.id,
                isPublished: question.isPublished,
                optionsCount: question.options.length,
                question,
            },
            'Question created successfully',
            201
        );
    })
);

router.put(
    '/questions/:id',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.question.findUnique({
            where: { id },
            include: { options: true },
        });
        if (!existing) throw new NotFoundError('Question not found.');

        const updated = await prisma.question.update({
            where: { id },
            data: {
                questionTextEn: req.body.questionTextEn ?? existing.questionTextEn,
                questionTextHi: req.body.questionTextHi !== undefined ? req.body.questionTextHi : existing.questionTextHi,
                questionImageUrl: req.body.questionImageUrl !== undefined ? req.body.questionImageUrl : existing.questionImageUrl,
                difficultyLevel: req.body.difficultyLevel ?? existing.difficultyLevel,
                explanationEn: req.body.explanationEn !== undefined ? req.body.explanationEn : existing.explanationEn,
                explanationHi: req.body.explanationHi !== undefined ? req.body.explanationHi : existing.explanationHi,
                isPublished: req.body.isPublished !== undefined ? Boolean(req.body.isPublished) : existing.isPublished,
            },
        });

        await logAdminAudit({
            req,
            action: 'update',
            entityType: 'question',
            entityId: id,
            oldValues: { questionTextEn: existing.questionTextEn, isPublished: existing.isPublished },
            newValues: { questionTextEn: updated.questionTextEn, isPublished: updated.isPublished },
        });

        sendSuccess(res, updated, 'Question updated successfully');
    })
);

router.post(
    '/questions/:id/duplicate',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const sourceQ = await prisma.question.findUnique({
            where: { id },
            include: { options: { orderBy: { displayOrder: 'asc' } } },
        });
        if (!sourceQ) throw new NotFoundError('Question not found.');

        const cloned = await prisma.question.create({
            data: {
                examinationId: sourceQ.examinationId,
                subjectId: sourceQ.subjectId,
                chapterId: sourceQ.chapterId,
                topicId: sourceQ.topicId,
                questionTextEn: `${sourceQ.questionTextEn} (Copy)`,
                questionTextHi: sourceQ.questionTextHi,
                questionImageUrl: sourceQ.questionImageUrl,
                questionType: sourceQ.questionType,
                difficultyLevel: sourceQ.difficultyLevel,
                explanationEn: sourceQ.explanationEn,
                explanationHi: sourceQ.explanationHi,
                explanationImageUrl: sourceQ.explanationImageUrl,
                source: sourceQ.source,
                language: sourceQ.language,
                marks: sourceQ.marks,
                negativeMarks: sourceQ.negativeMarks,
                isPublished: false,
                createdBy: req.user!.id,
                options: {
                    create: sourceQ.options.map((o) => ({
                        optionTextEn: o.optionTextEn,
                        optionTextHi: o.optionTextHi,
                        optionImageUrl: o.optionImageUrl,
                        isCorrect: o.isCorrect,
                        displayOrder: o.displayOrder,
                    })),
                },
            },
            include: { options: true },
        });

        sendSuccess(res, cloned, 'Question duplicated as draft', 201);
    })
);

router.delete(
    '/questions/:id',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const id = String(req.params.id);
        const existing = await prisma.question.findUnique({ where: { id } });
        if (!existing) throw new NotFoundError('Question not found.');

        await prisma.question.delete({ where: { id } });
        await logAdminAudit({
            req,
            action: 'delete',
            entityType: 'question',
            entityId: id,
            oldValues: { questionTextEn: existing.questionTextEn, isPublished: existing.isPublished },
        });

        sendSuccess(res, null, 'Question deleted');
    })
);

// BULK CSV/XLSX QUESTION IMPORT
router.post(
    '/questions/bulk-import',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    bulkUpload.single('file'),
    asyncHandler(async (req: Request, res: Response) => {
        if (!req.file) {
            throw new BadRequestError('CSV or Excel file is required.');
        }

        const examinationId = String(req.body.examinationId || '').trim();
        if (!examinationId) {
            throw new BadRequestError('examinationId is required for bulk question import.');
        }

        const exam = await prisma.examination.findUnique({
            where: { id: examinationId },
            include: {
                subjects: {
                    include: {
                        chapters: {
                            include: { topics: true },
                        },
                    },
                },
            },
        });

        if (!exam) throw new NotFoundError('Target examination not found.');

        const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
        const firstSheetName = workbook.SheetNames[0];
        if (!firstSheetName) {
            throw new BadRequestError('Uploaded spreadsheet is empty.');
        }

        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(
            workbook.Sheets[firstSheetName],
            { defval: '' }
        );

        if (rows.length === 0) {
            throw new BadRequestError('File contains 0 data rows.');
        }

        const importJob = await prisma.contentImportJob.create({
            data: {
                examinationId,
                adminUserId: req.user!.id,
                fileUrl: `memory://${req.file.originalname}`,
                fileName: req.file.originalname,
                entityType: 'question',
                status: ImportJobStatus.processing,
                totalRows: rows.length,
                startedAt: new Date(),
            },
        });

        const subjectMap = new Map(
            exam.subjects.map((s) => [s.name.trim().toLowerCase(), s])
        );

        let successfulRows = 0;
        let failedRows = 0;
        const errorLog: Array<{ row: number; field: string; message: string; rawData?: string }> = [];

        for (let i = 0; i < rows.length; i++) {
            const rowNum = i + 2; // Row 1 is header
            const r = rows[i];

            const questionTextEn = String(r['question_text_en'] || '').trim();
            const optionAEn = String(r['option_a_en'] || '').trim();
            const optionBEn = String(r['option_b_en'] || '').trim();
            const optionCEn = String(r['option_c_en'] || '').trim();
            const optionDEn = String(r['option_d_en'] || '').trim();
            const correctOpt = String(r['correct_option'] || '').trim().toUpperCase();
            const difficultyRaw = String(r['difficulty'] || 'medium').trim().toLowerCase();
            const subjectNameRaw = String(r['subject_name'] || '').trim().toLowerCase();

            if (!questionTextEn) {
                failedRows++;
                errorLog.push({ row: rowNum, field: 'question_text_en', message: 'Missing question_text_en' });
                continue;
            }

            if (!optionAEn || !optionBEn || !optionCEn || !optionDEn) {
                failedRows++;
                errorLog.push({ row: rowNum, field: 'options', message: 'All 4 English options (A, B, C, D) are required' });
                continue;
            }

            if (!['A', 'B', 'C', 'D'].includes(correctOpt)) {
                failedRows++;
                errorLog.push({
                    row: rowNum,
                    field: 'correct_option',
                    message: `Column 'correct_option' specifies '${correctOpt}', but single MCQ only supports A, B, C, or D.`,
                });
                continue;
            }

            if (!['easy', 'medium', 'hard'].includes(difficultyRaw)) {
                failedRows++;
                errorLog.push({
                    row: rowNum,
                    field: 'difficulty',
                    message: 'Difficulty must be easy, medium, or hard.',
                });
                continue;
            }

            const matchedSubject = subjectMap.get(subjectNameRaw);
            if (!matchedSubject) {
                failedRows++;
                errorLog.push({
                    row: rowNum,
                    field: 'subject_name',
                    message: `Subject '${String(r['subject_name'])}' not found in examination '${exam.name}'.`,
                });
                continue;
            }

            const chapterNameRaw = String(r['chapter_name'] || '').trim().toLowerCase();
            const topicNameRaw = String(r['topic_name'] || '').trim().toLowerCase();

            const matchedChapter = chapterNameRaw
                ? matchedSubject.chapters.find((c) => c.name.trim().toLowerCase() === chapterNameRaw)
                : undefined;

            const matchedTopic =
                topicNameRaw && matchedChapter
                    ? matchedChapter.topics.find((t) => t.name.trim().toLowerCase() === topicNameRaw)
                    : undefined;

            await prisma.question.create({
                data: {
                    examinationId,
                    subjectId: matchedSubject.id,
                    chapterId: matchedChapter?.id || null,
                    topicId: matchedTopic?.id || null,
                    questionTextEn,
                    questionTextHi: String(r['question_text_hi'] || '').trim() || null,
                    questionImageUrl: String(r['question_image_url'] || '').trim() || null,
                    questionType: QuestionType.single_correct_mcq,
                    difficultyLevel: difficultyRaw as DifficultyLevel,
                    explanationEn: String(r['explanation_en'] || '').trim() || null,
                    explanationHi: String(r['explanation_hi'] || '').trim() || null,
                    source: String(r['source'] || '').trim() || null,
                    isPublished: false, // Imported as draft for admin review
                    createdBy: req.user!.id,
                    options: {
                        create: [
                            {
                                optionTextEn: optionAEn,
                                optionTextHi: String(r['option_a_hi'] || '').trim() || null,
                                optionImageUrl: String(r['option_a_image_url'] || '').trim() || null,
                                isCorrect: correctOpt === 'A',
                                displayOrder: 1,
                            },
                            {
                                optionTextEn: optionBEn,
                                optionTextHi: String(r['option_b_hi'] || '').trim() || null,
                                optionImageUrl: String(r['option_b_image_url'] || '').trim() || null,
                                isCorrect: correctOpt === 'B',
                                displayOrder: 2,
                            },
                            {
                                optionTextEn: optionCEn,
                                optionTextHi: String(r['option_c_hi'] || '').trim() || null,
                                optionImageUrl: String(r['option_c_image_url'] || '').trim() || null,
                                isCorrect: correctOpt === 'C',
                                displayOrder: 3,
                            },
                            {
                                optionTextEn: optionDEn,
                                optionTextHi: String(r['option_d_hi'] || '').trim() || null,
                                optionImageUrl: String(r['option_d_image_url'] || '').trim() || null,
                                isCorrect: correctOpt === 'D',
                                displayOrder: 4,
                            },
                        ],
                    },
                },
            });

            successfulRows++;
        }

        const updatedJob = await prisma.contentImportJob.update({
            where: { id: importJob.id },
            data: {
                status: ImportJobStatus.completed,
                processedRows: rows.length,
                successfulRows,
                failedRows,
                errorLog,
                completedAt: new Date(),
            },
        });

        await logAdminAudit({
            req,
            action: 'bulk_import',
            entityType: 'question',
            entityId: updatedJob.id,
            newValues: { totalRows: rows.length, successfulRows, failedRows },
        });

        sendSuccess(
            res,
            {
                jobId: updatedJob.id,
                status: updatedJob.status,
                fileName: updatedJob.fileName,
                totalRows: updatedJob.totalRows,
                successfulRows: updatedJob.successfulRows,
                failedRows: updatedJob.failedRows,
                errorLog: updatedJob.errorLog,
            },
            'Bulk import processed',
            202
        );
    })
);

router.get(
    '/questions/import-jobs/:jobId',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const jobId = String(req.params.jobId);
        const job = await prisma.contentImportJob.findUnique({ where: { id: jobId } });
        if (!job) throw new NotFoundError('Import job not found.');

        sendSuccess(res, {
            jobId: job.id,
            status: job.status,
            totalRows: job.totalRows,
            processedRows: job.processedRows,
            successfulRows: job.successfulRows,
            failedRows: job.failedRows,
            errorLog: job.errorLog || [],
        });
    })
);

// ==========================================
// 5. QUIZ MANAGEMENT
// ==========================================
router.post(
    '/quizzes',
    authorize([UserRole.super_admin, UserRole.content_admin, UserRole.question_manager]),
    asyncHandler(async (req: Request, res: Response) => {
        const {
            title,
            description,
            examinationId,
            subjectId,
            quizType = QuizType.topic_wise,
            durationMinutes,
            marksPerQuestion = 1.0,
            negativeMarksPerQuestion = 0.0,
            instructions,
            difficultyLevel,
            isTimed = true,
            isPublished = false,
            questionIds = [],
        } = req.body;

        if (!title || !examinationId || !Array.isArray(questionIds) || questionIds.length === 0) {
            throw new BadRequestError('title, examinationId, and non-empty questionIds array are required.');
        }

        const quiz = await prisma.quiz.create({
            data: {
                title: String(title).trim(),
                description: description || null,
                examinationId: String(examinationId),
                subjectId: subjectId || null,
                quizType,
                totalQuestions: questionIds.length,
                durationMinutes: durationMinutes ? Number(durationMinutes) : null,
                marksPerQuestion: Number(marksPerQuestion),
                negativeMarksPerQuestion: Number(negativeMarksPerQuestion),
                instructions: instructions || null,
                difficultyLevel: difficultyLevel || null,
                isTimed: Boolean(isTimed),
                isPublished: Boolean(isPublished),
                createdBy: req.user!.id,
                quizQuestions: {
                    create: questionIds.map((qId: string, idx: number) => ({
                        questionId: String(qId),
                        displayOrder: idx + 1,
                    })),
                },
            },
            include: { quizQuestions: true },
        });

        await logAdminAudit({ req, action: 'create', entityType: 'quiz', entityId: quiz.id, newValues: quiz });
        sendSuccess(res, quiz, 'Quiz created successfully', 201);
    })
);

// ==========================================
// 6. STUDENT MANAGEMENT & STATUS TOGGLE
// ==========================================
router.get(
    '/students',
    authorize([UserRole.super_admin, UserRole.student_support]),
    asyncHandler(async (req: Request, res: Response) => {
        const page = Math.max(1, Number(req.query.page) || 1);
        const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
        const search = typeof req.query.search === 'string' ? req.query.search.trim() : undefined;

        const where = {
            role: UserRole.student,
            ...(search
                ? {
                    OR: [
                        { email: { contains: search, mode: 'insensitive' as const } },
                        { firstName: { contains: search, mode: 'insensitive' as const } },
                        { lastName: { contains: search, mode: 'insensitive' as const } },
                        { phone: { contains: search } },
                    ],
                }
                : {}),
        };

        const [totalRecords, students] = await Promise.all([
            prisma.user.count({ where }),
            prisma.user.findMany({
                where,
                select: {
                    id: true,
                    email: true,
                    firstName: true,
                    lastName: true,
                    displayName: true,
                    phone: true,
                    isActive: true,
                    lastLoginAt: true,
                    createdAt: true,
                    userExaminations: {
                        include: { examination: { select: { id: true, name: true } } },
                    },
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);

        sendSuccess(
            res,
            students,
            'Students fetched successfully',
            200,
            buildPagination(page, limit, totalRecords)
        );
    })
);

router.patch(
    '/students/:id/status',
    authorize([UserRole.super_admin, UserRole.student_support]),
    asyncHandler(async (req: Request, res: Response) => {
        const studentId = String(req.params.id);
        const isActive = Boolean(req.body.isActive);
        const reason = req.body.reason ? String(req.body.reason) : null;

        const student = await prisma.user.findUnique({ where: { id: studentId } });
        if (!student || student.role !== UserRole.student) {
            throw new NotFoundError('Student account not found.');
        }

        const updated = await prisma.user.update({
            where: { id: studentId },
            data: { isActive },
        });

        if (!isActive) {
            await prisma.refreshToken.updateMany({
                where: { userId: studentId, isRevoked: false },
                data: { isRevoked: true, revokedAt: new Date() },
            });
        }

        await logAdminAudit({
            req,
            action: 'status_change',
            entityType: 'student',
            entityId: studentId,
            oldValues: { isActive: student.isActive },
            newValues: { isActive: updated.isActive, reason },
        });

        sendSuccess(
            res,
            {
                studentId: updated.id,
                isActive: updated.isActive,
                statusChangedAt: new Date().toISOString(),
            },
            'Student account status updated'
        );
    })
);

// ==========================================
// 7. ADMIN USERS, APP CONFIG & AUDIT LOGS
// ==========================================
router.get(
    '/admin-users',
    authorize([UserRole.super_admin]),
    asyncHandler(async (_req: Request, res: Response) => {
        const admins = await prisma.user.findMany({
            where: { role: { not: UserRole.student } },
            select: {
                id: true,
                email: true,
                firstName: true,
                lastName: true,
                displayName: true,
                role: true,
                isActive: true,
                lastLoginAt: true,
                createdAt: true,
            },
            orderBy: { createdAt: 'desc' },
        });
        sendSuccess(res, admins);
    })
);

router.post(
    '/admin-users',
    authorize([UserRole.super_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const { email, password, firstName, lastName, role } = req.body;
        if (!email || !password || !firstName || !role) {
            throw new BadRequestError('email, password, firstName, and role are required.');
        }

        const passwordHash = await bcrypt.hash(String(password), 12);
        const adminUser = await prisma.user.create({
            data: {
                email: String(email).trim().toLowerCase(),
                passwordHash,
                firstName: String(firstName).trim(),
                lastName: lastName ? String(lastName).trim() : null,
                displayName: `${firstName} ${lastName || ''}`.trim(),
                role: role as UserRole,
                isActive: true,
                isEmailVerified: true,
            },
            select: {
                id: true,
                email: true,
                displayName: true,
                role: true,
                isActive: true,
            },
        });

        await logAdminAudit({
            req,
            action: 'create_admin',
            entityType: 'admin_user',
            entityId: adminUser.id,
            newValues: adminUser,
        });

        sendSuccess(res, adminUser, 'Admin user created successfully', 201);
    })
);

router.put(
    '/app-config',
    authorize([UserRole.super_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const updates = req.body as Record<string, string | boolean>;
        const updatedConfigs = [];

        for (const [key, val] of Object.entries(updates)) {
            const cfg = await prisma.appConfig.upsert({
                where: { configKey: key },
                update: { configValue: String(val) },
                create: {
                    configKey: key,
                    configValue: String(val),
                    configType: typeof val === 'boolean' ? 'boolean' : 'string',
                },
            });
            updatedConfigs.push(cfg);
        }

        await logAdminAudit({
            req,
            action: 'update',
            entityType: 'app_config',
            newValues: updates,
        });

        sendSuccess(res, updatedConfigs, 'App configuration updated');
    })
);

router.get(
    '/audit-logs',
    authorize([UserRole.super_admin]),
    asyncHandler(async (req: Request, res: Response) => {
        const page = Math.max(1, Number(req.query.page) || 1);
        const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
        const entityType =
            typeof req.query.entityType === 'string' ? req.query.entityType : undefined;
        const action = typeof req.query.action === 'string' ? req.query.action : undefined;

        const where = {
            ...(entityType ? { entityType } : {}),
            ...(action ? { action } : {}),
        };

        const [totalRecords, logs] = await Promise.all([
            prisma.adminAuditLog.count({ where }),
            prisma.adminAuditLog.findMany({
                where,
                include: {
                    adminUser: {
                        select: { id: true, email: true, displayName: true },
                    },
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);

        sendSuccess(
            res,
            logs.map((l) => ({
                id: l.id,
                adminUser: l.adminUser
                    ? {
                        id: l.adminUser.id,
                        email: l.adminUser.email,
                        name: l.adminUser.displayName,
                    }
                    : null,
                action: l.action,
                entityType: l.entityType,
                entityId: l.entityId,
                oldValues: l.oldValues,
                newValues: l.newValues,
                ipAddress: l.ipAddress,
                createdAt: l.createdAt,
            })),
            'Audit logs fetched',
            200,
            buildPagination(page, limit, totalRecords)
        );
    })
);

export default router;