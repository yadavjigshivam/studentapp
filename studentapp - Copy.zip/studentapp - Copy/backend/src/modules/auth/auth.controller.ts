import { Request, Response } from 'express';
import { authService } from './auth.service';
import { sendSuccess } from '../../shared/utils/response';

export class AuthController {
    async register(req: Request, res: Response): Promise<void> {
        const result = await authService.register(req.body);
        sendSuccess(res, result, 'Student account registered successfully', 201);
    }

    async login(req: Request, res: Response): Promise<void> {
        const result = await authService.login(req.body);
        sendSuccess(res, result, 'Login successful', 200);
    }

    async refreshToken(req: Request, res: Response): Promise<void> {
        const result = await authService.refreshToken(req.body.refreshToken);
        sendSuccess(res, result, 'Token refreshed successfully', 200);
    }

    async logout(req: Request, res: Response): Promise<void> {
        await authService.logout(req.body.refreshToken);
        sendSuccess(res, null, 'Session invalidated successfully', 200);
    }

    async forgotPassword(req: Request, res: Response): Promise<void> {
        const result = await authService.forgotPassword(req.body.email);
        sendSuccess(
            res,
            result.resetTokenForDev ? { devResetToken: result.resetTokenForDev } : {},
            'If an account exists with this email, a password reset link has been sent.',
            200
        );
    }

    async resetPassword(req: Request, res: Response): Promise<void> {
        await authService.resetPassword(req.body.token, req.body.newPassword);
        sendSuccess(res, null, 'Password has been reset successfully. Please log in.', 200);
    }

    async changePassword(req: Request, res: Response): Promise<void> {
        await authService.changePassword(
            req.user!.id,
            req.body.currentPassword,
            req.body.newPassword
        );
        sendSuccess(res, null, 'Password updated successfully.', 200);
    }
}

export const authController = new AuthController();