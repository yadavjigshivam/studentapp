import { Router } from 'express';
import { authController } from './auth.controller';
import { validate } from '../../middleware/validate';
import { authenticate } from '../../middleware/authenticate';
import {
    loginRateLimiter,
    registerRateLimiter,
    passwordResetRateLimiter,
} from '../../middleware/rateLimiter';
import {
    registerSchema,
    loginSchema,
    refreshTokenSchema,
    logoutSchema,
    forgotPasswordSchema,
    resetPasswordSchema,
    changePasswordSchema,
} from './auth.validators';
import { asyncHandler } from '../../shared/utils/response';

const router = Router();

router.post(
    '/register',
    registerRateLimiter,
    validate({ body: registerSchema }),
    asyncHandler(authController.register.bind(authController))
);

router.post(
    '/login',
    loginRateLimiter,
    validate({ body: loginSchema }),
    asyncHandler(authController.login.bind(authController))
);

router.post(
    '/refresh-token',
    validate({ body: refreshTokenSchema }),
    asyncHandler(authController.refreshToken.bind(authController))
);

router.post(
    '/logout',
    validate({ body: logoutSchema }),
    asyncHandler(authController.logout.bind(authController))
);

router.post(
    '/forgot-password',
    passwordResetRateLimiter,
    validate({ body: forgotPasswordSchema }),
    asyncHandler(authController.forgotPassword.bind(authController))
);

router.post(
    '/reset-password',
    passwordResetRateLimiter,
    validate({ body: resetPasswordSchema }),
    asyncHandler(authController.resetPassword.bind(authController))
);

router.post(
    '/change-password',
    authenticate,
    validate({ body: changePasswordSchema }),
    asyncHandler(authController.changePassword.bind(authController))
);

export default router;