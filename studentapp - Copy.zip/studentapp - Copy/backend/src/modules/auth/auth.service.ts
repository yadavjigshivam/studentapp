import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { UserRole } from '@prisma/client';
import { prisma } from '../../config/database';
import { env } from '../../config/env';
import {
    AuthenticationError,
    AuthorizationError,
    BadRequestError,
    ConflictError,
} from '../../shared/errors/AppError';
import { generateOpaqueToken, hashToken, getISTDateObject } from '../../shared/utils/response';

const SALT_ROUNDS = 12;
const ACCESS_TOKEN_SECONDS = 900; // 15 minutes
const REFRESH_TOKEN_DAYS = 7;

export class AuthService {
    private signAccessToken(user: { id: string; email: string; role: UserRole }): string {
        return jwt.sign(
            { sub: user.id, email: user.email, role: user.role },
            env.JWT_SECRET,
            { expiresIn: env.JWT_ACCESS_EXPIRY as jwt.SignOptions['expiresIn'] }
        );
    }

    private async issueTokenPair(
        user: { id: string; email: string; role: UserRole },
        deviceInfo?: string
    ) {
        const accessToken = this.signAccessToken(user);
        const rawRefreshToken = generateOpaqueToken();
        const tokenHash = hashToken(rawRefreshToken);

        const expiresAt = new Date(Date.now() + REFRESH_TOKEN_DAYS * 24 * 60 * 60 * 1000);

        await prisma.refreshToken.create({
            data: {
                userId: user.id,
                tokenHash,
                deviceInfo: deviceInfo || null,
                expiresAt,
            },
        });

        return {
            accessToken,
            accessTokenExpiresIn: ACCESS_TOKEN_SECONDS,
            refreshToken: rawRefreshToken,
        };
    }

    async register(input: {
        email: string;
        password: string;
        firstName: string;
        lastName?: string;
        phone?: string;
    }) {
        const existingEmail = await prisma.user.findUnique({ where: { email: input.email } });
        if (existingEmail) {
            throw new ConflictError('An account with this email already exists.');
        }

        if (input.phone) {
            const existingPhone = await prisma.user.findUnique({ where: { phone: input.phone } });
            if (existingPhone) {
                throw new ConflictError('An account with this phone number already exists.');
            }
        }

        const passwordHash = await bcrypt.hash(input.password, SALT_ROUNDS);
        const displayName = input.lastName
            ? `${input.firstName} ${input.lastName}`.trim()
            : input.firstName;

        const user = await prisma.user.create({
            data: {
                email: input.email,
                passwordHash,
                firstName: input.firstName,
                lastName: input.lastName || null,
                displayName,
                phone: input.phone || null,
                role: UserRole.student,
                isActive: true,
                isEmailVerified: false,
                lastLoginAt: new Date(),
                streak: {
                    create: {
                        currentStreak: 0,
                        longestStreak: 0,
                    },
                },
                focusModeSettings: {
                    create: {
                        blockedApps: [],
                        focusDurationMinutes: 25,
                        breakDurationMinutes: 5,
                        enableDnd: true,
                        enableAppOverlay: true,
                        emergencyExitEnabled: true,
                    },
                },
            },
        });

        const tokens = await this.issueTokenPair(user, 'Registration Client');

        return {
            user: {
                id: user.id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                displayName: user.displayName,
                phone: user.phone,
                role: user.role,
                isActive: user.isActive,
                isEmailVerified: user.isEmailVerified,
            },
            tokens,
        };
    }

    async login(input: { email: string; password: string; deviceInfo?: string }) {
        const user = await prisma.user.findUnique({
            where: { email: input.email },
            include: {
                userExaminations: {
                    where: { isPrimary: true },
                    include: { examination: true },
                    take: 1,
                },
            },
        });

        if (!user) {
            throw new AuthenticationError('Invalid email or password.');
        }

        const isPasswordValid = await bcrypt.compare(input.password, user.passwordHash);
        if (!isPasswordValid) {
            throw new AuthenticationError('Invalid email or password.');
        }

        if (!user.isActive) {
            throw new AuthorizationError('Account deactivated. Please contact support.');
        }

        await prisma.$transaction([
            prisma.user.update({
                where: { id: user.id },
                data: { lastLoginAt: new Date() },
            }),
            prisma.userActivityLog.create({
                data: {
                    userId: user.id,
                    activityType: 'login',
                    activityDate: getISTDateObject(),
                    metadata: { deviceInfo: input.deviceInfo || 'Unknown' },
                },
            }),
        ]);

        const tokens = await this.issueTokenPair(user, input.deviceInfo);
        const primaryExamRecord = user.userExaminations[0]?.examination || null;

        return {
            user: {
                id: user.id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                displayName: user.displayName,
                phone: user.phone,
                avatarUrl: user.avatarUrl,
                role: user.role,
                primaryExamination: primaryExamRecord
                    ? {
                        id: primaryExamRecord.id,
                        name: primaryExamRecord.name,
                        slug: primaryExamRecord.slug,
                    }
                    : null,
            },
            tokens,
        };
    }

    async refreshToken(rawRefreshToken: string) {
        const incomingHash = hashToken(rawRefreshToken);

        const storedToken = await prisma.refreshToken.findUnique({
            where: { tokenHash: incomingHash },
            include: { user: true },
        });

        if (!storedToken) {
            throw new AuthenticationError('Invalid refresh token.');
        }

        // Token Reuse Detection: if an already revoked token is presented, revoke all user sessions
        if (storedToken.isRevoked) {
            await prisma.refreshToken.updateMany({
                where: { userId: storedToken.userId, isRevoked: false },
                data: { isRevoked: true, revokedAt: new Date() },
            });
            throw new AuthenticationError('Refresh token has already been used or revoked. Please log in again.');
        }

        if (storedToken.expiresAt < new Date()) {
            throw new AuthenticationError('Refresh token has expired. Please log in again.');
        }

        if (!storedToken.user.isActive) {
            throw new AuthorizationError('Account is deactivated.');
        }

        // Rotate refresh token
        const newRawRefreshToken = generateOpaqueToken();
        const newTokenHash = hashToken(newRawRefreshToken);
        const expiresAt = new Date(Date.now() + REFRESH_TOKEN_DAYS * 24 * 60 * 60 * 1000);

        await prisma.$transaction([
            prisma.refreshToken.update({
                where: { id: storedToken.id },
                data: {
                    isRevoked: true,
                    revokedAt: new Date(),
                    replacedByTokenHash: newTokenHash,
                },
            }),
            prisma.refreshToken.create({
                data: {
                    userId: storedToken.userId,
                    tokenHash: newTokenHash,
                    deviceInfo: storedToken.deviceInfo,
                    expiresAt,
                },
            }),
        ]);

        const accessToken = this.signAccessToken(storedToken.user);

        return {
            accessToken,
            accessTokenExpiresIn: ACCESS_TOKEN_SECONDS,
            refreshToken: newRawRefreshToken,
        };
    }

    async logout(rawRefreshToken: string) {
        const incomingHash = hashToken(rawRefreshToken);
        await prisma.refreshToken.updateMany({
            where: { tokenHash: incomingHash, isRevoked: false },
            data: { isRevoked: true, revokedAt: new Date() },
        });
    }

    async forgotPassword(email: string) {
        const user = await prisma.user.findUnique({ where: { email } });
        if (!user || !user.isActive) {
            // Prevent email enumeration: return silently
            return { resetTokenForDev: null };
        }

        const rawResetToken = generateOpaqueToken();
        const tokenHash = hashToken(rawResetToken);
        const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour expiry

        await prisma.passwordResetToken.create({
            data: {
                userId: user.id,
                tokenHash,
                expiresAt,
            },
        });

        return {
            resetTokenForDev: env.NODE_ENV === 'development' ? rawResetToken : undefined,
        };
    }

    async resetPassword(rawToken: string, newPassword: string) {
        const tokenHash = hashToken(rawToken);
        const resetRecord = await prisma.passwordResetToken.findUnique({
            where: { tokenHash },
        });

        if (!resetRecord) {
            throw new BadRequestError('Invalid password reset token.');
        }

        if (resetRecord.isUsed) {
            throw new BadRequestError('Token already used.');
        }

        if (resetRecord.expiresAt < new Date()) {
            throw new BadRequestError('Token expired.');
        }

        const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

        await prisma.$transaction([
            prisma.user.update({
                where: { id: resetRecord.userId },
                data: { passwordHash },
            }),
            prisma.passwordResetToken.update({
                where: { id: resetRecord.id },
                data: { isUsed: true, usedAt: new Date() },
            }),
            prisma.refreshToken.updateMany({
                where: { userId: resetRecord.userId, isRevoked: false },
                data: { isRevoked: true, revokedAt: new Date() },
            }),
        ]);
    }

    async changePassword(userId: string, currentPassword: string, newPassword: string) {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) {
            throw new AuthenticationError('User not found.');
        }

        const isMatch = await bcrypt.compare(currentPassword, user.passwordHash);
        if (!isMatch) {
            throw new AuthenticationError('Current password is incorrect.');
        }

        const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
        await prisma.user.update({
            where: { id: userId },
            data: { passwordHash },
        });
    }
}

export const authService = new AuthService();