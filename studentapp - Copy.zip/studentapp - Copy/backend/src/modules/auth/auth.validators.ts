import { z } from 'zod';

const passwordRule = z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one digit')
    .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character');

export const registerSchema = z
    .object({
        email: z.string().trim().toLowerCase().email('Invalid email address format'),
        password: passwordRule,
        confirmPassword: z.string(),
        firstName: z.string().trim().min(2, 'First name is required (min 2 characters)').max(100),
        lastName: z.string().trim().max(100).optional(),
        phone: z
            .string()
            .trim()
            .regex(/^\+?[0-9]{10,15}$/, 'Invalid phone number format')
            .optional(),
    })
    .refine((data) => data.password === data.confirmPassword, {
        message: 'Passwords do not match',
        path: ['confirmPassword'],
    });

export const loginSchema = z.object({
    email: z.string().trim().toLowerCase().email('Invalid email address'),
    password: z.string().min(1, 'Password is required'),
    deviceInfo: z.string().max(255).optional(),
});

export const refreshTokenSchema = z.object({
    refreshToken: z.string().min(10, 'Valid refresh token is required'),
});

export const logoutSchema = z.object({
    refreshToken: z.string().min(10, 'Refresh token is required'),
});

export const forgotPasswordSchema = z.object({
    email: z.string().trim().toLowerCase().email('Invalid email address'),
});

export const resetPasswordSchema = z
    .object({
        token: z.string().min(10, 'Reset token is required'),
        newPassword: passwordRule,
        confirmPassword: z.string(),
    })
    .refine((data) => data.newPassword === data.confirmPassword, {
        message: 'Passwords do not match',
        path: ['confirmPassword'],
    });

export const changePasswordSchema = z
    .object({
        currentPassword: z.string().min(1, 'Current password is required'),
        newPassword: passwordRule,
        confirmPassword: z.string(),
    })
    .refine((data) => data.newPassword === data.confirmPassword, {
        message: 'Passwords do not match',
        path: ['confirmPassword'],
    });