import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { BookmarkType, FocusExitReason } from '@prisma/client';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { validate } from '../../middleware/validate';
import { asyncHandler, buildPagination, sendSuccess } from '../../shared/utils/response';
import { BadRequestError, NotFoundError } from '../../shared/errors/AppError';

export const bookmarksRouter = Router();
export const focusModeRouter = Router();

const createBookmarkSchema = z.object({
    bookmarkType: z.nativeEnum(BookmarkType),
    questionId: z.string().uuid().optional().nullable(),
    studyNoteId: z.string().uuid().optional().nullable(),
    notes: z.string().max(1000).optional().nullable(),
});

// 1. GET /api/v1/bookmarks
bookmarksRouter.get(
    '/',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const page = Math.max(1, Number(req.query.page) || 1);
        const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
        const typeFilter =
            typeof req.query.type === 'string' &&
                (req.query.type === 'question' || req.query.type === 'study_note')
                ? (req.query.type as BookmarkType)
                : undefined;

        const where = {
            userId,
            ...(typeFilter ? { bookmarkType: typeFilter } : {}),
        };

        const [totalRecords, bookmarks] = await Promise.all([
            prisma.bookmark.count({ where }),
            prisma.bookmark.findMany({
                where,
                include: {
                    question: {
                        select: {
                            id: true,
                            questionTextEn: true,
                            questionTextHi: true,
                            difficultyLevel: true,
                            subject: { select: { id: true, name: true } },
                        },
                    },
                    studyNote: {
                        select: {
                            id: true,
                            title: true,
                            summary: true,
                            topic: { select: { id: true, name: true } },
                        },
                    },
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);

        sendSuccess(
            res,
            bookmarks,
            'Bookmarks fetched successfully',
            200,
            buildPagination(page, limit, totalRecords)
        );
    })
);

// 2. POST /api/v1/bookmarks
bookmarksRouter.post(
    '/',
    authenticate,
    validate({ body: createBookmarkSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const bookmarkType = req.body.bookmarkType as BookmarkType;
        const questionId = (req.body.questionId as string | null | undefined) || null;
        const studyNoteId = (req.body.studyNoteId as string | null | undefined) || null;
        const notes = (req.body.notes as string | null | undefined) || null;

        if (bookmarkType === BookmarkType.question && !questionId) {
            throw new BadRequestError('questionId is required when bookmarkType is question.');
        }
        if (bookmarkType === BookmarkType.study_note && !studyNoteId) {
            throw new BadRequestError('studyNoteId is required when bookmarkType is study_note.');
        }

        const bookmark = await prisma.bookmark.create({
            data: {
                userId,
                bookmarkType,
                questionId: bookmarkType === BookmarkType.question ? questionId : null,
                studyNoteId: bookmarkType === BookmarkType.study_note ? studyNoteId : null,
                notes,
            },
        });

        sendSuccess(
            res,
            {
                bookmarkId: bookmark.id,
                bookmarkType: bookmark.bookmarkType,
                questionId: bookmark.questionId,
                studyNoteId: bookmark.studyNoteId,
                createdAt: bookmark.createdAt,
            },
            'Bookmark saved',
            201
        );
    })
);

// 3. DELETE /api/v1/bookmarks/:id
bookmarksRouter.delete(
    '/:id',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const bookmarkId = String(req.params.id);

        const existing = await prisma.bookmark.findFirst({
            where: { id: bookmarkId, userId },
        });

        if (!existing) throw new NotFoundError('Bookmark not found.');

        await prisma.bookmark.delete({ where: { id: bookmarkId } });
        sendSuccess(res, null, 'Bookmark removed');
    })
);

// ==========================================
// FOCUS MODE ROUTES
// ==========================================

const updateFocusSettingsSchema = z.object({
    blockedApps: z.array(z.string()).default([]),
    focusDurationMinutes: z.number().int().min(5).max(360).default(25),
    breakDurationMinutes: z.number().int().min(1).max(60).default(5),
    enableDnd: z.boolean().default(true),
    enableAppOverlay: z.boolean().default(true),
    emergencyExitEnabled: z.boolean().default(true),
});

const recordFocusSessionSchema = z.object({
    studySessionId: z.string().uuid().optional().nullable(),
    deviceId: z.string().max(100).optional().nullable(),
    plannedDurationMinutes: z.number().int().min(1).default(25),
    actualDurationSeconds: z.number().int().min(0).default(0),
    distractionsCount: z.number().int().min(0).default(0),
    wasCompleted: z.boolean().default(true),
    exitReason: z.nativeEnum(FocusExitReason).optional().default(FocusExitReason.completed),
    permissionGranted: z.record(z.boolean()).optional().default({}),
    blockingMethodUsed: z.string().max(50).optional().default('overlay_reminder'),
});

// 4. GET /api/v1/focus-mode/settings
focusModeRouter.get(
    '/focus-mode/settings',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;

        const settings = await prisma.focusModeSetting.upsert({
            where: { userId },
            update: {},
            create: {
                userId,
                blockedApps: [],
                focusDurationMinutes: 25,
                breakDurationMinutes: 5,
                enableDnd: true,
                enableAppOverlay: true,
                emergencyExitEnabled: true,
            },
        });

        sendSuccess(res, settings);
    })
);

// 5. PUT /api/v1/focus-mode/settings
focusModeRouter.put(
    '/focus-mode/settings',
    authenticate,
    validate({ body: updateFocusSettingsSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const blockedApps = req.body.blockedApps as string[];
        const focusDurationMinutes = Number(req.body.focusDurationMinutes);
        const breakDurationMinutes = Number(req.body.breakDurationMinutes);
        const enableDnd = Boolean(req.body.enableDnd);
        const enableAppOverlay = Boolean(req.body.enableAppOverlay);
        const emergencyExitEnabled = Boolean(req.body.emergencyExitEnabled);

        const updated = await prisma.focusModeSetting.upsert({
            where: { userId },
            update: {
                blockedApps,
                focusDurationMinutes,
                breakDurationMinutes,
                enableDnd,
                enableAppOverlay,
                emergencyExitEnabled,
            },
            create: {
                userId,
                blockedApps,
                focusDurationMinutes,
                breakDurationMinutes,
                enableDnd,
                enableAppOverlay,
                emergencyExitEnabled,
            },
        });

        sendSuccess(
            res,
            {
                blockedAppsCount: blockedApps.length,
                blockedApps: updated.blockedApps,
                focusDurationMinutes: updated.focusDurationMinutes,
                breakDurationMinutes: updated.breakDurationMinutes,
                enableDnd: updated.enableDnd,
                enableAppOverlay: updated.enableAppOverlay,
                emergencyExitEnabled: updated.emergencyExitEnabled,
            },
            'Focus Mode configuration updated'
        );
    })
);

// 6. POST /api/v1/focus-sessions
focusModeRouter.post(
    '/focus-sessions',
    authenticate,
    validate({ body: recordFocusSessionSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const now = new Date();
        const actualDurationSeconds = Number(req.body.actualDurationSeconds) || 0;
        const distractionsCount = Number(req.body.distractionsCount) || 0;
        const startedAt = new Date(now.getTime() - actualDurationSeconds * 1000);

        const focusSession = await prisma.focusSession.create({
            data: {
                userId,
                studySessionId: (req.body.studySessionId as string | null | undefined) || null,
                deviceId: (req.body.deviceId as string | null | undefined) || null,
                plannedDurationMinutes: Number(req.body.plannedDurationMinutes) || 25,
                actualDurationSeconds,
                distractionsCount,
                wasCompleted: Boolean(req.body.wasCompleted),
                exitReason: (req.body.exitReason as FocusExitReason) || FocusExitReason.completed,
                permissionGranted: req.body.permissionGranted || {},
                blockingMethodUsed: String(req.body.blockingMethodUsed || 'overlay_reminder'),
                startedAt,
                endedAt: now,
            },
        });

        const focusEfficiency = Math.max(0, Number((100 - distractionsCount * 2).toFixed(1)));

        sendSuccess(
            res,
            {
                focusSessionId: focusSession.id,
                distractionsLogged: focusSession.distractionsCount,
                focusEfficiency,
            },
            'Focus session recorded',
            201
        );
    })
);