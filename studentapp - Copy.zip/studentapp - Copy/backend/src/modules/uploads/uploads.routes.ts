import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { createClient } from '@supabase/supabase-js';
import { authenticate } from '../../middleware/authenticate';
import { env } from '../../config/env';
import { asyncHandler, sendSuccess } from '../../shared/utils/response';
import { BadRequestError } from '../../shared/errors/AppError';

const router = Router();

const ALLOWED_MIME_TYPES = new Set([
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/svg+xml',
    'application/pdf',
    'text/csv',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
]);

const ALLOWED_FOLDERS = new Set(['questions', 'avatars', 'syllabus', 'imports', 'logos']);

const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
        fileSize: 10 * 1024 * 1024, // 10 MB max
    },
    fileFilter: (_req, file, cb) => {
        if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
            cb(new BadRequestError(`Unsupported file type: ${file.mimetype}`));
            return;
        }
        cb(null, true);
    },
});

// POST /api/v1/uploads - Secure asset upload (Supabase Storage with Local Disk fallback)
router.post(
    '/',
    authenticate,
    upload.single('file'),
    asyncHandler(async (req: Request, res: Response) => {
        if (!req.file) {
            throw new BadRequestError('No file provided in multipart payload.');
        }

        const rawFolder = typeof req.body.folder === 'string' ? req.body.folder.trim() : 'questions';
        const folder = ALLOWED_FOLDERS.has(rawFolder) ? rawFolder : 'questions';

        const ext = path.extname(req.file.originalname).toLowerCase() || '.bin';
        const now = new Date();
        const yearMonth = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}`;
        const safeFileName = `${uuidv4()}${ext}`;
        const fileKey = `${folder}/${yearMonth}/${safeFileName}`;

        // Use Supabase Storage if configured with real credentials
        const hasSupabase =
            env.SUPABASE_URL &&
            env.SUPABASE_KEY &&
            !env.SUPABASE_URL.includes('your-project.supabase.co');

        if (hasSupabase) {
            const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_KEY);
            const { error } = await supabase.storage
                .from(env.SUPABASE_BUCKET)
                .upload(fileKey, req.file.buffer, {
                    contentType: req.file.mimetype,
                    upsert: false,
                });

            if (error) {
                throw new BadRequestError(`Cloud storage upload failed: ${error.message}`);
            }

            const { data: publicUrlData } = supabase.storage
                .from(env.SUPABASE_BUCKET)
                .getPublicUrl(fileKey);

            sendSuccess(
                res,
                {
                    url: publicUrlData.publicUrl,
                    fileKey,
                    mimeType: req.file.mimetype,
                    sizeBytes: req.file.size,
                },
                'File uploaded successfully',
                201
            );
            return;
        }

        // Local development fallback: save inside backend/uploads/<folder>/<YYYY>/<MM>
        const localDir = path.join(process.cwd(), 'uploads', folder, String(now.getFullYear()), String(now.getMonth() + 1).padStart(2, '0'));
        fs.mkdirSync(localDir, { recursive: true });

        const fullLocalPath = path.join(localDir, safeFileName);
        fs.writeFileSync(fullLocalPath, req.file.buffer);

        const hostUrl = `${req.protocol}://${req.get('host')}`;
        const publicUrl = `${hostUrl}/uploads/${fileKey}`;

        sendSuccess(
            res,
            {
                url: publicUrl,
                fileKey,
                mimeType: req.file.mimetype,
                sizeBytes: req.file.size,
            },
            'File uploaded successfully',
            201
        );
    })
);

export default router;