import { Router, Request, Response } from 'express';
import { ProgressStatus } from '@prisma/client';
import jwt from 'jsonwebtoken';
import { prisma } from '../../config/database';
import { env } from '../../config/env';
import { authenticate } from '../../middleware/authenticate';
import { asyncHandler, buildPagination, sendSuccess } from '../../shared/utils/response';
import { NotFoundError } from '../../shared/errors/AppError';

const router = Router();

function extractOptionalUserId(req: Request): string | null {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader?.startsWith('Bearer ')) return null;
        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, env.JWT_SECRET) as { sub: string };
        return decoded.sub;
    } catch {
        return null;
    }
}

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// 1. GET /api/v1/examinations
router.get(
    '/examinations',
    asyncHandler(async (req: Request, res: Response) => {
        const page = Math.max(1, Number(req.query.page) || 1);
        const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
        const category = typeof req.query.category === 'string' ? req.query.category : undefined;
        const search = typeof req.query.search === 'string' ? req.query.search : undefined;

        const where = {
            isActive: true,
            ...(category ? { category: { equals: category, mode: 'insensitive' as const } } : {}),
            ...(search
                ? {
                    OR: [
                        { name: { contains: search, mode: 'insensitive' as const } },
                        { description: { contains: search, mode: 'insensitive' as const } },
                    ],
                }
                : {}),
        };

        const [totalRecords, exams] = await Promise.all([
            prisma.examination.count({ where }),
            prisma.examination.findMany({
                where,
                include: {
                    _count: { select: { subjects: { where: { isActive: true } } } },
                    syllabusVersions: {
                        where: { isActive: true },
                        orderBy: { createdAt: 'desc' },
                        take: 1,
                    },
                },
                orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }],
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);

        const data = exams.map((exam) => ({
            id: exam.id,
            name: exam.name,
            slug: exam.slug,
            description: exam.description,
            category: exam.category,
            logoUrl: exam.logoUrl,
            language: exam.language,
            instructions: exam.instructions,
            subjectsCount: exam._count.subjects,
            activeSyllabusVersion: exam.syllabusVersions[0]?.versionCode || '1.0',
        }));

        sendSuccess(
            res,
            data,
            'Examinations fetched successfully',
            200,
            buildPagination(page, limit, totalRecords)
        );
    })
);

// 2. GET /api/v1/examinations/:examId/syllabus
router.get(
    '/examinations/:examId/syllabus',
    asyncHandler(async (req: Request, res: Response) => {
        const examId = String(req.params.examId);
        const userId = extractOptionalUserId(req);
        const isUuid = UUID_REGEX.test(examId);

        const exam = await prisma.examination.findFirst({
            where: {
                ...(isUuid ? { id: examId } : { slug: examId }),
                isActive: true,
            },
            include: {
                syllabusVersions: {
                    where: { isActive: true },
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                },
                subjects: {
                    where: { isActive: true },
                    orderBy: { displayOrder: 'asc' },
                    include: {
                        chapters: {
                            where: { isActive: true },
                            orderBy: { displayOrder: 'asc' },
                            include: {
                                topics: {
                                    where: { isActive: true },
                                    orderBy: { displayOrder: 'asc' },
                                },
                            },
                        },
                    },
                },
            },
        });

        if (!exam) {
            throw new NotFoundError('Examination not found.');
        }

        const topicProgressMap = new Map<
            string,
            {
                status: ProgressStatus;
                studyTimeSeconds: number;
                questionsAttempted: number;
                questionsCorrect: number;
                completedAt: Date | null;
            }
        >();

        if (userId) {
            const progressRecords = await prisma.topicProgress.findMany({
                where: {
                    userId,
                    topic: { chapter: { subject: { examinationId: exam.id } } },
                },
            });
            for (const rec of progressRecords) {
                topicProgressMap.set(rec.topicId, rec);
            }
        }

        const activeSyllabus = exam.syllabusVersions[0] || null;

        const subjects = exam.subjects.map((subject) => {
            let subjectTotalTopics = 0;
            let subjectCompletedTopics = 0;
            let subjectStudySeconds = 0;
            let hasAnyActivity = false;

            const chapters = subject.chapters.map((chapter) => {
                const topics = chapter.topics.map((topic) => {
                    subjectTotalTopics += 1;
                    const prog = topicProgressMap.get(topic.id);
                    const status = prog?.status || ProgressStatus.not_started;
                    const studyTimeSeconds = prog?.studyTimeSeconds || 0;
                    const questionsAttempted = prog?.questionsAttempted || 0;
                    const questionsCorrect = prog?.questionsCorrect || 0;

                    if (status === ProgressStatus.completed) {
                        subjectCompletedTopics += 1;
                    }
                    if (status !== ProgressStatus.not_started || studyTimeSeconds > 0 || questionsAttempted > 0) {
                        hasAnyActivity = true;
                    }
                    subjectStudySeconds += studyTimeSeconds;

                    const accuracy =
                        questionsAttempted > 0
                            ? Number(((questionsCorrect / questionsAttempted) * 100).toFixed(1))
                            : null;

                    return {
                        id: topic.id,
                        name: topic.name,
                        slug: topic.slug,
                        description: topic.description,
                        estimatedStudyTimeMinutes: topic.estimatedStudyTimeMinutes,
                        displayOrder: topic.displayOrder,
                        progress: {
                            status,
                            studyTimeSeconds,
                            questionsAttempted,
                            accuracy,
                            completedAt: prog?.completedAt || null,
                        },
                    };
                });

                return {
                    id: chapter.id,
                    name: chapter.name,
                    slug: chapter.slug,
                    description: chapter.description,
                    displayOrder: chapter.displayOrder,
                    topics,
                };
            });

            const completionPercentage =
                subjectTotalTopics > 0
                    ? Number(((subjectCompletedTopics / subjectTotalTopics) * 100).toFixed(2))
                    : 0;

            const subjectStatus: ProgressStatus =
                subjectTotalTopics > 0 && subjectCompletedTopics === subjectTotalTopics
                    ? ProgressStatus.completed
                    : hasAnyActivity
                        ? ProgressStatus.in_progress
                        : ProgressStatus.not_started;

            return {
                id: subject.id,
                name: subject.name,
                slug: subject.slug,
                description: subject.description,
                iconUrl: subject.iconUrl,
                displayOrder: subject.displayOrder,
                progress: {
                    status: subjectStatus,
                    completedTopics: subjectCompletedTopics,
                    totalTopics: subjectTotalTopics,
                    remainingTopics: Math.max(0, subjectTotalTopics - subjectCompletedTopics),
                    completionPercentage,
                    totalStudySeconds: subjectStudySeconds,
                },
                chapters,
            };
        });

        sendSuccess(res, {
            examination: {
                id: exam.id,
                name: exam.name,
                slug: exam.slug,
                versionCode: activeSyllabus?.versionCode || '1.0',
                officialNotificationPdfUrl: activeSyllabus?.fileUrl || null,
                publishedAt: activeSyllabus?.publishedAt || exam.createdAt,
            },
            subjects,
        });
    })
);

// 3. GET /api/v1/topics/:topicId/notes
router.get(
    '/topics/:topicId/notes',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const topicId = String(req.params.topicId);
        const userId = req.user!.id;

        const topic = await prisma.topic.findUnique({
            where: { id: topicId },
            include: {
                studyNotes: {
                    where: { isPublished: true },
                    orderBy: { displayOrder: 'asc' },
                },
            },
        });

        if (!topic) {
            throw new NotFoundError('Topic not found.');
        }

        const note = topic.studyNotes[0] || null;
        let bookmark = null;

        if (note) {
            bookmark = await prisma.bookmark.findUnique({
                where: {
                    userId_studyNoteId: {
                        userId,
                        studyNoteId: note.id,
                    },
                },
            });
        }

        sendSuccess(res, {
            topicId: topic.id,
            topicName: topic.name,
            note: note
                ? {
                    id: note.id,
                    title: note.title,
                    summary: note.summary,
                    contentEn: note.contentEn,
                    contentHi: note.contentHi,
                    imageUrls: note.imageUrls || [],
                    isBookmarked: Boolean(bookmark),
                    bookmarkId: bookmark?.id || null,
                }
                : null,
            allNotes: topic.studyNotes,
        });
    })
);

// 4. PATCH /api/v1/topics/:topicId/complete
router.patch(
    '/topics/:topicId/complete',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const topicId = String(req.params.topicId);
        const userId = req.user!.id;
        const completed = req.body.completed !== false;

        const topic = await prisma.topic.findUnique({
            where: { id: topicId },
            include: { chapter: true },
        });

        if (!topic) throw new NotFoundError('Topic not found.');

        const updatedProgress = await prisma.topicProgress.upsert({
            where: { userId_topicId: { userId, topicId } },
            update: {
                status: completed ? ProgressStatus.completed : ProgressStatus.in_progress,
                completedAt: completed ? new Date() : null,
                lastStudiedAt: new Date(),
            },
            create: {
                userId,
                topicId,
                status: completed ? ProgressStatus.completed : ProgressStatus.in_progress,
                completedAt: completed ? new Date() : null,
                lastStudiedAt: new Date(),
            },
        });

        sendSuccess(res, updatedProgress, `Topic marked as ${updatedProgress.status}`);
    })
);

export default router;