import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { SessionStatus, TargetTaskType } from '@prisma/client';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { validate } from '../../middleware/validate';
import { idempotency } from '../../middleware/idempotency';
import { asyncHandler, buildPagination, sendSuccess, getISTDateObject } from '../../shared/utils/response';
import { BadRequestError, NotFoundError } from '../../shared/errors/AppError';
import {
    autoTrackDailyTarget,
    recordQuestionProgress,
    updateStreakForUser,
} from '../../shared/utils/progressTracker';

const router = Router();

interface SubmittedAnswerItem {
    questionId: string;
    selectedOptionId?: string | null;
    timeTakenSeconds?: number;
}

const submitQuizSchema = z.object({
    totalTimeSeconds: z.number().int().min(0).default(0),
    answers: z
        .array(
            z.object({
                questionId: z.string().uuid(),
                selectedOptionId: z.string().uuid().nullable().optional(),
                timeTakenSeconds: z.number().int().min(0).optional().default(0),
            })
        )
        .default([]),
});

// 1. GET /api/v1/quizzes
router.get(
    '/',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const page = Math.max(1, Number(req.query.page) || 1);
        const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 20));
        const examinationId =
            typeof req.query.examinationId === 'string' ? req.query.examinationId : undefined;
        const subjectId = typeof req.query.subjectId === 'string' ? req.query.subjectId : undefined;

        const where = {
            isPublished: true,
            ...(examinationId ? { examinationId } : {}),
            ...(subjectId ? { subjectId } : {}),
        };

        const [totalRecords, quizzes] = await Promise.all([
            prisma.quiz.count({ where }),
            prisma.quiz.findMany({
                where,
                include: {
                    subject: { select: { id: true, name: true } },
                    examination: { select: { id: true, name: true } },
                },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);

        sendSuccess(
            res,
            quizzes.map((q) => ({
                id: q.id,
                title: q.title,
                description: q.description,
                quizType: q.quizType,
                totalQuestions: q.totalQuestions,
                durationMinutes: q.durationMinutes,
                marksPerQuestion: Number(q.marksPerQuestion),
                negativeMarksPerQuestion: Number(q.negativeMarksPerQuestion),
                difficultyLevel: q.difficultyLevel,
                isTimed: q.isTimed,
                examination: q.examination,
                subject: q.subject,
            })),
            'Quizzes fetched successfully',
            200,
            buildPagination(page, limit, totalRecords)
        );
    })
);

// 2. POST /api/v1/quizzes/:id/start
router.post(
    '/:id/start',
    authenticate,
    idempotency,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const quizId = String(req.params.id);
        const idempotencyKey =
            typeof req.headers['idempotency-key'] === 'string' ? req.headers['idempotency-key'] : null;

        const quiz = await prisma.quiz.findFirst({
            where: { id: quizId, isPublished: true },
            include: {
                quizQuestions: {
                    orderBy: { displayOrder: 'asc' },
                    include: {
                        question: {
                            include: {
                                options: {
                                    orderBy: { displayOrder: 'asc' },
                                    select: {
                                        id: true,
                                        optionTextEn: true,
                                        optionTextHi: true,
                                        optionImageUrl: true,
                                        displayOrder: true,
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });

        if (!quiz) {
            throw new NotFoundError('Quiz not found or unpublished.');
        }

        const previousAttemptsCount = await prisma.quizAttempt.count({
            where: { userId, quizId },
        });

        const attemptNumber = previousAttemptsCount + 1;
        const totalQuestions = quiz.quizQuestions.length;
        const totalMarks = totalQuestions * Number(quiz.marksPerQuestion);

        const attempt = await prisma.quizAttempt.create({
            data: {
                userId,
                quizId,
                attemptNumber,
                status: SessionStatus.in_progress,
                totalQuestions,
                unattemptedQuestions: totalQuestions,
                totalMarks,
                idempotencyKey,
            },
        });

        sendSuccess(
            res,
            {
                attemptId: attempt.id,
                quizId: quiz.id,
                title: quiz.title,
                attemptNumber: attempt.attemptNumber,
                totalQuestions,
                durationMinutes: quiz.durationMinutes,
                marksPerQuestion: Number(quiz.marksPerQuestion),
                negativeMarksPerQuestion: Number(quiz.negativeMarksPerQuestion),
                startedAt: attempt.startedAt,
                serverCurrentTime: new Date().toISOString(),
                questions: quiz.quizQuestions.map((qq, idx) => ({
                    id: qq.question.id,
                    displayOrder: qq.displayOrder || idx + 1,
                    questionTextEn: qq.question.questionTextEn,
                    questionTextHi: qq.question.questionTextHi,
                    questionImageUrl: qq.question.questionImageUrl,
                    options: qq.question.options,
                })),
            },
            'Quiz attempt started',
            201
        );
    })
);

// 3. POST /api/v1/quizzes/:id/attempts/:attemptId/submit
router.post(
    '/:id/attempts/:attemptId/submit',
    authenticate,
    idempotency,
    validate({ body: submitQuizSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const quizId = String(req.params.id);
        const attemptId = String(req.params.attemptId);
        const totalTimeSeconds = Number(req.body.totalTimeSeconds) || 0;
        const answers = (req.body.answers || []) as SubmittedAnswerItem[];

        const attempt = await prisma.quizAttempt.findFirst({
            where: { id: attemptId, quizId, userId },
        });

        if (!attempt) {
            throw new NotFoundError('Quiz attempt not found.');
        }

        const quiz = await prisma.quiz.findUnique({
            where: { id: quizId },
            include: {
                quizQuestions: {
                    include: {
                        question: {
                            include: { options: true },
                        },
                    },
                },
            },
        });

        if (!quiz) throw new NotFoundError('Quiz not found.');

        const allowedQuestionMap = new Map(
            quiz.quizQuestions.map((qq) => [qq.questionId, qq.question])
        );

        for (const ans of answers) {
            if (!allowedQuestionMap.has(ans.questionId)) {
                throw new BadRequestError(`Question ${ans.questionId} does not belong to this quiz.`);
            }
        }

        const submittedMap = new Map<string, SubmittedAnswerItem>(
            answers.map((a) => [a.questionId, a])
        );

        let attemptedQuestions = 0;
        let correctAnswers = 0;
        let incorrectAnswers = 0;
        const marksPerQ = Number(quiz.marksPerQuestion);
        const negMarksPerQ = Number(quiz.negativeMarksPerQuestion);

        const resultsReview: Array<Record<string, unknown>> = [];

        for (const qq of quiz.quizQuestions) {
            const question = qq.question;
            const correctOption = question.options.find((o) => o.isCorrect);
            const userSub = submittedMap.get(question.id);
            const selectedOptionId = userSub?.selectedOptionId || null;

            let isCorrect = false;
            let marksAwarded = 0;

            if (selectedOptionId) {
                attemptedQuestions += 1;
                isCorrect = correctOption?.id === selectedOptionId;
                if (isCorrect) {
                    correctAnswers += 1;
                    marksAwarded = marksPerQ;
                } else {
                    incorrectAnswers += 1;
                    marksAwarded = -negMarksPerQ;
                }

                await prisma.userAnswer.upsert({
                    where: {
                        quizAttemptId_questionId: {
                            quizAttemptId: attemptId,
                            questionId: question.id,
                        },
                    },
                    update: {
                        selectedOptionId,
                        isCorrect,
                        timeTakenSeconds: userSub?.timeTakenSeconds ?? 0,
                    },
                    create: {
                        userId,
                        questionId: question.id,
                        quizAttemptId: attemptId,
                        selectedOptionId,
                        isCorrect,
                        timeTakenSeconds: userSub?.timeTakenSeconds ?? 0,
                    },
                });

                if (attempt.status !== SessionStatus.completed) {
                    await recordQuestionProgress({
                        userId,
                        subjectId: question.subjectId,
                        topicId: question.topicId,
                        attemptedIncrement: 1,
                        correctIncrement: isCorrect ? 1 : 0,
                    });
                }
            }

            resultsReview.push({
                questionId: question.id,
                selectedOptionId,
                correctOptionId: correctOption?.id || null,
                isCorrect,
                marksAwarded,
                explanationEn: question.explanationEn,
                explanationHi: question.explanationHi,
                explanationImageUrl: question.explanationImageUrl,
            });
        }

        const totalQuestions = quiz.quizQuestions.length;
        const unattemptedQuestions = Math.max(0, totalQuestions - attemptedQuestions);
        const scoreObtained = Number(
            (correctAnswers * marksPerQ - incorrectAnswers * negMarksPerQ).toFixed(2)
        );
        const totalMarks = Number((totalQuestions * marksPerQ).toFixed(2));
        const accuracyPercentage =
            attemptedQuestions > 0
                ? Number(((correctAnswers / attemptedQuestions) * 100).toFixed(2))
                : 0;

        const updatedAttempt = await prisma.quizAttempt.update({
            where: { id: attemptId },
            data: {
                status: SessionStatus.completed,
                totalQuestions,
                attemptedQuestions,
                correctAnswers,
                incorrectAnswers,
                unattemptedQuestions,
                scoreObtained,
                totalMarks,
                accuracyPercentage,
                totalTimeSeconds,
                submittedAt: attempt.submittedAt || new Date(),
            },
        });

        if (attempt.status !== SessionStatus.completed && attemptedQuestions > 0) {
            await autoTrackDailyTarget({
                userId,
                taskType: TargetTaskType.question_practice,
                incrementBy: attemptedQuestions,
                subjectId: quiz.subjectId,
            });
            await updateStreakForUser(userId);
            await prisma.userActivityLog.create({
                data: {
                    userId,
                    activityType: 'quiz_completed',
                    activityDate: getISTDateObject(),
                    metadata: {
                        quizId,
                        attemptId,
                        scoreObtained,
                        accuracyPercentage,
                    },
                },
            });
        }

        sendSuccess(
            res,
            {
                attemptId: updatedAttempt.id,
                quizId: updatedAttempt.quizId,
                attemptNumber: updatedAttempt.attemptNumber,
                totalQuestions,
                attemptedQuestions,
                correctAnswers,
                incorrectAnswers,
                unattemptedQuestions,
                scoreObtained,
                totalMarks,
                accuracyPercentage,
                totalTimeSeconds,
                submittedAt: updatedAttempt.submittedAt,
                resultsReview,
            },
            'Quiz attempt evaluated and finalized'
        );
    })
);

// 4. GET /api/v1/quizzes/:id/attempts
router.get(
    '/:id/attempts',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const quizId = String(req.params.id);

        const attempts = await prisma.quizAttempt.findMany({
            where: { userId, quizId },
            orderBy: { attemptNumber: 'desc' },
        });

        sendSuccess(
            res,
            attempts.map((a) => ({
                attemptId: a.id,
                attemptNumber: a.attemptNumber,
                scoreObtained: Number(a.scoreObtained),
                totalMarks: Number(a.totalMarks),
                accuracy: a.accuracyPercentage !== null ? Number(a.accuracyPercentage) : 0,
                submittedAt: a.submittedAt,
                status: a.status,
            }))
        );
    })
);

export default router;