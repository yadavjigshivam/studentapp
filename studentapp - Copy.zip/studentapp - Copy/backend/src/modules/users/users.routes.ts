import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { validate } from '../../middleware/validate';
import { asyncHandler, sendSuccess } from '../../shared/utils/response';
import { NotFoundError } from '../../shared/errors/AppError';

const router = Router();

const updateProfileSchema = z.object({
    firstName: z.string().trim().min(2).max(100).optional(),
    lastName: z.string().trim().max(100).optional().nullable(),
    phone: z.string().trim().regex(/^\+?[0-9]{10,15}$/).optional().nullable(),
    avatarUrl: z.string().url().optional().nullable(),
});

const enrollExamSchema = z.object({
    examinationId: z.string().uuid('Valid examinationId UUID is required'),
    isPrimary: z.boolean().optional().default(false),
});

const registerDeviceSchema = z.object({
    deviceToken: z.string().min(5, 'FCM deviceToken is required'),
    deviceType: z.enum(['android', 'ios', 'web']).optional().default('android'),
    deviceName: z.string().max(200).optional(),
    osVersion: z.string().max(50).optional(),
    appVersion: z.string().max(20).optional(),
});

// 1. GET /api/v1/users/me
router.get(
    '/me',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const user = await prisma.user.findUnique({
            where: { id: req.user!.id },
            include: {
                streak: true,
                userExaminations: {
                    include: { examination: true },
                    orderBy: [{ isPrimary: 'desc' }, { selectedAt: 'asc' }],
                },
            },
        });

        if (!user) throw new NotFoundError('User profile not found.');

        sendSuccess(res, {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            displayName: user.displayName,
            phone: user.phone,
            avatarUrl: user.avatarUrl,
            role: user.role,
            isEmailVerified: user.isEmailVerified,
            streak: {
                currentStreak: user.streak?.currentStreak ?? 0,
                longestStreak: user.streak?.longestStreak ?? 0,
                lastActiveDate: user.streak?.lastActiveDate ?? null,
            },
            enrolledExaminations: user.userExaminations.map((ue) => ({
                enrollmentId: ue.id,
                examinationId: ue.examinationId,
                name: ue.examination.name,
                slug: ue.examination.slug,
                category: ue.examination.category,
                logoUrl: ue.examination.logoUrl,
                isPrimary: ue.isPrimary,
                enrolledAt: ue.selectedAt,
            })),
        });
    })
);

// 2. PATCH /api/v1/users/me
router.patch(
    '/me',
    authenticate,
    validate({ body: updateProfileSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const existing = await prisma.user.findUnique({ where: { id: req.user!.id } });
        if (!existing) throw new NotFoundError('User not found.');

        const firstName = (req.body.firstName as string | undefined) ?? existing.firstName;
        const lastName =
            req.body.lastName !== undefined ? (req.body.lastName as string | null) : existing.lastName;
        const displayName = lastName ? `${firstName} ${lastName}`.trim() : firstName;

        const updated = await prisma.user.update({
            where: { id: req.user!.id },
            data: {
                firstName,
                lastName,
                displayName,
                phone: req.body.phone !== undefined ? (req.body.phone as string | null) : existing.phone,
                avatarUrl:
                    req.body.avatarUrl !== undefined
                        ? (req.body.avatarUrl as string | null)
                        : existing.avatarUrl,
            },
            select: {
                id: true,
                email: true,
                firstName: true,
                lastName: true,
                displayName: true,
                phone: true,
                avatarUrl: true,
                role: true,
            },
        });

        sendSuccess(res, updated, 'Profile updated successfully');
    })
);

// 3. GET /api/v1/users/me/examinations
router.get(
    '/me/examinations',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const enrollments = await prisma.userExamination.findMany({
            where: { userId: req.user!.id },
            include: { examination: true },
            orderBy: [{ isPrimary: 'desc' }, { selectedAt: 'asc' }],
        });

        const data = enrollments.map((ue) => ({
            enrollmentId: ue.id,
            examinationId: ue.examinationId,
            name: ue.examination.name,
            slug: ue.examination.slug,
            category: ue.examination.category,
            logoUrl: ue.examination.logoUrl,
            isPrimary: ue.isPrimary,
            enrolledAt: ue.selectedAt,
        }));

        sendSuccess(res, data);
    })
);

// 4. POST /api/v1/users/me/examinations
router.post(
    '/me/examinations',
    authenticate,
    validate({ body: enrollExamSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const examinationId = String(req.body.examinationId);
        const isPrimary = Boolean(req.body.isPrimary);
        const userId = req.user!.id;

        const exam = await prisma.examination.findFirst({
            where: { id: examinationId, isActive: true },
        });
        if (!exam) throw new NotFoundError('Examination not found or inactive.');

        const existingCount = await prisma.userExamination.count({ where: { userId } });
        const shouldBePrimary = isPrimary || existingCount === 0;

        const enrollment = await prisma.$transaction(async (tx) => {
            if (shouldBePrimary) {
                await tx.userExamination.updateMany({
                    where: { userId, isPrimary: true },
                    data: { isPrimary: false },
                });
            }

            return tx.userExamination.upsert({
                where: {
                    userId_examinationId: { userId, examinationId },
                },
                update: {
                    isPrimary: shouldBePrimary,
                },
                create: {
                    userId,
                    examinationId,
                    isPrimary: shouldBePrimary,
                },
            });
        });

        sendSuccess(
            res,
            {
                enrollmentId: enrollment.id,
                examinationId: exam.id,
                name: exam.name,
                slug: exam.slug,
                isPrimary: enrollment.isPrimary,
            },
            'Enrolled in examination successfully',
            201
        );
    })
);

// 5. PUT /api/v1/users/me/examinations/:examinationId/primary
router.put(
    '/me/examinations/:examinationId/primary',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const examinationId = String(req.params.examinationId);

        const enrollment = await prisma.userExamination.findUnique({
            where: { userId_examinationId: { userId, examinationId } },
            include: { examination: true },
        });

        if (!enrollment) {
            throw new NotFoundError('You are not enrolled in this examination.');
        }

        await prisma.$transaction([
            prisma.userExamination.updateMany({
                where: { userId, isPrimary: true },
                data: { isPrimary: false },
            }),
            prisma.userExamination.update({
                where: { id: enrollment.id },
                data: { isPrimary: true },
            }),
        ]);

        sendSuccess(
            res,
            {
                examinationId: enrollment.examinationId,
                name: enrollment.examination.name,
                isPrimary: true,
            },
            'Primary examination updated successfully'
        );
    })
);

// 6. DELETE /api/v1/users/me/examinations/:examinationId
router.delete(
    '/me/examinations/:examinationId',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const examinationId = String(req.params.examinationId);

        const enrollment = await prisma.userExamination.findUnique({
            where: { userId_examinationId: { userId, examinationId } },
        });

        if (!enrollment) {
            throw new NotFoundError('Enrollment not found.');
        }

        await prisma.userExamination.delete({ where: { id: enrollment.id } });

        if (enrollment.isPrimary) {
            const nextEnrollment = await prisma.userExamination.findFirst({
                where: { userId },
                orderBy: { selectedAt: 'asc' },
            });
            if (nextEnrollment) {
                await prisma.userExamination.update({
                    where: { id: nextEnrollment.id },
                    data: { isPrimary: true },
                });
            }
        }

        sendSuccess(res, null, 'Examination removed from your list');
    })
);

// 7. Device & App Config Router
export const deviceAndConfigRouter = Router();

deviceAndConfigRouter.post(
    '/devices/register',
    authenticate,
    validate({ body: registerDeviceSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const deviceToken = String(req.body.deviceToken);
        const deviceType = (req.body.deviceType as string | undefined) || 'android';
        const deviceName = (req.body.deviceName as string | undefined) || undefined;
        const osVersion = (req.body.osVersion as string | undefined) || undefined;
        const appVersion = (req.body.appVersion as string | undefined) || undefined;

        const device = await prisma.userDevice.upsert({
            where: {
                userId_deviceToken: { userId, deviceToken },
            },
            update: {
                deviceType,
                deviceName,
                osVersion,
                appVersion,
                isActive: true,
                lastActiveAt: new Date(),
            },
            create: {
                userId,
                deviceToken,
                deviceType,
                deviceName,
                osVersion,
                appVersion,
                isActive: true,
                lastActiveAt: new Date(),
            },
        });

        sendSuccess(res, { deviceId: device.id, isActive: device.isActive }, 'Device token registered');
    })
);

deviceAndConfigRouter.get(
    '/app/config',
    asyncHandler(async (_req: Request, res: Response) => {
        const configs = await prisma.appConfig.findMany({ where: { isActive: true } });
        const map = new Map(configs.map((c) => [c.configKey, c.configValue]));

        sendSuccess(res, {
            minAppVersion: map.get('min_app_version') || '1.0.0',
            latestAppVersion: map.get('latest_app_version') || '1.0.0',
            forceUpdate: map.get('force_update') === 'true',
            maintenanceMode: map.get('maintenance_mode') === 'true',
            maintenanceMessage: map.get('maintenance_message') || null,
            supportEmail: map.get('support_email') || 'support@studyplatform.in',
        });
    })
);

export default router;