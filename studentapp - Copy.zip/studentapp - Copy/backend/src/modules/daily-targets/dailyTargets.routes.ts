import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { TargetTaskType, TargetSourceType } from '@prisma/client';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { validate } from '../../middleware/validate';
import { idempotency } from '../../middleware/idempotency';
import { asyncHandler, sendSuccess, getISTDateObject } from '../../shared/utils/response';
import { NotFoundError } from '../../shared/errors/AppError';
import { updateStreakForUser } from '../../shared/utils/progressTracker';

const router = Router();

const createDailyTargetSchema = z.object({
    targetDate: z
        .string()
        .regex(/^\d{4}-\d{2}-\d{2}$/, 'targetDate must be in YYYY-MM-DD format')
        .optional(),
    tasks: z
        .array(
            z.object({
                taskType: z.nativeEnum(TargetTaskType),
                title: z.string().trim().min(2).max(255),
                description: z.string().max(1000).optional().nullable(),
                targetValue: z.number().int().min(1).max(10000),
                subjectId: z.string().uuid().optional().nullable(),
                chapterId: z.string().uuid().optional().nullable(),
                topicId: z.string().uuid().optional().nullable(),
                sourceType: z.nativeEnum(TargetSourceType).optional().default(TargetSourceType.user_custom),
                isAutoTracked: z.boolean().optional().default(true),
                sortOrder: z.number().int().optional().default(0),
            })
        )
        .min(1, 'At least one target task is required'),
});

function getUnitForTaskType(taskType: TargetTaskType): string {
    switch (taskType) {
        case TargetTaskType.study_time:
            return 'minutes';
        case TargetTaskType.question_practice:
        case TargetTaskType.revision:
            return 'questions';
        case TargetTaskType.topic_completion:
            return 'topics';
    }
}

// 1. GET /api/v1/daily-targets?date=YYYY-MM-DD
router.get(
    '/',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const dateParam = typeof req.query.date === 'string' ? req.query.date : undefined;
        const targetDate = getISTDateObject(dateParam);

        const dailyTarget = await prisma.dailyTarget.findUnique({
            where: {
                userId_targetDate: { userId, targetDate },
            },
            include: {
                tasks: {
                    include: {
                        subject: { select: { id: true, name: true } },
                        topic: { select: { id: true, name: true } },
                    },
                    orderBy: { sortOrder: 'asc' },
                },
            },
        });

        const dateString = targetDate.toISOString().slice(0, 10);

        if (!dailyTarget) {
            sendSuccess(res, {
                targetDate: dateString,
                isCompleted: false,
                completionPercentage: 0,
                tasks: [],
            });
            return;
        }

        sendSuccess(res, {
            id: dailyTarget.id,
            targetDate: dateString,
            isCompleted: dailyTarget.isCompleted,
            completionPercentage: Number(dailyTarget.completionPercentage),
            tasks: dailyTarget.tasks.map((t) => ({
                id: t.id,
                taskType: t.taskType,
                title: t.title,
                description: t.description,
                targetValue: t.targetValue,
                currentValue: t.currentValue,
                unit: getUnitForTaskType(t.taskType),
                sourceType: t.sourceType,
                isCompleted: t.isCompleted,
                isAutoTracked: t.isAutoTracked,
                subjectId: t.subjectId,
                subjectName: t.subject?.name || null,
                topicId: t.topicId,
                topicName: t.topic?.name || null,
            })),
        });
    })
);

// 2. POST /api/v1/daily-targets - Create or append daily target tasks for a date
router.post(
    '/',
    authenticate,
    idempotency,
    validate({ body: createDailyTargetSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const dateParam = typeof req.body.targetDate === 'string' ? req.body.targetDate : undefined;
        const targetDate = getISTDateObject(dateParam);
        const tasksInput = req.body.tasks as Array<{
            taskType: TargetTaskType;
            title: string;
            description?: string | null;
            targetValue: number;
            subjectId?: string | null;
            chapterId?: string | null;
            topicId?: string | null;
            sourceType?: TargetSourceType;
            isAutoTracked?: boolean;
            sortOrder?: number;
        }>;

        const dailyTarget = await prisma.dailyTarget.upsert({
            where: {
                userId_targetDate: { userId, targetDate },
            },
            update: {},
            create: {
                userId,
                targetDate,
                isCompleted: false,
                completionPercentage: 0,
            },
        });

        for (let i = 0; i < tasksInput.length; i++) {
            const t = tasksInput[i];
            await prisma.dailyTargetTask.create({
                data: {
                    dailyTargetId: dailyTarget.id,
                    targetDate,
                    taskType: t.taskType,
                    title: t.title,
                    description: t.description || null,
                    targetValue: t.targetValue,
                    subjectId: t.subjectId || null,
                    chapterId: t.chapterId || null,
                    topicId: t.topicId || null,
                    sourceType: t.sourceType || TargetSourceType.user_custom,
                    isAutoTracked: t.isAutoTracked !== false,
                    sortOrder: t.sortOrder ?? i + 1,
                },
            });
        }

        const allTasks = await prisma.dailyTargetTask.findMany({
            where: { dailyTargetId: dailyTarget.id },
            orderBy: { sortOrder: 'asc' },
        });

        const totalTargetSum = allTasks.reduce((acc, item) => acc + Math.max(1, item.targetValue), 0);
        const totalCurrentSum = allTasks.reduce(
            (acc, item) => acc + Math.min(item.targetValue, item.currentValue),
            0
        );
        const completionPercentage =
            totalTargetSum > 0
                ? Number(((totalCurrentSum / totalTargetSum) * 100).toFixed(2))
                : 0;

        await prisma.dailyTarget.update({
            where: { id: dailyTarget.id },
            data: {
                completionPercentage,
                isCompleted: allTasks.every((item) => item.isCompleted),
            },
        });

        sendSuccess(
            res,
            {
                targetDate: targetDate.toISOString().slice(0, 10),
                tasksCount: allTasks.length,
                completionPercentage,
            },
            'Daily target set successfully',
            201
        );
    })
);

// 3. PATCH /api/v1/daily-targets/tasks/:taskId/complete - Manually toggle task completion
router.patch(
    '/tasks/:taskId/complete',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const taskId = String(req.params.taskId);
        const isCompleted = req.body.isCompleted !== false;

        const task = await prisma.dailyTargetTask.findUnique({
            where: { id: taskId },
            include: { dailyTarget: true },
        });

        if (!task || task.dailyTarget.userId !== userId) {
            throw new NotFoundError('Target task not found.');
        }

        const updatedTask = await prisma.dailyTargetTask.update({
            where: { id: taskId },
            data: {
                isCompleted,
                currentValue: isCompleted ? task.targetValue : task.currentValue,
                completedAt: isCompleted ? new Date() : null,
            },
        });

        const siblingTasks = await prisma.dailyTargetTask.findMany({
            where: { dailyTargetId: task.dailyTargetId },
        });

        const totalTargetSum = siblingTasks.reduce((acc, t) => acc + Math.max(1, t.targetValue), 0);
        const totalCurrentSum = siblingTasks.reduce(
            (acc, t) => acc + Math.min(t.targetValue, t.currentValue),
            0
        );
        const completionPercentage =
            totalTargetSum > 0
                ? Number(((totalCurrentSum / totalTargetSum) * 100).toFixed(2))
                : 0;

        await prisma.dailyTarget.update({
            where: { id: task.dailyTargetId },
            data: {
                completionPercentage,
                isCompleted: siblingTasks.every((t) => t.isCompleted),
            },
        });

        if (isCompleted) {
            await updateStreakForUser(userId);
        }

        sendSuccess(res, updatedTask, 'Target task updated');
    })
);

// 4. DELETE /api/v1/daily-targets/tasks/:taskId - Delete a daily target task
router.delete(
    '/tasks/:taskId',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const taskId = String(req.params.taskId);

        const task = await prisma.dailyTargetTask.findUnique({
            where: { id: taskId },
            include: { dailyTarget: true },
        });

        if (!task || task.dailyTarget.userId !== userId) {
            throw new NotFoundError('Target task not found.');
        }

        await prisma.dailyTargetTask.delete({ where: { id: taskId } });
        sendSuccess(res, null, 'Target task deleted');
    })
);

export default router;