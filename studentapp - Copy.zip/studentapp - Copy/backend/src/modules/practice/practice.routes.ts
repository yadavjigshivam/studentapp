import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { PracticeType, SessionStatus, TargetTaskType, BookmarkType } from '@prisma/client';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { validate } from '../../middleware/validate';
import { idempotency } from '../../middleware/idempotency';
import { asyncHandler, sendSuccess, getISTDateObject } from '../../shared/utils/response';
import { BadRequestError, ConflictError, NotFoundError } from '../../shared/errors/AppError';
import {
    autoTrackDailyTarget,
    recordQuestionProgress,
    updateStreakForUser,
} from '../../shared/utils/progressTracker';

const router = Router();

const startPracticeSchema = z.object({
    practiceType: z.nativeEnum(PracticeType),
    examinationId: z.string().uuid().optional(),
    subjectId: z.string().uuid().optional(),
    chapterId: z.string().uuid().optional(),
    topicId: z.string().uuid().optional(),
    questionCount: z.number().int().min(1).max(100).optional().default(10),
});

const submitPracticeAnswerSchema = z.object({
    questionId: z.string().uuid('Valid questionId is required'),
    selectedOptionId: z.string().uuid('Valid selectedOptionId is required'),
    timeTakenSeconds: z.number().int().min(0).max(3600).optional().default(10),
});

// 1. POST /api/v1/practice-sessions
router.post(
    '/',
    authenticate,
    idempotency,
    validate({ body: startPracticeSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const practiceType = req.body.practiceType as PracticeType;
        const examinationId = req.body.examinationId as string | undefined;
        const subjectId = req.body.subjectId as string | undefined;
        const chapterId = req.body.chapterId as string | undefined;
        const topicId = req.body.topicId as string | undefined;
        const questionCount = Number(req.body.questionCount) || 10;
        const idempotencyKey =
            typeof req.headers['idempotency-key'] === 'string' ? req.headers['idempotency-key'] : null;

        let questionIdsFilter: string[] | undefined;

        if (practiceType === PracticeType.incorrect_questions) {
            const wrongAnswers = await prisma.userAnswer.findMany({
                where: { userId, isCorrect: false },
                select: { questionId: true },
                distinct: ['questionId'],
            });
            questionIdsFilter = wrongAnswers.map((wa) => wa.questionId);
            if (questionIdsFilter.length === 0) {
                throw new NotFoundError('No incorrect questions found in your history yet.');
            }
        } else if (practiceType === PracticeType.bookmarked_review) {
            const bookmarks = await prisma.bookmark.findMany({
                where: { userId, bookmarkType: BookmarkType.question, questionId: { not: null } },
                select: { questionId: true },
            });
            questionIdsFilter = bookmarks
                .map((b) => b.questionId)
                .filter((id): id is string => Boolean(id));
            if (questionIdsFilter.length === 0) {
                throw new NotFoundError('No bookmarked questions found.');
            }
        }

        const questions = await prisma.question.findMany({
            where: {
                isPublished: true,
                ...(questionIdsFilter ? { id: { in: questionIdsFilter } } : {}),
                ...(topicId ? { topicId } : {}),
                ...(chapterId ? { chapterId } : {}),
                ...(subjectId ? { subjectId } : {}),
                ...(examinationId ? { examinationId } : {}),
            },
            include: {
                options: {
                    orderBy: { displayOrder: 'asc' },
                    select: {
                        id: true,
                        optionTextEn: true,
                        optionTextHi: true,
                        optionImageUrl: true,
                        displayOrder: true,
                    },
                },
            },
            take: questionCount,
            orderBy: { createdAt: 'desc' },
        });

        if (questions.length === 0) {
            throw new NotFoundError('No published questions found for the selected criteria.');
        }

        const session = await prisma.practiceSession.create({
            data: {
                userId,
                practiceType,
                examinationId: examinationId || questions[0].examinationId,
                subjectId: subjectId || questions[0].subjectId,
                chapterId: chapterId || questions[0].chapterId,
                topicId: topicId || questions[0].topicId,
                totalQuestions: questions.length,
                unattempted: questions.length,
                idempotencyKey,
                status: SessionStatus.in_progress,
            },
        });

        sendSuccess(
            res,
            {
                sessionId: session.id,
                practiceType: session.practiceType,
                totalQuestions: questions.length,
                questions: questions.map((q) => ({
                    id: q.id,
                    questionTextEn: q.questionTextEn,
                    questionTextHi: q.questionTextHi,
                    questionImageUrl: q.questionImageUrl,
                    questionType: q.questionType,
                    difficultyLevel: q.difficultyLevel,
                    marks: Number(q.marks),
                    negativeMarks: Number(q.negativeMarks),
                    options: q.options,
                })),
            },
            'Practice session initialized',
            201
        );
    })
);

// 2. POST /api/v1/practice-sessions/:sessionId/answer
router.post(
    '/:sessionId/answer',
    authenticate,
    idempotency,
    validate({ body: submitPracticeAnswerSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const sessionId = String(req.params.sessionId);
        const questionId = String(req.body.questionId);
        const selectedOptionId = String(req.body.selectedOptionId);
        const timeTakenSeconds = Number(req.body.timeTakenSeconds) || 10;
        const idempotencyKey =
            typeof req.headers['idempotency-key'] === 'string' ? req.headers['idempotency-key'] : null;

        const session = await prisma.practiceSession.findFirst({
            where: { id: sessionId, userId },
        });

        if (!session) {
            throw new NotFoundError('Practice session not found.');
        }

        const existingAnswer = await prisma.userAnswer.findUnique({
            where: {
                practiceSessionId_questionId: {
                    practiceSessionId: sessionId,
                    questionId,
                },
            },
        });

        if (existingAnswer) {
            throw new ConflictError('You have already submitted an answer for this question in this session.');
        }

        const question = await prisma.question.findUnique({
            where: { id: questionId },
            include: { options: true },
        });

        if (!question) {
            throw new BadRequestError('Question does not exist.');
        }

        const chosenOption = question.options.find((o) => o.id === selectedOptionId);
        if (!chosenOption) {
            throw new BadRequestError('Selected option does not belong to this question.');
        }

        const correctOption = question.options.find((o) => o.isCorrect);
        const isCorrect = chosenOption.isCorrect;

        await prisma.userAnswer.create({
            data: {
                userId,
                questionId,
                practiceSessionId: sessionId,
                selectedOptionId,
                isCorrect,
                timeTakenSeconds,
                idempotencyKey,
            },
        });

        const newAttempted = session.attempted + 1;
        const newCorrect = session.correct + (isCorrect ? 1 : 0);
        const newIncorrect = session.incorrect + (isCorrect ? 0 : 1);
        const newUnattempted = Math.max(0, session.totalQuestions - newAttempted);
        const newAccuracy = Number(((newCorrect / newAttempted) * 100).toFixed(2));

        await prisma.practiceSession.update({
            where: { id: sessionId },
            data: {
                attempted: newAttempted,
                correct: newCorrect,
                incorrect: newIncorrect,
                unattempted: newUnattempted,
                accuracy: newAccuracy,
                totalTimeSeconds: { increment: timeTakenSeconds },
            },
        });

        await recordQuestionProgress({
            userId,
            subjectId: question.subjectId,
            topicId: question.topicId,
            attemptedIncrement: 1,
            correctIncrement: isCorrect ? 1 : 0,
        });

        await autoTrackDailyTarget({
            userId,
            taskType: TargetTaskType.question_practice,
            incrementBy: 1,
            subjectId: question.subjectId,
            topicId: question.topicId,
        });

        await updateStreakForUser(userId);

        sendSuccess(
            res,
            {
                questionId,
                selectedOptionId,
                isCorrect,
                correctOptionId: correctOption?.id || null,
                explanationEn: question.explanationEn,
                explanationHi: question.explanationHi,
                explanationImageUrl: question.explanationImageUrl,
                currentSessionProgress: {
                    attempted: newAttempted,
                    correct: newCorrect,
                    incorrect: newIncorrect,
                },
            },
            'Answer evaluated'
        );
    })
);

// 3. POST /api/v1/practice-sessions/:sessionId/complete
router.post(
    '/:sessionId/complete',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const sessionId = String(req.params.sessionId);

        const session = await prisma.practiceSession.findFirst({
            where: { id: sessionId, userId },
        });

        if (!session) {
            throw new NotFoundError('Practice session not found.');
        }

        const accuracy =
            session.attempted > 0
                ? Number(((session.correct / session.attempted) * 100).toFixed(2))
                : null;

        const completedSession = await prisma.practiceSession.update({
            where: { id: sessionId },
            data: {
                status: SessionStatus.completed,
                completedAt: session.completedAt || new Date(),
                accuracy,
            },
        });

        await prisma.userActivityLog.create({
            data: {
                userId,
                activityType: 'practice_completed',
                activityDate: getISTDateObject(),
                metadata: {
                    sessionId: completedSession.id,
                    attempted: completedSession.attempted,
                    correct: completedSession.correct,
                    accuracy,
                },
            },
        });

        sendSuccess(
            res,
            {
                sessionId: completedSession.id,
                totalQuestions: completedSession.totalQuestions,
                attempted: completedSession.attempted,
                correct: completedSession.correct,
                incorrect: completedSession.incorrect,
                unattempted: completedSession.unattempted,
                accuracy: completedSession.accuracy !== null ? Number(completedSession.accuracy) : null,
                totalTimeSeconds: completedSession.totalTimeSeconds,
                metricsUpdated: {
                    dailyTargetQuestionsIncremented: completedSession.attempted,
                    streakMaintained: true,
                },
            },
            'Practice session completed'
        );
    })
);

export default router;