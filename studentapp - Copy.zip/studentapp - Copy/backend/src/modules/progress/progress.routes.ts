import { Router, Request, Response } from 'express';
import { ProgressStatus, StudySessionStatus, TargetTaskType } from '@prisma/client';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { asyncHandler, sendSuccess, getISTDateObject } from '../../shared/utils/response';

const router = Router();

/**
 * Formats seconds into "Xh Ym" string for dashboard display.
 */
function formatSecondsToHoursMinutes(totalSeconds: number): string {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    return `${hours}h ${String(minutes).padStart(2, '0')}m`;
}

/**
 * Calculates accurate study seconds for a specific IST calendar date (YYYY-MM-DD),
 * splitting midnight-spanning sessions across calendar boundaries in Asia/Kolkata.
 */
async function calculateDailyStudySecondsIST(userId: string, istDateStr: string): Promise<number> {
    const dayStart = new Date(`${istDateStr}T00:00:00+05:30`);
    const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);

    const overlappingSessions = await prisma.studySession.findMany({
        where: {
            userId,
            status: StudySessionStatus.completed,
            startedAt: { lt: dayEnd },
            endedAt: { gt: dayStart },
        },
    });

    let totalSecondsForDay = 0;

    for (const s of overlappingSessions) {
        const effectiveEnd = s.endedAt || s.lastHeartbeatAt || s.startedAt;
        const rawSpanSeconds = Math.max(
            1,
            (effectiveEnd.getTime() - s.startedAt.getTime()) / 1000
        );

        const overlapStartMs = Math.max(s.startedAt.getTime(), dayStart.getTime());
        const overlapEndMs = Math.min(effectiveEnd.getTime(), dayEnd.getTime());
        const overlapSeconds = Math.max(0, (overlapEndMs - overlapStartMs) / 1000);

        const activeRatio = Math.min(1, s.actualDurationSeconds / rawSpanSeconds);
        totalSecondsForDay += Math.round(overlapSeconds * activeRatio);
    }

    return totalSecondsForDay;
}

// 1. GET /api/v1/progress/dashboard-summary - Complete Home Dashboard Snapshot
router.get(
    '/dashboard-summary',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const todayDateObj = getISTDateObject();
        const todayStr = todayDateObj.toISOString().slice(0, 10);

        const dayStartIST = new Date(`${todayStr}T00:00:00+05:30`);
        const dayEndIST = new Date(dayStartIST.getTime() + 24 * 60 * 60 * 1000);

        const [
            primaryEnrollment,
            completedStudySeconds,
            answersToday,
            topicsCompletedToday,
            dailyTarget,
            streak,
        ] = await Promise.all([
            prisma.userExamination.findFirst({
                where: { userId, isPrimary: true },
                include: { examination: true },
            }),
            calculateDailyStudySecondsIST(userId, todayStr),
            prisma.userAnswer.findMany({
                where: {
                    userId,
                    answeredAt: { gte: dayStartIST, lt: dayEndIST },
                },
                select: { isCorrect: true },
            }),
            prisma.topicProgress.count({
                where: {
                    userId,
                    status: ProgressStatus.completed,
                    completedAt: { gte: dayStartIST, lt: dayEndIST },
                },
            }),
            prisma.dailyTarget.findUnique({
                where: {
                    userId_targetDate: { userId, targetDate: todayDateObj },
                },
                include: { tasks: true },
            }),
            prisma.userStreak.findUnique({ where: { userId } }),
        ]);

        const attemptedToday = answersToday.length;
        const correctToday = answersToday.filter((a) => a.isCorrect).length;
        const incorrectToday = attemptedToday - correctToday;
        const accuracyToday =
            attemptedToday > 0 ? Number(((correctToday / attemptedToday) * 100).toFixed(1)) : 0;

        // Extract daily targets or defaults
        let studyTargetMinutes = 120; // Default 2h
        let questionTargetToday = 100;
        let topicTargetToday = 2;

        if (dailyTarget && dailyTarget.tasks.length > 0) {
            const studyTasks = dailyTarget.tasks.filter((t) => t.taskType === TargetTaskType.study_time);
            if (studyTasks.length > 0) {
                studyTargetMinutes = studyTasks.reduce((sum, t) => sum + t.targetValue, 0);
            }
            const qTasks = dailyTarget.tasks.filter(
                (t) => t.taskType === TargetTaskType.question_practice
            );
            if (qTasks.length > 0) {
                questionTargetToday = qTasks.reduce((sum, t) => sum + t.targetValue, 0);
            }
            const topTasks = dailyTarget.tasks.filter(
                (t) => t.taskType === TargetTaskType.topic_completion
            );
            if (topTasks.length > 0) {
                topicTargetToday = topTasks.reduce((sum, t) => sum + t.targetValue, 0);
            }
        }

        const targetSeconds = studyTargetMinutes * 60;

        sendSuccess(res, {
            date: todayStr,
            primaryExamination: primaryEnrollment
                ? {
                    id: primaryEnrollment.examination.id,
                    name: primaryEnrollment.examination.name,
                    slug: primaryEnrollment.examination.slug,
                }
                : null,
            studyTime: {
                completedSeconds: completedStudySeconds,
                targetSeconds,
                formattedCompleted: formatSecondsToHoursMinutes(completedStudySeconds),
                formattedTarget: formatSecondsToHoursMinutes(targetSeconds),
            },
            questions: {
                attemptedToday,
                correctToday,
                incorrectToday,
                accuracyToday,
                targetToday: questionTargetToday,
            },
            topics: {
                completedToday: topicsCompletedToday,
                targetToday: topicTargetToday,
            },
            dailyTargetCompletionPercentage: dailyTarget ? Number(dailyTarget.completionPercentage) : 0,
            streak: {
                currentStreakDays: streak?.currentStreak ?? 0,
                longestStreakDays: streak?.longestStreak ?? 0,
                isActiveToday:
                    streak?.lastActiveDate?.toISOString().slice(0, 10) === todayStr,
            },
        });
    })
);

// 2. GET /api/v1/progress/weak-areas - Diagnostic analysis (20 Q/subject, 10 Q/topic thresholds)
router.get(
    '/weak-areas',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;

        const subjectProgs = await prisma.subjectProgress.findMany({
            where: { userId },
            include: { subject: { select: { id: true, name: true } } },
        });

        const topicProgs = await prisma.topicProgress.findMany({
            where: { userId },
            include: {
                topic: {
                    select: {
                        id: true,
                        name: true,
                        chapter: { select: { subject: { select: { name: true } } } },
                    },
                },
            },
        });

        const weakSubjects: Array<Record<string, unknown>> = [];
        const strongSubjects: Array<Record<string, unknown>> = [];
        const insufficientDataAreas: Array<Record<string, unknown>> = [];

        for (const sp of subjectProgs) {
            if (sp.questionsAttempted < 20) {
                insufficientDataAreas.push({
                    subjectId: sp.subjectId,
                    subjectName: sp.subject.name,
                    attemptedQuestions: sp.questionsAttempted,
                    thresholdRequired: 20,
                    message: `Practice at least ${20 - sp.questionsAttempted} more questions to unlock diagnostic accuracy.`,
                });
                continue;
            }

            const accuracyPercentage = Number(
                ((sp.questionsCorrect / sp.questionsAttempted) * 100).toFixed(2)
            );

            if (accuracyPercentage < 60) {
                weakSubjects.push({
                    subjectId: sp.subjectId,
                    subjectName: sp.subject.name,
                    attemptedQuestions: sp.questionsAttempted,
                    correctQuestions: sp.questionsCorrect,
                    accuracyPercentage,
                    status: 'weak',
                });
            } else if (accuracyPercentage >= 80) {
                strongSubjects.push({
                    subjectId: sp.subjectId,
                    subjectName: sp.subject.name,
                    attemptedQuestions: sp.questionsAttempted,
                    correctQuestions: sp.questionsCorrect,
                    accuracyPercentage,
                    status: 'strong',
                });
            }
        }

        const weakTopics: Array<Record<string, unknown>> = [];
        const strongTopics: Array<Record<string, unknown>> = [];

        for (const tp of topicProgs) {
            if (tp.questionsAttempted < 10) continue;

            const accuracyPercentage = Number(
                ((tp.questionsCorrect / tp.questionsAttempted) * 100).toFixed(2)
            );

            if (accuracyPercentage < 60) {
                weakTopics.push({
                    topicId: tp.topicId,
                    topicName: tp.topic.name,
                    subjectName: tp.topic.chapter.subject.name,
                    attemptedQuestions: tp.questionsAttempted,
                    accuracyPercentage,
                    status: 'weak',
                });
            } else if (accuracyPercentage >= 80) {
                strongTopics.push({
                    topicId: tp.topicId,
                    topicName: tp.topic.name,
                    subjectName: tp.topic.chapter.subject.name,
                    attemptedQuestions: tp.questionsAttempted,
                    accuracyPercentage,
                    status: 'strong',
                });
            }
        }

        sendSuccess(res, {
            weakSubjects,
            strongSubjects,
            weakTopics,
            strongTopics,
            insufficientDataAreas,
        });
    })
);

// 3. GET /api/v1/progress/analytics?days=7 - Weekly / Monthly study & question analytics
router.get(
    '/analytics',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const days = Math.min(30, Math.max(1, Number(req.query.days) || 7));
        const todayDateObj = getISTDateObject();

        const dailyTimeline: Array<Record<string, unknown>> = [];

        for (let i = days - 1; i >= 0; i--) {
            const dateObj = new Date(todayDateObj.getTime() - i * 24 * 60 * 60 * 1000);
            const dateStr = dateObj.toISOString().slice(0, 10);
            const dayStartIST = new Date(`${dateStr}T00:00:00+05:30`);
            const dayEndIST = new Date(dayStartIST.getTime() + 24 * 60 * 60 * 1000);

            const [studySeconds, answers] = await Promise.all([
                calculateDailyStudySecondsIST(userId, dateStr),
                prisma.userAnswer.findMany({
                    where: {
                        userId,
                        answeredAt: { gte: dayStartIST, lt: dayEndIST },
                    },
                    select: { isCorrect: true },
                }),
            ]);

            const attempted = answers.length;
            const correct = answers.filter((a) => a.isCorrect).length;

            dailyTimeline.push({
                date: dateStr,
                studyMinutes: Math.round(studySeconds / 60),
                studySeconds,
                questionsAttempted: attempted,
                questionsCorrect: correct,
                accuracy: attempted > 0 ? Number(((correct / attempted) * 100).toFixed(1)) : 0,
            });
        }

        const subjectBreakdown = await prisma.subjectProgress.findMany({
            where: { userId },
            include: { subject: { select: { id: true, name: true } } },
        });

        sendSuccess(res, {
            periodDays: days,
            dailyTimeline,
            subjects: subjectBreakdown.map((sp) => ({
                subjectId: sp.subjectId,
                subjectName: sp.subject.name,
                studyTimeSeconds: sp.studyTimeSeconds,
                questionsAttempted: sp.questionsAttempted,
                questionsCorrect: sp.questionsCorrect,
                completionPercentage: Number(sp.completionPercentage),
                accuracyPercentage:
                    sp.questionsAttempted >= 20
                        ? Number(((sp.questionsCorrect / sp.questionsAttempted) * 100).toFixed(1))
                        : null,
                strengthLabel:
                    sp.questionsAttempted < 20
                        ? 'insufficient_data'
                        : sp.questionsCorrect / sp.questionsAttempted >= 0.8
                            ? 'strong'
                            : sp.questionsCorrect / sp.questionsAttempted >= 0.6
                                ? 'moderate'
                                : 'weak',
            })),
        });
    })
);

export default router;