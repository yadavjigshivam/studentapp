import { Router, Request, Response } from 'express';
import { z } from 'zod';
import {
    StudySessionStatus,
    ProgressStatus,
    TargetTaskType,
} from '@prisma/client';
import { prisma } from '../../config/database';
import { authenticate } from '../../middleware/authenticate';
import { validate } from '../../middleware/validate';
import { idempotency } from '../../middleware/idempotency';
import { asyncHandler, sendSuccess, getISTDateObject } from '../../shared/utils/response';
import { BadRequestError, NotFoundError } from '../../shared/errors/AppError';
import { autoTrackDailyTarget, updateStreakForUser } from '../../shared/utils/progressTracker';

const router = Router();
const MAX_REALISTIC_SESSION_SECONDS = 12 * 3600; // 12 hours cap

const startSessionSchema = z.object({
    subjectId: z.string().uuid().optional().nullable(),
    chapterId: z.string().uuid().optional().nullable(),
    topicId: z.string().uuid().optional().nullable(),
    isFocusMode: z.boolean().optional().default(false),
    deviceId: z.string().max(100).optional().nullable(),
    localSessionId: z.string().max(100).optional().nullable(),
});

const heartbeatSchema = z.object({
    deviceTimestamp: z.string().datetime().optional(),
    eventType: z.string().max(50).optional().default('heartbeat'),
    elapsedSeconds: z.number().int().min(0).optional(),
    batteryLevel: z.number().min(0).max(1).optional(),
});

const endSessionSchema = z.object({
    notes: z.string().max(5000).optional().nullable(),
    markTopicCompleted: z.boolean().optional().default(false),
});

// 1. GET /api/v1/study-sessions/active - Check for unclosed/interrupted session on app launch
router.get(
    '/active',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;

        const activeSession = await prisma.studySession.findFirst({
            where: {
                userId,
                status: { in: [StudySessionStatus.active, StudySessionStatus.paused] },
            },
            include: {
                subject: { select: { id: true, name: true } },
                topic: { select: { id: true, name: true } },
            },
            orderBy: { startedAt: 'desc' },
        });

        if (!activeSession) {
            sendSuccess(res, { hasActiveSession: false, session: null });
            return;
        }

        const referenceEnd = activeSession.lastHeartbeatAt || new Date();
        const rawElapsed = Math.max(
            0,
            Math.floor((referenceEnd.getTime() - activeSession.startedAt.getTime()) / 1000) -
            activeSession.pausedDurationSeconds
        );

        sendSuccess(res, {
            hasActiveSession: true,
            session: {
                id: activeSession.id,
                subjectId: activeSession.subjectId,
                topicId: activeSession.topicId,
                subjectName: activeSession.subject?.name || 'General Study',
                topicName: activeSession.topic?.name || 'Self Study',
                startedAt: activeSession.startedAt,
                lastHeartbeatAt: activeSession.lastHeartbeatAt,
                status: activeSession.status,
                isFocusMode: activeSession.isFocusMode,
                approximateElapsedSeconds: Math.min(rawElapsed, MAX_REALISTIC_SESSION_SECONDS),
            },
        });
    })
);

// 2. POST /api/v1/study-sessions - Start study session (auto-closes any dangling active session)
router.post(
    '/',
    authenticate,
    idempotency,
    validate({ body: startSessionSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const subjectId = (req.body.subjectId as string | null | undefined) || null;
        const chapterId = (req.body.chapterId as string | null | undefined) || null;
        const topicId = (req.body.topicId as string | null | undefined) || null;
        const isFocusMode = Boolean(req.body.isFocusMode);
        const deviceId = (req.body.deviceId as string | null | undefined) || null;
        const localSessionId = (req.body.localSessionId as string | null | undefined) || null;
        const idempotencyKey =
            typeof req.headers['idempotency-key'] === 'string' ? req.headers['idempotency-key'] : null;

        // Auto-close any existing active/paused session to prevent duplicate concurrent timers
        const openSessions = await prisma.studySession.findMany({
            where: {
                userId,
                status: { in: [StudySessionStatus.active, StudySessionStatus.paused] },
            },
        });

        const now = new Date();
        for (const prev of openSessions) {
            const effectiveEnd = prev.lastHeartbeatAt || now;
            const calcSeconds = Math.min(
                MAX_REALISTIC_SESSION_SECONDS,
                Math.max(
                    0,
                    Math.floor((effectiveEnd.getTime() - prev.startedAt.getTime()) / 1000) -
                    prev.pausedDurationSeconds
                )
            );
            await prisma.studySession.update({
                where: { id: prev.id },
                data: {
                    endedAt: effectiveEnd,
                    actualDurationSeconds: calcSeconds,
                    status: StudySessionStatus.completed,
                },
            });
        }

        const session = await prisma.studySession.create({
            data: {
                userId,
                subjectId,
                chapterId,
                topicId,
                isFocusMode,
                deviceId,
                localSessionId,
                idempotencyKey,
                startedAt: now,
                lastHeartbeatAt: now,
                status: StudySessionStatus.active,
            },
            include: {
                subject: { select: { name: true } },
                topic: { select: { name: true } },
            },
        });

        sendSuccess(
            res,
            {
                sessionId: session.id,
                subjectName: session.subject?.name || 'General Study',
                topicName: session.topic?.name || 'General Topic',
                startedAt: session.startedAt,
                status: session.status,
                isFocusMode: session.isFocusMode,
            },
            'Study session initiated',
            201
        );
    })
);

// 3. POST /api/v1/study-sessions/:id/heartbeat - Record periodic client heartbeat
router.post(
    '/:id/heartbeat',
    authenticate,
    validate({ body: heartbeatSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const sessionId = String(req.params.id);

        const session = await prisma.studySession.findFirst({
            where: { id: sessionId, userId },
        });

        if (!session) throw new NotFoundError('Study session not found.');

        const now = new Date();
        const deviceTime = req.body.deviceTimestamp ? new Date(String(req.body.deviceTimestamp)) : now;

        await prisma.$transaction([
            prisma.studySession.update({
                where: { id: sessionId },
                data: { lastHeartbeatAt: now },
            }),
            prisma.studySessionEvent.create({
                data: {
                    studySessionId: sessionId,
                    eventType: String(req.body.eventType || 'heartbeat'),
                    deviceTimestamp: deviceTime,
                    serverTimestamp: now,
                    payload: {
                        elapsedSeconds: req.body.elapsedSeconds,
                        batteryLevel: req.body.batteryLevel,
                    },
                },
            }),
        ]);

        sendSuccess(res, {
            sessionId,
            acknowledgedAt: now.toISOString(),
            serverStatus: session.status,
        });
    })
);

// 4. PATCH /api/v1/study-sessions/:id/pause - Pause study session
router.patch(
    '/:id/pause',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const sessionId = String(req.params.id);

        const session = await prisma.studySession.findFirst({
            where: { id: sessionId, userId },
        });

        if (!session) throw new NotFoundError('Study session not found.');
        if (session.status === StudySessionStatus.paused) {
            throw new BadRequestError('Session is already paused.');
        }
        if (session.status !== StudySessionStatus.active) {
            throw new BadRequestError('Only an active session can be paused.');
        }

        const now = new Date();
        await prisma.$transaction([
            prisma.studySession.update({
                where: { id: sessionId },
                data: { status: StudySessionStatus.paused, lastHeartbeatAt: now },
            }),
            prisma.studySessionPause.create({
                data: {
                    studySessionId: sessionId,
                    pausedAt: now,
                },
            }),
        ]);

        sendSuccess(res, { sessionId, status: StudySessionStatus.paused, pausedAt: now }, 'Session paused');
    })
);

// 5. PATCH /api/v1/study-sessions/:id/resume - Resume paused study session
router.patch(
    '/:id/resume',
    authenticate,
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const sessionId = String(req.params.id);

        const session = await prisma.studySession.findFirst({
            where: { id: sessionId, userId },
            include: {
                pauses: {
                    where: { resumedAt: null },
                    orderBy: { pausedAt: 'desc' },
                    take: 1,
                },
            },
        });

        if (!session) throw new NotFoundError('Study session not found.');
        if (session.status !== StudySessionStatus.paused) {
            throw new BadRequestError('Session is not paused.');
        }

        const now = new Date();
        const openPause = session.pauses[0];
        const pauseSeconds = openPause
            ? Math.max(0, Math.floor((now.getTime() - openPause.pausedAt.getTime()) / 1000))
            : 0;

        await prisma.$transaction([
            ...(openPause
                ? [
                    prisma.studySessionPause.update({
                        where: { id: openPause.id },
                        data: { resumedAt: now, durationSeconds: pauseSeconds },
                    }),
                ]
                : []),
            prisma.studySession.update({
                where: { id: sessionId },
                data: {
                    status: StudySessionStatus.active,
                    pausedDurationSeconds: { increment: pauseSeconds },
                    lastHeartbeatAt: now,
                },
            }),
        ]);

        sendSuccess(
            res,
            {
                sessionId,
                status: StudySessionStatus.active,
                totalPausedSeconds: session.pausedDurationSeconds + pauseSeconds,
            },
            'Session resumed'
        );
    })
);

// 6. PATCH /api/v1/study-sessions/:id/end - End study session & update progress
router.patch(
    '/:id/end',
    authenticate,
    validate({ body: endSessionSchema }),
    asyncHandler(async (req: Request, res: Response) => {
        const userId = req.user!.id;
        const sessionId = String(req.params.id);
        const notes = (req.body.notes as string | null | undefined) || null;
        const markTopicCompleted = Boolean(req.body.markTopicCompleted);

        const session = await prisma.studySession.findFirst({
            where: { id: sessionId, userId },
            include: {
                pauses: {
                    where: { resumedAt: null },
                },
            },
        });

        if (!session) throw new NotFoundError('Study session not found.');

        const now = new Date();
        let additionalPauseSeconds = 0;

        for (const openPause of session.pauses) {
            const pSec = Math.max(0, Math.floor((now.getTime() - openPause.pausedAt.getTime()) / 1000));
            additionalPauseSeconds += pSec;
            await prisma.studySessionPause.update({
                where: { id: openPause.id },
                data: { resumedAt: now, durationSeconds: pSec },
            });
        }

        const totalPausedSeconds = session.pausedDurationSeconds + additionalPauseSeconds;
        const rawElapsedSeconds = Math.max(
            0,
            Math.floor((now.getTime() - session.startedAt.getTime()) / 1000) - totalPausedSeconds
        );
        const actualDurationSeconds = Math.min(rawElapsedSeconds, MAX_REALISTIC_SESSION_SECONDS);

        const updatedSession = await prisma.studySession.update({
            where: { id: sessionId },
            data: {
                endedAt: now,
                actualDurationSeconds,
                pausedDurationSeconds: totalPausedSeconds,
                status: StudySessionStatus.completed,
                notes: notes ?? session.notes,
            },
        });

        // Update Topic Progress
        if (session.topicId) {
            await prisma.topicProgress.upsert({
                where: { userId_topicId: { userId, topicId: session.topicId } },
                update: {
                    studyTimeSeconds: { increment: actualDurationSeconds },
                    lastStudiedAt: now,
                    ...(markTopicCompleted
                        ? { status: ProgressStatus.completed, completedAt: now }
                        : {}),
                },
                create: {
                    userId,
                    topicId: session.topicId,
                    studyTimeSeconds: actualDurationSeconds,
                    lastStudiedAt: now,
                    status: markTopicCompleted ? ProgressStatus.completed : ProgressStatus.in_progress,
                    completedAt: markTopicCompleted ? now : null,
                },
            });
        }

        // Update Subject Progress
        if (session.subjectId) {
            const totalTopics = await prisma.topic.count({
                where: { isActive: true, chapter: { subjectId: session.subjectId, isActive: true } },
            });
            const completedTopics = await prisma.topicProgress.count({
                where: {
                    userId,
                    status: ProgressStatus.completed,
                    topic: { chapter: { subjectId: session.subjectId } },
                },
            });
            const completionPercentage =
                totalTopics > 0 ? Number(((completedTopics / totalTopics) * 100).toFixed(2)) : 0;

            await prisma.subjectProgress.upsert({
                where: { userId_subjectId: { userId, subjectId: session.subjectId } },
                update: {
                    totalTopics,
                    completedTopics,
                    studyTimeSeconds: { increment: actualDurationSeconds },
                    completionPercentage,
                    lastStudiedAt: now,
                },
                create: {
                    userId,
                    subjectId: session.subjectId,
                    totalTopics,
                    completedTopics,
                    studyTimeSeconds: actualDurationSeconds,
                    completionPercentage,
                    lastStudiedAt: now,
                },
            });
        }

        const minutesStudied = Math.floor(actualDurationSeconds / 60);
        if (minutesStudied > 0) {
            await autoTrackDailyTarget({
                userId,
                taskType: TargetTaskType.study_time,
                incrementBy: minutesStudied,
                subjectId: session.subjectId,
                topicId: session.topicId,
            });
        }

        if (markTopicCompleted) {
            await autoTrackDailyTarget({
                userId,
                taskType: TargetTaskType.topic_completion,
                incrementBy: 1,
                subjectId: session.subjectId,
                topicId: session.topicId,
            });
        }

        if (actualDurationSeconds >= 300 || markTopicCompleted) {
            await updateStreakForUser(userId);
        }

        await prisma.userActivityLog.create({
            data: {
                userId,
                activityType: 'study_session_end',
                activityDate: getISTDateObject(),
                metadata: {
                    sessionId: updatedSession.id,
                    actualDurationSeconds,
                    markTopicCompleted,
                },
            },
        });

        sendSuccess(
            res,
            {
                sessionId: updatedSession.id,
                status: updatedSession.status,
                startedAt: updatedSession.startedAt,
                endedAt: updatedSession.endedAt,
                actualDurationSeconds: updatedSession.actualDurationSeconds,
                pausedDurationSeconds: updatedSession.pausedDurationSeconds,
                topicMarkedCompleted: markTopicCompleted,
                dailyTargetUpdated: {
                    minutesAdded: minutesStudied,
                },
            },
            'Study session completed'
        );
    })
);

export default router;