import express, { Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import hpp from 'hpp';
import path from 'path';
import { env } from './config/env';
import { apiRateLimiter } from './middleware/rateLimiter';
import { errorHandler } from './middleware/errorHandler';
import { NotFoundError } from './shared/errors/AppError';
import { sendSuccess } from './shared/utils/response';

// Route Imports
import authRoutes from './modules/auth/auth.routes';
import usersRoutes, { deviceAndConfigRouter } from './modules/users/users.routes';
import examinationsRoutes from './modules/examinations/examinations.routes';
import practiceRoutes from './modules/practice/practice.routes';
import quizzesRoutes from './modules/quizzes/quizzes.routes';
import studySessionsRoutes from './modules/study-sessions/studySessions.routes';
import dailyTargetsRoutes from './modules/daily-targets/dailyTargets.routes';
import { bookmarksRouter, focusModeRouter } from './modules/bookmarks/bookmarks.routes';
import progressRoutes from './modules/progress/progress.routes';
import uploadsRoutes from './modules/uploads/uploads.routes';
import adminRoutes from './modules/admin/admin.routes';

const app = express();

// 1. Global Security & Performance Middlewares
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(
    cors({
        origin: env.CORS_ORIGIN === '*' ? '*' : env.CORS_ORIGIN.split(','),
        credentials: true,
    })
);
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(hpp());

// Serve locally uploaded files in dev mode
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// 2. Health Check Endpoint
app.get('/health', (_req: Request, res: Response) => {
    sendSuccess(res, {
        status: 'healthy',
        environment: env.NODE_ENV,
        uptimeSeconds: Math.floor(process.uptime()),
    });
});

// 3. API v1 Routes
app.use('/api/v1', apiRateLimiter);
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/users', usersRoutes);
app.use('/api/v1', deviceAndConfigRouter); // /devices/register and /app/config
app.use('/api/v1', examinationsRoutes); // /examinations, /topics/:topicId/notes
app.use('/api/v1/practice-sessions', practiceRoutes);
app.use('/api/v1/quizzes', quizzesRoutes);
app.use('/api/v1/study-sessions', studySessionsRoutes);
app.use('/api/v1/daily-targets', dailyTargetsRoutes);
app.use('/api/v1/bookmarks', bookmarksRouter);
app.use('/api/v1', focusModeRouter); // /focus-mode/settings and /focus-sessions
app.use('/api/v1/progress', progressRoutes);
app.use('/api/v1/uploads', uploadsRoutes);
app.use('/api/v1/admin', adminRoutes);

// 4. 404 Handler for unmatched routes
app.use((req: Request, _res: Response, next) => {
    next(new NotFoundError(`Route ${req.method} ${req.originalUrl} not found.`));
});

// 5. Centralized Error Handler
app.use(errorHandler);

export default app;