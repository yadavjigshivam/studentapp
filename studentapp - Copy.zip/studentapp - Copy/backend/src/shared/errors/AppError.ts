export interface ErrorDetail {
    field?: string;
    issue: string;
}

export class AppError extends Error {
    public readonly statusCode: number;
    public readonly code: string;
    public readonly details?: ErrorDetail[];
    public readonly isOperational: boolean;

    constructor(
        message: string,
        statusCode: number = 500,
        code: string = 'INTERNAL_ERROR',
        details?: ErrorDetail[],
        isOperational: boolean = true
    ) {
        super(message);
        Object.setPrototypeOf(this, new.target.prototype);
        this.statusCode = statusCode;
        this.code = code;
        this.details = details;
        this.isOperational = isOperational;
        Error.captureStackTrace(this);
    }
}

export class ValidationError extends AppError {
    constructor(message = 'The provided payload contains invalid or missing fields.', details?: ErrorDetail[]) {
        super(message, 422, 'VALIDATION_FAILED', details);
    }
}

export class AuthenticationError extends AppError {
    constructor(message = 'Authentication failed or token is invalid.') {
        super(message, 401, 'AUTHENTICATION_FAILED');
    }
}

export class AuthorizationError extends AppError {
    constructor(message = 'You do not have permission to perform this action.') {
        super(message, 403, 'FORBIDDEN');
    }
}

export class NotFoundError extends AppError {
    constructor(message = 'Requested resource was not found.') {
        super(message, 404, 'NOT_FOUND');
    }
}

export class ConflictError extends AppError {
    constructor(message = 'Resource already exists or state conflict occurred.') {
        super(message, 409, 'CONFLICT');
    }
}

export class BadRequestError extends AppError {
    constructor(message = 'Bad request.') {
        super(message, 400, 'BAD_REQUEST');
    }
}

export class RateLimitError extends AppError {
    constructor(message = 'Too many requests. Please try again later.') {
        super(message, 429, 'RATE_LIMIT_EXCEEDED');
    }
}