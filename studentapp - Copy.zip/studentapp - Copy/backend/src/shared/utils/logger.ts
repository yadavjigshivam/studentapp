import winston from 'winston';
import { env } from '../../config/env';

export const logger = winston.createLogger({
    level: env.NODE_ENV === 'development' ? 'debug' : 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    defaultMeta: { service: 'study-platform-api' },
    transports: [
        new winston.transports.Console({
            format:
                env.NODE_ENV === 'development'
                    ? winston.format.combine(winston.format.colorize(), winston.format.simple())
                    : winston.format.json(),
        }),
    ],
});