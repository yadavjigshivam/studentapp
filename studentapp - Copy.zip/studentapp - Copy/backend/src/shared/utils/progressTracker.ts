import { TargetTaskType, ProgressStatus } from '@prisma/client';
import { prisma } from '../../config/database';
import { getISTDateObject } from './response';

/**
 * Updates user's daily study streak based on IST calendar date.
 */
export async function updateStreakForUser(userId: string): Promise<void> {
    const todayIST = getISTDateObject();
    const yesterdayIST = new Date(todayIST.getTime() - 24 * 60 * 60 * 1000);

    const streak = await prisma.userStreak.findUnique({ where: { userId } });

    if (!streak) {
        await prisma.userStreak.create({
            data: {
                userId,
                currentStreak: 1,
                longestStreak: 1,
                lastActiveDate: todayIST,
                streakStartDate: todayIST,
            },
        });
        return;
    }

    if (streak.lastActiveDate) {
        const lastActiveTime = new Date(streak.lastActiveDate).getTime();
        if (lastActiveTime === todayIST.getTime()) {
            // Already counted for today
            return;
        }

        if (lastActiveTime === yesterdayIST.getTime()) {
            const nextStreak = streak.currentStreak + 1;
            await prisma.userStreak.update({
                where: { userId },
                data: {
                    currentStreak: nextStreak,
                    longestStreak: Math.max(streak.longestStreak, nextStreak),
                    lastActiveDate: todayIST,
                },
            });
            return;
        }
    }

    // Gap of 1+ days -> reset streak to 1
    await prisma.userStreak.update({
        where: { userId },
        data: {
            currentStreak: 1,
            longestStreak: Math.max(streak.longestStreak, 1),
            lastActiveDate: todayIST,
            streakStartDate: todayIST,
        },
    });
}

/**
 * Automatically increments matching Daily Target Tasks for today (IST) and recalculates overall target percentage.
 */
export async function autoTrackDailyTarget(params: {
    userId: string;
    taskType: TargetTaskType;
    incrementBy: number;
    subjectId?: string | null;
    topicId?: string | null;
}): Promise<number> {
    if (params.incrementBy <= 0) return 0;

    const todayIST = getISTDateObject();
    const dailyTarget = await prisma.dailyTarget.findUnique({
        where: {
            userId_targetDate: {
                userId: params.userId,
                targetDate: todayIST,
            },
        },
        include: { tasks: true },
    });

    if (!dailyTarget || dailyTarget.tasks.length === 0) {
        return 0;
    }

    // Match tasks of same type that are auto-tracked and either general or matching subject/topic
    const matchingTasks = dailyTarget.tasks.filter((task) => {
        if (!task.isAutoTracked || task.taskType !== params.taskType) return false;
        if (task.topicId && params.topicId && task.topicId !== params.topicId) return false;
        if (task.subjectId && params.subjectId && task.subjectId !== params.subjectId) return false;
        return true;
    });

    for (const task of matchingTasks) {
        const newValue = Math.min(task.targetValue, task.currentValue + params.incrementBy);
        const nowCompleted = newValue >= task.targetValue;

        await prisma.dailyTargetTask.update({
            where: { id: task.id },
            data: {
                currentValue: newValue,
                isCompleted: nowCompleted,
                completedAt: nowCompleted && !task.isCompleted ? new Date() : task.completedAt,
            },
        });
    }

    // Recalculate daily target completion percentage
    const updatedTasks = await prisma.dailyTargetTask.findMany({
        where: { dailyTargetId: dailyTarget.id },
    });

    const totalTargetSum = updatedTasks.reduce((acc, t) => acc + Math.max(1, t.targetValue), 0);
    const totalCurrentSum = updatedTasks.reduce(
        (acc, t) => acc + Math.min(t.targetValue, t.currentValue),
        0
    );
    const completionPercentage =
        totalTargetSum > 0 ? Math.min(100, Number(((totalCurrentSum / totalTargetSum) * 100).toFixed(2))) : 0;
    const allCompleted = updatedTasks.every((t) => t.isCompleted);

    await prisma.dailyTarget.update({
        where: { id: dailyTarget.id },
        data: {
            completionPercentage,
            isCompleted: allCompleted,
        },
    });

    return params.incrementBy;
}

/**
 * Updates topic and subject question counters after answering questions.
 */
export async function recordQuestionProgress(params: {
    userId: string;
    subjectId: string;
    topicId?: string | null;
    attemptedIncrement: number;
    correctIncrement: number;
}): Promise<void> {
    const now = new Date();

    if (params.topicId) {
        const existingTopicProg = await prisma.topicProgress.findUnique({
            where: { userId_topicId: { userId: params.userId, topicId: params.topicId } },
        });

        await prisma.topicProgress.upsert({
            where: { userId_topicId: { userId: params.userId, topicId: params.topicId } },
            update: {
                questionsAttempted: { increment: params.attemptedIncrement },
                questionsCorrect: { increment: params.correctIncrement },
                lastStudiedAt: now,
                status:
                    existingTopicProg?.status === ProgressStatus.not_started
                        ? ProgressStatus.in_progress
                        : undefined,
            },
            create: {
                userId: params.userId,
                topicId: params.topicId,
                status: ProgressStatus.in_progress,
                questionsAttempted: params.attemptedIncrement,
                questionsCorrect: params.correctIncrement,
                lastStudiedAt: now,
            },
        });
    }

    const totalTopicsInSubject = await prisma.topic.count({
        where: { isActive: true, chapter: { subjectId: params.subjectId, isActive: true } },
    });

    const completedTopicsInSubject = await prisma.topicProgress.count({
        where: {
            userId: params.userId,
            status: ProgressStatus.completed,
            topic: { chapter: { subjectId: params.subjectId } },
        },
    });

    const completionPercentage =
        totalTopicsInSubject > 0
            ? Number(((completedTopicsInSubject / totalTopicsInSubject) * 100).toFixed(2))
            : 0;

    await prisma.subjectProgress.upsert({
        where: { userId_subjectId: { userId: params.userId, subjectId: params.subjectId } },
        update: {
            totalTopics: totalTopicsInSubject,
            completedTopics: completedTopicsInSubject,
            questionsAttempted: { increment: params.attemptedIncrement },
            questionsCorrect: { increment: params.correctIncrement },
            completionPercentage,
            lastStudiedAt: now,
        },
        create: {
            userId: params.userId,
            subjectId: params.subjectId,
            totalTopics: totalTopicsInSubject,
            completedTopics: completedTopicsInSubject,
            questionsAttempted: params.attemptedIncrement,
            questionsCorrect: params.correctIncrement,
            completionPercentage,
            lastStudiedAt: now,
        },
    });
}