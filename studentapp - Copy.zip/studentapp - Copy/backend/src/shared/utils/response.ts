import { Response, Request, NextFunction, RequestHandler } from 'express';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';

export interface PaginationMeta {
    page: number;
    limit: number;
    totalRecords: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
}

export function sendSuccess<T>(
    res: Response,
    data: T,
    message: string = 'Operation completed successfully',
    statusCode: number = 200,
    pagination?: PaginationMeta
): Response {
    const requestId = (res.req?.headers['x-request-id'] as string) || `req_${uuidv4().replace(/-/g, '').slice(0, 12)}`;
    const payload: Record<string, unknown> = {
        success: true,
        data,
        message,
    };

    if (pagination) {
        payload.pagination = pagination;
    }

    payload.meta = {
        timestamp: new Date().toISOString(),
        requestId,
    };

    return res.status(statusCode).json(payload);
}

export function buildPagination(page: number, limit: number, totalRecords: number): PaginationMeta {
    const totalPages = Math.max(1, Math.ceil(totalRecords / limit));
    return {
        page,
        limit,
        totalRecords,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
    };
}

/**
 * Generates a cryptographic SHA-256 hash of a raw token string.
 */
export function hashToken(rawToken: string): string {
    return crypto.createHash('sha256').update(rawToken).digest('hex');
}

/**
 * Generates a high-entropy 64-character hex secret token.
 */
export function generateOpaqueToken(): string {
    return crypto.randomBytes(32).toString('hex');
}

/**
 * Returns current date in Asia/Kolkata (YYYY-MM-DD) as a UTC Date object at 00:00:00Z for @db.Date columns.
 */
export function getISTDateObject(dateString?: string): Date {
    if (dateString && /^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
        return new Date(`${dateString}T00:00:00.000Z`);
    }
    const istString = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Kolkata',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    }).format(new Date());
    return new Date(`${istString}T00:00:00.000Z`);
}

/**
 * Wraps async route handlers to forward rejected promises to Express error middleware.
 */
export const asyncHandler = (
    fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>
): RequestHandler => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};