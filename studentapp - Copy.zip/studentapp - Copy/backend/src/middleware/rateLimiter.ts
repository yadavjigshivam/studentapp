import rateLimit from 'express-rate-limit';
import { RateLimitError } from '../shared/errors/AppError';

export const registerRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (_req, _res, next) => {
        next(new RateLimitError('Too many registration attempts from this IP. Please try again after 15 minutes.'));
    },
});

export const loginRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (_req, _res, next) => {
        next(new RateLimitError('Too many login attempts. Please wait 15 minutes before retrying.'));
    },
});

export const passwordResetRateLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 5,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (_req, _res, next) => {
        next(new RateLimitError('Too many password reset requests. Please try again in an hour.'));
    },
});

export const apiRateLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 120,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (_req, _res, next) => {
        next(new RateLimitError('API rate limit exceeded. Please slow down your requests.'));
    },
});