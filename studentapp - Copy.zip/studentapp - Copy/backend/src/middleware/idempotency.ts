import { Request, Response, NextFunction } from 'express';

interface CachedIdempotentResponse {
    statusCode: number;
    body: unknown;
    expiresAt: number;
}

const idempotencyCache = new Map<string, CachedIdempotentResponse>();
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

// Periodic cleanup of expired idempotency keys
setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of idempotencyCache.entries()) {
        if (entry.expiresAt < now) {
            idempotencyCache.delete(key);
        }
    }
}, 5 * 60 * 1000).unref();

export const idempotency = (req: Request, res: Response, next: NextFunction): void => {
    const rawKey = req.headers['idempotency-key'];
    if (!rawKey || typeof rawKey !== 'string') {
        next();
        return;
    }

    const userScope = req.user?.id || req.ip || 'anonymous';
    const cacheKey = `${userScope}:${req.method}:${req.originalUrl}:${rawKey}`;

    const existing = idempotencyCache.get(cacheKey);
    if (existing && existing.expiresAt > Date.now()) {
        res.setHeader('X-Idempotent-Replay', 'true');
        res.status(existing.statusCode).json(existing.body);
        return;
    }

    const originalJson = res.json.bind(res);
    res.json = (body: unknown): Response => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
            idempotencyCache.set(cacheKey, {
                statusCode: res.statusCode,
                body,
                expiresAt: Date.now() + CACHE_TTL_MS,
            });
        }
        return originalJson(body);
    };

    next();
};