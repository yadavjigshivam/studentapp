import { Request, Response, NextFunction } from 'express';
import { Prisma } from '@prisma/client';
import { v4 as uuidv4 } from 'uuid';
import { AppError } from '../shared/errors/AppError';
import { logger } from '../shared/utils/logger';
import { env } from '../config/env';

export const errorHandler = (
    err: Error,
    req: Request,
    res: Response,
    _next: NextFunction
): void => {
    const requestId = (req.headers['x-request-id'] as string) || `req_${uuidv4().replace(/-/g, '').slice(0, 12)}`;

    if (err instanceof AppError) {
        res.status(err.statusCode).json({
            success: false,
            error: {
                code: err.code,
                message: err.message,
                ...(err.details ? { details: err.details } : {}),
            },
            meta: {
                timestamp: new Date().toISOString(),
                requestId,
            },
        });
        return;
    }

    // Handle Prisma Unique Constraint Violations (P2002)
    if (err instanceof Prisma.PrismaClientKnownRequestError) {
        if (err.code === 'P2002') {
            const target = (err.meta?.target as string[])?.join(', ') || 'field';
            res.status(409).json({
                success: false,
                error: {
                    code: 'DUPLICATE_RESOURCE',
                    message: `A record with this ${target} already exists.`,
                },
                meta: {
                    timestamp: new Date().toISOString(),
                    requestId,
                },
            });
            return;
        }

        if (err.code === 'P2025') {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'The requested database record was not found.',
                },
                meta: {
                    timestamp: new Date().toISOString(),
                    requestId,
                },
            });
            return;
        }
    }

    logger.error('Unhandled Server Exception:', {
        requestId,
        path: req.originalUrl,
        method: req.method,
        error: err.message,
        stack: err.stack,
    });

    res.status(500).json({
        success: false,
        error: {
            code: 'INTERNAL_SERVER_ERROR',
            message:
                env.NODE_ENV === 'development'
                    ? err.message
                    : 'An unexpected error occurred on the server.',
        },
        meta: {
            timestamp: new Date().toISOString(),
            requestId,
        },
    });
};