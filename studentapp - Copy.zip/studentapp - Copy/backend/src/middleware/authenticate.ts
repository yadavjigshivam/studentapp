import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UserRole } from '@prisma/client';
import { env } from '../config/env';
import { prisma } from '../config/database';
import { AuthenticationError, AuthorizationError } from '../shared/errors/AppError';

export interface AuthUserPayload {
    id: string;
    email: string;
    role: UserRole;
}

declare global {
    namespace Express {
        interface Request {
            user?: AuthUserPayload;
        }
    }
}

interface JwtDecodedPayload {
    sub: string;
    email: string;
    role: UserRole;
    iat?: number;
    exp?: number;
}

export const authenticate = async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new AuthenticationError('Missing or malformed Authorization header.');
        }

        const token = authHeader.split(' ')[1];
        if (!token) {
            throw new AuthenticationError('Access token is required.');
        }

        const decoded = jwt.verify(token, env.JWT_SECRET) as JwtDecodedPayload;

        const user = await prisma.user.findUnique({
            where: { id: decoded.sub },
            select: { id: true, email: true, role: true, isActive: true },
        });

        if (!user) {
            throw new AuthenticationError('User account associated with this token no longer exists.');
        }

        if (!user.isActive) {
            throw new AuthorizationError('Your account has been deactivated. Please contact support.');
        }

        req.user = {
            id: user.id,
            email: user.email,
            role: user.role,
        };

        next();
    } catch (error) {
        if (error instanceof AuthenticationError || error instanceof AuthorizationError) {
            next(error);
            return;
        }
        next(new AuthenticationError('Invalid or expired access token.'));
    }
};