import { Request, Response, NextFunction } from 'express';
import { UserRole } from '@prisma/client';
import { AuthenticationError, AuthorizationError } from '../shared/errors/AppError';

export const authorize = (allowedRoles: UserRole[]) => {
    return (req: Request, _res: Response, next: NextFunction): void => {
        if (!req.user) {
            next(new AuthenticationError('Authentication required before role verification.'));
            return;
        }

        if (!allowedRoles.includes(req.user.role)) {
            next(
                new AuthorizationError(
                    `Access denied. Required role: ${allowedRoles.join(' or ')}.`
                )
            );
            return;
        }

        next();
    };
};