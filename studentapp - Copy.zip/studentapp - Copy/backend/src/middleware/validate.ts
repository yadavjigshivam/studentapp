import { Request, Response, NextFunction } from 'express';
import { AnyZodObject, ZodError, ZodTypeAny } from 'zod';
import { ValidationError } from '../shared/errors/AppError';

interface ValidationSchemas {
    body?: AnyZodObject | ZodTypeAny;
    query?: AnyZodObject | ZodTypeAny;
    params?: AnyZodObject | ZodTypeAny;
}

export const validate = (schemas: ValidationSchemas) => {
    return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
        try {
            if (schemas.body) {
                req.body = await schemas.body.parseAsync(req.body);
            }
            if (schemas.query) {
                const parsedQuery = await schemas.query.parseAsync(req.query);
                Object.assign(req.query, parsedQuery);
            }
            if (schemas.params) {
                const parsedParams = await schemas.params.parseAsync(req.params);
                Object.assign(req.params, parsedParams);
            }
            next();
        } catch (error) {
            if (error instanceof ZodError) {
                const details = error.errors.map((err) => ({
                    field: err.path.join('.'),
                    issue: err.message,
                }));
                next(new ValidationError('The provided payload contains invalid or missing fields.', details));
                return;
            }
            next(error);
        }
    };
};