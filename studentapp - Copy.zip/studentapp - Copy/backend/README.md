# 📦 Backend — Multi-Exam Study Platform

> **Status:** Documentation Phase — No code yet.

## Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Runtime | Node.js | 20 LTS |
| Framework | Express.js | 4.x |
| Language | TypeScript | 5.x |
| ORM | Prisma | 5.x |
| Database | PostgreSQL | 15+ |
| Auth | JWT (jsonwebtoken + bcrypt) | — |
| Validation | Zod | 3.x |
| File Uploads | Multer + Supabase Storage | — |
| Logging | Winston | 3.x |
| Rate Limiting | express-rate-limit | — |
| Testing | Jest + Supertest | — |

## Project Structure (Planned)

```
backend/
├── src/
│   ├── config/                    # Database, auth, storage, environment config
│   │   ├── database.ts
│   │   ├── auth.ts
│   │   ├── storage.ts
│   │   └── env.ts
│   │
│   ├── middleware/                 # Express middleware
│   │   ├── authenticate.ts        # JWT verification
│   │   ├── authorize.ts           # Role-based access control
│   │   ├── validate.ts            # Zod schema validation
│   │   ├── rateLimiter.ts         # Rate limiting per route
│   │   ├── errorHandler.ts        # Centralized error handling
│   │   └── auditLog.ts            # Admin action logging
│   │
│   ├── modules/                   # Feature modules (controller + service + routes + validators)
│   │   ├── auth/
│   │   │   ├── auth.controller.ts
│   │   │   ├── auth.service.ts
│   │   │   ├── auth.routes.ts
│   │   │   ├── auth.validators.ts
│   │   │   └── auth.types.ts
│   │   ├── users/
│   │   ├── examinations/
│   │   ├── subjects/
│   │   ├── chapters/
│   │   ├── topics/
│   │   ├── syllabus/
│   │   ├── notes/
│   │   ├── questions/
│   │   ├── quizzes/
│   │   ├── practice/
│   │   ├── study-sessions/
│   │   ├── daily-targets/
│   │   ├── progress/
│   │   ├── bookmarks/
│   │   ├── focus-mode/
│   │   ├── devices/
│   │   ├── app-config/
│   │   └── admin/
│   │
│   ├── shared/                    # Shared utilities
│   │   ├── types/                 # Global TypeScript types
│   │   ├── utils/                 # Helper functions
│   │   ├── errors/                # Custom error classes
│   │   └── constants/             # App-wide constants
│   │
│   ├── prisma/
│   │   ├── schema.prisma          # Database schema
│   │   ├── migrations/            # Prisma migrations
│   │   └── seed.ts                # Database seeding
│   │
│   ├── app.ts                     # Express app setup
│   └── server.ts                  # Server entry point
│
├── tests/
│   ├── unit/
│   ├── integration/
│   └── helpers/
│
├── .env.example                   # Environment variable template
├── tsconfig.json
├── jest.config.ts
├── package.json
└── README.md
```

## Setup Instructions (To Be Executed After Plan Approval)

### Prerequisites

- Node.js 20 LTS
- PostgreSQL 15+ (or Supabase/Neon free tier)
- npm or pnpm

### Installation Steps

```bash
# 1. Navigate to backend directory
cd backend

# 2. Install dependencies
pnpm install

# 3. Copy environment variables
cp .env.example .env

# 4. Update .env with your database URL and secrets
#    DATABASE_URL="postgresql://user:password@host:5432/studentapp"
#    JWT_SECRET="your-secret-key"
#    JWT_REFRESH_SECRET="your-refresh-secret"

# 5. Generate Prisma client
pnpm prisma generate

# 6. Run database migrations
pnpm prisma migrate dev

# 7. Seed the database
pnpm prisma db seed

# 8. Start development server
pnpm dev
```

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | ✅ |
| `JWT_SECRET` | Access token signing secret | ✅ |
| `JWT_REFRESH_SECRET` | Refresh token signing secret | ✅ |
| `JWT_ACCESS_EXPIRY` | Access token expiry (default: `15m`) | ❌ |
| `JWT_REFRESH_EXPIRY` | Refresh token expiry (default: `7d`) | ❌ |
| `PORT` | Server port (default: `3000`) | ❌ |
| `NODE_ENV` | `development` / `production` | ❌ |
| `SUPABASE_URL` | Supabase project URL (for file storage) | ❌ |
| `SUPABASE_KEY` | Supabase anon key | ❌ |
| `CORS_ORIGIN` | Allowed CORS origins | ❌ |

### Available Scripts

| Script | Description |
|--------|-------------|
| `pnpm dev` | Start development server with hot reload |
| `pnpm build` | Compile TypeScript to JavaScript |
| `pnpm start` | Start production server |
| `pnpm test` | Run test suite |
| `pnpm test:watch` | Run tests in watch mode |
| `pnpm lint` | Run ESLint |
| `pnpm prisma:studio` | Open Prisma Studio (DB GUI) |
| `pnpm prisma:migrate` | Run pending migrations |
| `pnpm prisma:seed` | Seed the database |

### Module Pattern

Each feature module follows a consistent pattern:

```
module-name/
├── module.controller.ts    # HTTP request/response handling
├── module.service.ts       # Business logic
├── module.routes.ts        # Route definitions
├── module.validators.ts    # Zod validation schemas
└── module.types.ts         # Module-specific TypeScript types
```

### API Base URL

```
Development:  http://localhost:3000/api/v1
Production:   https://your-domain.com/api/v1
```

## Documentation

- [Product Requirements](../docs/01-product-requirements.md)
- [Database Schema & ERD](../docs/02-database-schema-ERD.md)
- [API Specifications](../docs/03-api-specifications.md)
- [Tech Stack & Architecture](../docs/04-tech-stack-architecture.md)
- [Testing & Security](../docs/06-testing-and-security.md)

