# 🖥️ Admin Panel — Multi-Exam Study Platform

> **Status:** Documentation Phase — No code yet.

## Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Framework | React | 18.x |
| Language | TypeScript | 5.x |
| Routing | React Router | 6.x |
| Styling | Tailwind CSS | 3.x |
| HTTP Client | Axios | 1.x |
| Forms | React Hook Form + Zod | — |
| Data Tables | TanStack Table (React Table v8) | 8.x |
| Charts | Recharts | 2.x |
| File Upload | React Dropzone | — |
| Build Tool | Vite | 5.x |
| Testing | Jest + React Testing Library + Cypress | — |

## Project Structure (Planned)

```
admin-panel/
├── src/
│   ├── components/                # Shared UI components
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx        # Navigation sidebar
│   │   │   ├── Header.tsx         # Top header with user info
│   │   │   ├── Layout.tsx         # Main layout wrapper
│   │   │   └── Breadcrumb.tsx
│   │   ├── ui/
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Select.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── DataTable.tsx      # Reusable table with pagination
│   │   │   ├── FileUpload.tsx
│   │   │   ├── StatusBadge.tsx
│   │   │   ├── ConfirmDialog.tsx
│   │   │   ├── Toast.tsx
│   │   │   └── LoadingSpinner.tsx
│   │   └── charts/
│   │       ├── StatsCard.tsx
│   │       ├── BarChart.tsx
│   │       └── LineChart.tsx
│   │
│   ├── pages/                     # Route pages
│   │   ├── auth/
│   │   │   └── Login.tsx
│   │   ├── dashboard/
│   │   │   └── Dashboard.tsx      # Admin overview stats
│   │   ├── examinations/
│   │   │   ├── ExaminationList.tsx
│   │   │   ├── ExaminationForm.tsx
│   │   │   └── ExaminationDetail.tsx
│   │   ├── subjects/
│   │   │   ├── SubjectList.tsx
│   │   │   └── SubjectForm.tsx
│   │   ├── chapters/
│   │   │   ├── ChapterList.tsx
│   │   │   └── ChapterForm.tsx
│   │   ├── topics/
│   │   │   ├── TopicList.tsx
│   │   │   └── TopicForm.tsx
│   │   ├── syllabus/
│   │   │   ├── SyllabusList.tsx
│   │   │   └── SyllabusForm.tsx
│   │   ├── notes/
│   │   │   ├── NoteList.tsx
│   │   │   └── NoteForm.tsx
│   │   ├── questions/
│   │   │   ├── QuestionList.tsx
│   │   │   ├── QuestionForm.tsx
│   │   │   ├── QuestionDetail.tsx
│   │   │   └── BulkImport.tsx     # CSV/Excel upload & validation
│   │   ├── quizzes/
│   │   │   ├── QuizList.tsx
│   │   │   ├── QuizForm.tsx
│   │   │   └── QuizQuestionSelector.tsx
│   │   ├── students/
│   │   │   ├── StudentList.tsx
│   │   │   └── StudentDetail.tsx
│   │   ├── admin-users/
│   │   │   ├── AdminUserList.tsx
│   │   │   └── AdminUserForm.tsx
│   │   ├── audit-logs/
│   │   │   └── AuditLogList.tsx
│   │   └── settings/
│   │       └── AppConfig.tsx      # Force update, maintenance mode
│   │
│   ├── services/                  # API service layer
│   │   ├── api.ts                 # Axios instance
│   │   ├── auth.service.ts
│   │   ├── examination.service.ts
│   │   ├── subject.service.ts
│   │   ├── chapter.service.ts
│   │   ├── topic.service.ts
│   │   ├── question.service.ts
│   │   ├── quiz.service.ts
│   │   ├── student.service.ts
│   │   ├── auditLog.service.ts
│   │   └── appConfig.service.ts
│   │
│   ├── hooks/                     # Custom hooks
│   │   ├── useAuth.ts
│   │   ├── usePagination.ts
│   │   ├── useDebounce.ts
│   │   └── useConfirm.ts
│   │
│   ├── store/                     # State management
│   │   ├── authStore.ts
│   │   └── uiStore.ts
│   │
│   ├── types/                     # TypeScript types
│   │   ├── examination.types.ts
│   │   ├── question.types.ts
│   │   ├── student.types.ts
│   │   └── common.types.ts
│   │
│   ├── utils/
│   │   ├── formatters.ts
│   │   ├── validators.ts
│   │   └── constants.ts
│   │
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css                  # Tailwind imports
│
├── public/
├── .env.example
├── tailwind.config.js
├── vite.config.ts
├── tsconfig.json
├── package.json
└── README.md
```

## Setup Instructions (To Be Executed After Plan Approval)

### Prerequisites

- Node.js 20 LTS
- pnpm

### Installation Steps

```bash
# 1. Navigate to admin-panel directory
cd admin-panel

# 2. Install dependencies
pnpm install

# 3. Create environment configuration
cp .env.example .env

# 4. Update .env with backend API URL
#    VITE_API_URL="http://localhost:3000/api/v1"

# 5. Start development server
pnpm dev
```

### Available Scripts

| Script | Description |
|--------|-------------|
| `pnpm dev` | Start Vite development server |
| `pnpm build` | Production build |
| `pnpm preview` | Preview production build |
| `pnpm test` | Run test suite |
| `pnpm test:e2e` | Run Cypress E2E tests |
| `pnpm lint` | Run ESLint |

### Admin Sidebar Navigation

```
📊 Dashboard
📝 Examinations
   ├── All Examinations
   └── Add Examination
📚 Content
   ├── Subjects
   ├── Chapters
   ├── Topics
   └── Study Notes
❓ Question Bank
   ├── All Questions
   ├── Add Question
   └── Bulk Import
📋 Quizzes
   ├── All Quizzes
   └── Create Quiz
👥 Students
   └── All Students
👤 Admin Users
   └── Manage Admins
📜 Audit Logs
⚙️ Settings
   ├── App Configuration
   └── Force Update
```

### Role-Based Access Control (RBAC)

| Page | Super Admin | Content Admin | Question Manager | Student Support |
|------|:-----------:|:-------------:|:----------------:|:--------------:|
| Dashboard | ✅ | ✅ | ✅ | ✅ |
| Examinations | ✅ (full) | ✅ (full) | 👁️ (view) | ❌ |
| Subjects | ✅ (full) | ✅ (full) | 👁️ (view) | ❌ |
| Chapters/Topics | ✅ (full) | ✅ (full) | 👁️ (view) | ❌ |
| Study Notes | ✅ (full) | ✅ (full) | ❌ | ❌ |
| Questions | ✅ (full) | ✅ (full) | ✅ (full) | ❌ |
| Quizzes | ✅ (full) | ✅ (full) | ✅ (full) | ❌ |
| Students | ✅ (full) | ❌ | ❌ | ✅ (view + status) |
| Admin Users | ✅ (full) | ❌ | ❌ | ❌ |
| Audit Logs | ✅ (full) | ❌ | ❌ | ❌ |
| App Config | ✅ (full) | ❌ | ❌ | ❌ |

### Bulk Question Import

The admin panel supports bulk question import via CSV/Excel files.

**Required CSV Template Columns:**

| Column | Required | Description |
|--------|----------|-------------|
| `question_text_en` | ✅ | Question text (English) |
| `question_text_hi` | ❌ | Question text (Hindi) |
| `question_image_url` | ❌ | URL to question image |
| `option_a_en` | ✅ | Option A text (English) |
| `option_a_hi` | ❌ | Option A text (Hindi) |
| `option_a_image_url` | ❌ | URL to Option A image |
| `option_b_en` | ✅ | Option B text (English) |
| `option_b_hi` | ❌ | Option B (Hindi) |
| `option_b_image_url` | ❌ | URL to Option B image |
| `option_c_en` | ✅ | Option C text (English) |
| `option_c_hi` | ❌ | Option C (Hindi) |
| `option_c_image_url` | ❌ | URL to Option C image |
| `option_d_en` | ✅ | Option D text (English) |
| `option_d_hi` | ❌ | Option D (Hindi) |
| `option_d_image_url` | ❌ | URL to Option D image |
| `correct_option` | ✅ | `A`, `B`, `C`, or `D` |
| `explanation_en` | ❌ | Explanation (English) |
| `explanation_hi` | ❌ | Explanation (Hindi) |
| `difficulty` | ✅ | `easy`, `medium`, or `hard` |
| `subject_name` | ✅ | Must match existing subject |
| `chapter_name` | ❌ | Must match existing chapter |
| `topic_name` | ❌ | Must match existing topic |
| `source` | ❌ | e.g., "Previous Year 2023" |

**Import Workflow:**
1. Upload CSV/Excel file
2. System validates all rows (format, required fields, reference matching)
3. Display validation results with row-level errors
4. Admin reviews and confirms
5. Valid questions are imported as unpublished (draft)
6. Admin can then review and publish in bulk

## Documentation

- [Product Requirements](../docs/01-product-requirements.md)
- [Database Schema & ERD](../docs/02-database-schema-ERD.md)
- [API Specifications](../docs/03-api-specifications.md)
- [Tech Stack & Architecture](../docs/04-tech-stack-architecture.md)

