import { create } from 'zustand';
import { api } from '../services/api';

export interface AdminUser {
    id: string;
    email: string;
    firstName: string;
    lastName?: string | null;
    displayName?: string | null;
    role: 'student' | 'super_admin' | 'content_admin' | 'question_manager' | 'student_support';
}

interface AuthState {
    user: AdminUser | null;
    isAuthenticated: boolean;
    login: (email: string, password: string) => Promise<void>;
    logout: () => Promise<void>;
}

const savedUser = localStorage.getItem('admin_user');
const savedToken = localStorage.getItem('admin_access_token');

export const useAuthStore = create<AuthState>((set) => ({
    user: savedUser ? (JSON.parse(savedUser) as AdminUser) : null,
    isAuthenticated: Boolean(savedToken && savedUser),

    login: async (email: string, password: string) => {
        const res = await api.post('/auth/login', {
            email,
            password,
            deviceInfo: 'Admin Web Panel',
        });

        const { user, tokens } = res.data.data;

        if (user.role === 'student') {
            throw new Error('Access denied. Student accounts cannot log in to the Admin Panel.');
        }

        localStorage.setItem('admin_access_token', tokens.accessToken);
        localStorage.setItem('admin_refresh_token', tokens.refreshToken);
        localStorage.setItem('admin_user', JSON.stringify(user));

        set({ user, isAuthenticated: true });
    },

    logout: async () => {
        const refreshToken = localStorage.getItem('admin_refresh_token');
        try {
            if (refreshToken) {
                await api.post('/auth/logout', { refreshToken });
            }
        } catch {
            // Ignore network errors during logout
        } finally {
            localStorage.removeItem('admin_access_token');
            localStorage.removeItem('admin_refresh_token');
            localStorage.removeItem('admin_user');
            set({ user: null, isAuthenticated: false });
        }
    },
}));