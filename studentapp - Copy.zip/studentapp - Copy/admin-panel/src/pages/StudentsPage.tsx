import React, { useEffect, useState } from 'react';
import { Search, UserCheck, UserX } from 'lucide-react';
import { api } from '../services/api';

interface StudentRecord {
    id: string;
    email: string;
    firstName: string;
    lastName: string | null;
    displayName: string | null;
    phone: string | null;
    isActive: boolean;
    lastLoginAt: string | null;
    createdAt: string;
    userExaminations: Array<{
        isPrimary: boolean;
        examination: { id: string; name: string };
    }>;
}

export const StudentsPage: React.FC = () => {
    const [students, setStudents] = useState<StudentRecord[]>([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);

    const loadStudents = async (query = '') => {
        setLoading(true);
        try {
            const params = new URLSearchParams({ page: '1', limit: '50' });
            if (query.trim()) params.set('search', query.trim());
            const res = await api.get(`/admin/students?${params.toString()}`);
            setStudents(res.data.data);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadStudents();
    }, []);

    const handleToggleStatus = async (student: StudentRecord) => {
        const nextStatus = !student.isActive;
        await api.patch(`/admin/students/${student.id}/status`, {
            isActive: nextStatus,
            reason: nextStatus ? 'Reactivated by admin' : 'Suspended by admin',
        });
        await loadStudents(search);
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Student Management</h1>
                    <p className="text-sm text-slate-500">Search registered students and manage account status</p>
                </div>

                <form
                    onSubmit={(e) => {
                        e.preventDefault();
                        loadStudents(search);
                    }}
                    className="flex gap-2"
                >
                    <div className="relative">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                        <input
                            type="text"
                            placeholder="Search name, email or phone..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-sm w-64"
                        />
                    </div>
                    <button
                        type="submit"
                        className="px-4 py-2 bg-slate-900 text-white text-sm font-medium rounded-lg"
                    >
                        Search
                    </button>
                </form>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-x-auto">
                {loading ? (
                    <div className="p-8 text-center text-sm text-slate-500">Loading students...</div>
                ) : students.length === 0 ? (
                    <div className="p-8 text-center text-sm text-slate-500">No students found.</div>
                ) : (
                    <table className="w-full text-left border-collapse text-sm">
                        <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500">
                                <th className="px-5 py-3">Student</th>
                                <th className="px-5 py-3">Selected Exams</th>
                                <th className="px-5 py-3">Last Login</th>
                                <th className="px-5 py-3">Status</th>
                                <th className="px-5 py-3 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {students.map((st) => (
                                <tr key={st.id} className="hover:bg-slate-50">
                                    <td className="px-5 py-3.5">
                                        <p className="font-semibold text-slate-900">
                                            {st.displayName || `${st.firstName} ${st.lastName || ''}`}
                                        </p>
                                        <p className="text-xs text-slate-500">{st.email}</p>
                                        {st.phone && <p className="text-xs text-slate-400">{st.phone}</p>}
                                    </td>
                                    <td className="px-5 py-3.5">
                                        <div className="flex flex-wrap gap-1">
                                            {st.userExaminations.length === 0 ? (
                                                <span className="text-xs text-slate-400">None selected</span>
                                            ) : (
                                                st.userExaminations.map((ue) => (
                                                    <span
                                                        key={ue.examination.id}
                                                        className={`px-2 py-0.5 rounded text-xs ${ue.isPrimary
                                                                ? 'bg-blue-100 text-blue-700 font-medium'
                                                                : 'bg-slate-100 text-slate-600'
                                                            }`}
                                                    >
                                                        {ue.examination.name}
                                                    </span>
                                                ))
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-5 py-3.5 text-xs text-slate-500">
                                        {st.lastLoginAt ? new Date(st.lastLoginAt).toLocaleString() : 'Never'}
                                    </td>
                                    <td className="px-5 py-3.5">
                                        <span
                                            className={`px-2.5 py-1 rounded-full text-xs font-medium ${st.isActive
                                                    ? 'bg-emerald-50 text-emerald-700'
                                                    : 'bg-red-50 text-red-700'
                                                }`}
                                        >
                                            {st.isActive ? 'Active' : 'Suspended'}
                                        </span>
                                    </td>
                                    <td className="px-5 py-3.5 text-right">
                                        <button
                                            type="button"
                                            onClick={() => handleToggleStatus(st)}
                                            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${st.isActive
                                                    ? 'bg-red-50 text-red-700 hover:bg-red-100'
                                                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                                }`}
                                        >
                                            {st.isActive ? (
                                                <>
                                                    <UserX className="w-3.5 h-3.5" /> Deactivate
                                                </>
                                            ) : (
                                                <>
                                                    <UserCheck className="w-3.5 h-3.5" /> Activate
                                                </>
                                            )}
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};