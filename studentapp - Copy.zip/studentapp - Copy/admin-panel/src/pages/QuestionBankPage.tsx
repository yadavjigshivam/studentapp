import React, { useEffect, useState } from 'react';
import {
    Plus,
    Upload,
    Download,
    Copy,
    Trash2,
    CheckCircle,
    Clock,
    Image as ImageIcon,
} from 'lucide-react';
import { AxiosError } from 'axios';
import { api } from '../services/api';

interface Exam {
    id: string;
    name: string;
}

interface Subject {
    id: string;
    name: string;
}

interface Chapter {
    id: string;
    name: string;
}

interface Topic {
    id: string;
    name: string;
}

interface QuestionOptionItem {
    id?: string;
    optionTextEn: string;
    optionTextHi: string;
    optionImageUrl: string;
    isCorrect: boolean;
    displayOrder: number;
}

interface QuestionRecord {
    id: string;
    questionTextEn: string;
    questionTextHi: string | null;
    questionImageUrl: string | null;
    difficultyLevel: 'easy' | 'medium' | 'hard';
    isPublished: boolean;
    source: string | null;
    subject?: { id: string; name: string };
    topic?: { id: string; name: string } | null;
    options: QuestionOptionItem[];
}

interface ImportReport {
    jobId: string;
    status: string;
    fileName: string;
    totalRows: number;
    successfulRows: number;
    failedRows: number;
    errorLog: Array<{ row: number; field: string; message: string }>;
}

const emptyOptions = (): QuestionOptionItem[] => [
    { optionTextEn: '', optionTextHi: '', optionImageUrl: '', isCorrect: true, displayOrder: 1 },
    { optionTextEn: '', optionTextHi: '', optionImageUrl: '', isCorrect: false, displayOrder: 2 },
    { optionTextEn: '', optionTextHi: '', optionImageUrl: '', isCorrect: false, displayOrder: 3 },
    { optionTextEn: '', optionTextHi: '', optionImageUrl: '', isCorrect: false, displayOrder: 4 },
];

export const QuestionBankPage: React.FC = () => {
    const [exams, setExams] = useState<Exam[]>([]);
    const [subjects, setSubjects] = useState<Subject[]>([]);
    const [chapters, setChapters] = useState<Chapter[]>([]);
    const [topics, setTopics] = useState<Topic[]>([]);
    const [questions, setQuestions] = useState<QuestionRecord[]>([]);
    const [activeTab, setActiveTab] = useState<'list' | 'create' | 'import'>('list');

    // Filter / Selection state
    const [examId, setExamId] = useState('');
    const [subjectId, setSubjectId] = useState('');
    const [chapterId, setChapterId] = useState('');
    const [topicId, setTopicId] = useState('');

    // Create Question Form
    const [questionTextEn, setQuestionTextEn] = useState('');
    const [questionTextHi, setQuestionTextHi] = useState('');
    const [questionImageUrl, setQuestionImageUrl] = useState('');
    const [difficultyLevel, setDifficultyLevel] = useState<'easy' | 'medium' | 'hard'>('medium');
    const [explanationEn, setExplanationEn] = useState('');
    const [explanationHi, setExplanationHi] = useState('');
    const [source, setSource] = useState('');
    const [isPublished, setIsPublished] = useState(true);
    const [options, setOptions] = useState<QuestionOptionItem[]>(emptyOptions());

    // Bulk Import State
    const [importFile, setImportFile] = useState<File | null>(null);
    const [importReport, setImportReport] = useState<ImportReport | null>(null);

    const [notice, setNotice] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);

    const flashNotice = (msg: string) => {
        setError(null);
        setNotice(msg);
        setTimeout(() => setNotice(null), 4000);
    };

    const loadExams = async () => {
        const res = await api.get('/admin/examinations');
        const list: Exam[] = res.data.data;
        setExams(list);
        if (!examId && list.length > 0) setExamId(list[0].id);
    };

    const loadQuestions = async (filterExamId?: string) => {
        const params = new URLSearchParams({ page: '1', limit: '50' });
        if (filterExamId) params.set('examinationId', filterExamId);
        const res = await api.get(`/admin/questions?${params.toString()}`);
        setQuestions(res.data.data);
    };

    useEffect(() => {
        loadExams();
    }, []);

    useEffect(() => {
        if (!examId) {
            setSubjects([]);
            return;
        }
        api.get(`/admin/subjects?examinationId=${examId}`).then((res) => {
            const list: Subject[] = res.data.data;
            setSubjects(list);
            setSubjectId(list[0]?.id || '');
        });
        loadQuestions(examId);
    }, [examId]);

    useEffect(() => {
        if (!subjectId) {
            setChapters([]);
            setChapterId('');
            return;
        }
        api.get(`/admin/chapters?subjectId=${subjectId}`).then((res) => {
            const list: Chapter[] = res.data.data;
            setChapters(list);
            setChapterId(list[0]?.id || '');
        });
    }, [subjectId]);

    useEffect(() => {
        if (!chapterId) {
            setTopics([]);
            setTopicId('');
            return;
        }
        api.get(`/admin/topics?chapterId=${chapterId}`).then((res) => {
            const list: Topic[] = res.data.data;
            setTopics(list);
            setTopicId(list[0]?.id || '');
        });
    }, [chapterId]);

    const handleImageUpload = async (file: File, onUrl: (url: string) => void) => {
        try {
            const fd = new FormData();
            fd.append('file', file);
            fd.append('folder', 'questions');
            const res = await api.post('/uploads', fd, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            onUrl(res.data.data.url);
            flashNotice('Image uploaded successfully.');
        } catch {
            setError('Image upload failed. Please check file type (JPG/PNG/WebP) and size (<10MB).');
        }
    };

    const handleCreateQuestion = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!subjectId) {
            setError('Please select a Subject first.');
            return;
        }
        setSubmitting(true);
        setError(null);
        try {
            await api.post('/admin/questions', {
                examinationId: examId || undefined,
                subjectId,
                chapterId: chapterId || undefined,
                topicId: topicId || undefined,
                questionTextEn,
                questionTextHi: questionTextHi || undefined,
                questionImageUrl: questionImageUrl || undefined,
                difficultyLevel,
                explanationEn: explanationEn || undefined,
                explanationHi: explanationHi || undefined,
                source: source || undefined,
                isPublished,
                options: options.map((o, idx) => ({
                    optionTextEn: o.optionTextEn,
                    optionTextHi: o.optionTextHi || undefined,
                    optionImageUrl: o.optionImageUrl || undefined,
                    isCorrect: o.isCorrect,
                    displayOrder: idx + 1,
                })),
            });

            setQuestionTextEn('');
            setQuestionTextHi('');
            setQuestionImageUrl('');
            setExplanationEn('');
            setExplanationHi('');
            setSource('');
            setOptions(emptyOptions());
            await loadQuestions(examId);
            setActiveTab('list');
            flashNotice('Question created successfully!');
        } catch (err) {
            if (err instanceof AxiosError) {
                setError(err.response?.data?.error?.message || 'Failed to create question.');
            } else {
                setError('Failed to create question.');
            }
        } finally {
            setSubmitting(false);
        }
    };

    const handleTogglePublish = async (q: QuestionRecord) => {
        await api.put(`/admin/questions/${q.id}`, { isPublished: !q.isPublished });
        await loadQuestions(examId);
    };

    const handleDuplicate = async (id: string) => {
        await api.post(`/admin/questions/${id}/duplicate`);
        await loadQuestions(examId);
        flashNotice('Question duplicated as draft.');
    };

    const handleDelete = async (id: string) => {
        if (!window.confirm('Delete this question permanently?')) return;
        await api.delete(`/admin/questions/${id}`);
        await loadQuestions(examId);
        flashNotice('Question deleted.');
    };

    const handleBulkImport = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!examId || !importFile) return;
        setSubmitting(true);
        setError(null);
        setImportReport(null);
        try {
            const fd = new FormData();
            fd.append('file', importFile);
            fd.append('examinationId', examId);
            const res = await api.post('/admin/questions/bulk-import', fd, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            setImportReport(res.data.data);
            setImportFile(null);
            await loadQuestions(examId);
            flashNotice('Bulk import completed! Review imported drafts below.');
        } catch (err) {
            if (err instanceof AxiosError) {
                setError(err.response?.data?.error?.message || 'Bulk import failed.');
            } else {
                setError('Bulk import failed.');
            }
        } finally {
            setSubmitting(false);
        }
    };

    const downloadCsvTemplate = () => {
        const headers = [
            'question_text_en',
            'question_text_hi',
            'question_image_url',
            'option_a_en',
            'option_a_hi',
            'option_a_image_url',
            'option_b_en',
            'option_b_hi',
            'option_b_image_url',
            'option_c_en',
            'option_c_hi',
            'option_c_image_url',
            'option_d_en',
            'option_d_hi',
            'option_d_image_url',
            'correct_option',
            'explanation_en',
            'explanation_hi',
            'difficulty',
            'subject_name',
            'chapter_name',
            'topic_name',
            'source',
        ];
        const sampleRow = [
            '"Which planet is known as the Red Planet?"',
            '"किस ग्रह को लाल ग्रह कहा जाता है?"',
            '""',
            '"Mars"',
            '"मंगल"',
            '""',
            '"Venus"',
            '"शुक्र"',
            '""',
            '"Jupiter"',
            '"बृहस्पति"',
            '""',
            '"Saturn"',
            '"शनि"',
            '""',
            '"A"',
            '"Mars appears red due to iron oxide on its surface."',
            '"मंगल की सतह पर आयरन ऑक्साइड के कारण यह लाल दिखता है।"',
            '"easy"',
            `"${subjects[0]?.name || 'Child Development & Pedagogy'}"`,
            `"${chapters[0]?.name || ''}"`,
            `"${topics[0]?.name || ''}"`,
            '"Sample Import"',
        ];
        const csvContent = `${headers.join(',')}\n${sampleRow.join(',')}`;
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'question-bank-template.csv';
        a.click();
        URL.revokeObjectURL(url);
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Question Bank</h1>
                    <p className="text-sm text-slate-500">
                        Create bilingual questions with images or bulk import via CSV / Excel
                    </p>
                </div>

                <div className="flex items-center gap-2">
                    <select
                        value={examId}
                        onChange={(e) => setExamId(e.target.value)}
                        className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium"
                    >
                        {exams.map((ex) => (
                            <option key={ex.id} value={ex.id}>
                                {ex.name}
                            </option>
                        ))}
                    </select>

                    <button
                        type="button"
                        onClick={() => setActiveTab('list')}
                        className={`px-3.5 py-2 rounded-lg text-sm font-medium ${activeTab === 'list' ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200'
                            }`}
                    >
                        All ({questions.length})
                    </button>
                    <button
                        type="button"
                        onClick={() => setActiveTab('create')}
                        className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-medium ${activeTab === 'create' ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200'
                            }`}
                    >
                        <Plus className="w-4 h-4" /> Add Question
                    </button>
                    <button
                        type="button"
                        onClick={() => setActiveTab('import')}
                        className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-medium ${activeTab === 'import' ? 'bg-emerald-600 text-white' : 'bg-white border border-slate-200'
                            }`}
                    >
                        <Upload className="w-4 h-4" /> Bulk Import
                    </button>
                </div>
            </div>

            {notice && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm font-medium">
                    {notice}
                </div>
            )}
            {error && (
                <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm font-medium">
                    {error}
                </div>
            )}

            {/* TAB 1: LIST */}
            {activeTab === 'list' && (
                <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                    {questions.length === 0 ? (
                        <div className="p-10 text-center text-sm text-slate-500">
                            No questions found for this examination yet. Click &ldquo;Add Question&rdquo; or &ldquo;Bulk Import&rdquo;.
                        </div>
                    ) : (
                        <div className="divide-y divide-slate-100">
                            {questions.map((q) => (
                                <div key={q.id} className="p-5 flex flex-col md:flex-row md:items-start justify-between gap-4">
                                    <div className="space-y-1.5 flex-1">
                                        <div className="flex flex-wrap items-center gap-2 text-xs">
                                            <span
                                                className={`px-2 py-0.5 rounded-full font-medium ${q.isPublished
                                                        ? 'bg-emerald-100 text-emerald-700'
                                                        : 'bg-amber-100 text-amber-700'
                                                    }`}
                                            >
                                                {q.isPublished ? 'Published' : 'Draft'}
                                            </span>
                                            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded uppercase">
                                                {q.difficultyLevel}
                                            </span>
                                            {q.subject && (
                                                <span className="text-slate-500 font-medium">{q.subject.name}</span>
                                            )}
                                            {q.topic && <span className="text-slate-400">/ {q.topic.name}</span>}
                                            {q.source && <span className="text-blue-600">• {q.source}</span>}
                                        </div>
                                        <p className="font-medium text-slate-900 text-sm">{q.questionTextEn}</p>
                                        {q.questionTextHi && (
                                            <p className="text-slate-600 text-sm">{q.questionTextHi}</p>
                                        )}
                                        {q.questionImageUrl && (
                                            <img
                                                src={q.questionImageUrl}
                                                alt="Question"
                                                className="mt-2 max-h-32 rounded border border-slate-200"
                                            />
                                        )}
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-2">
                                            {q.options.map((o, idx) => (
                                                <div
                                                    key={o.id || idx}
                                                    className={`text-xs px-2.5 py-1.5 rounded border ${o.isCorrect
                                                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold'
                                                            : 'bg-slate-50 border-slate-200 text-slate-600'
                                                        }`}
                                                >
                                                    {String.fromCharCode(65 + idx)}. {o.optionTextEn}
                                                    {o.optionTextHi ? ` (${o.optionTextHi})` : ''}
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-1.5 shrink-0">
                                        <button
                                            type="button"
                                            onClick={() => handleTogglePublish(q)}
                                            title={q.isPublished ? 'Unpublish' : 'Publish'}
                                            className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                                        >
                                            {q.isPublished ? (
                                                <Clock className="w-4 h-4 text-amber-600" />
                                            ) : (
                                                <CheckCircle className="w-4 h-4 text-emerald-600" />
                                            )}
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => handleDuplicate(q.id)}
                                            title="Duplicate"
                                            className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                                        >
                                            <Copy className="w-4 h-4" />
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => handleDelete(q.id)}
                                            title="Delete"
                                            className="p-2 rounded-lg border border-slate-200 hover:bg-red-50 text-red-600"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* TAB 2: CREATE SINGLE QUESTION */}
            {activeTab === 'create' && (
                <form onSubmit={handleCreateQuestion} className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1">Subject *</label>
                            <select
                                value={subjectId}
                                onChange={(e) => setSubjectId(e.target.value)}
                                required
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            >
                                <option value="">Select Subject</option>
                                {subjects.map((s) => (
                                    <option key={s.id} value={s.id}>
                                        {s.name}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1">Chapter</label>
                            <select
                                value={chapterId}
                                onChange={(e) => setChapterId(e.target.value)}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            >
                                <option value="">Optional Chapter</option>
                                {chapters.map((c) => (
                                    <option key={c.id} value={c.id}>
                                        {c.name}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1">Topic</label>
                            <select
                                value={topicId}
                                onChange={(e) => setTopicId(e.target.value)}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            >
                                <option value="">Optional Topic</option>
                                {topics.map((t) => (
                                    <option key={t.id} value={t.id}>
                                        {t.name}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1">Difficulty</label>
                            <select
                                value={difficultyLevel}
                                onChange={(e) => setDifficultyLevel(e.target.value as 'easy' | 'medium' | 'hard')}
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            >
                                <option value="easy">Easy</option>
                                <option value="medium">Medium</option>
                                <option value="hard">Hard</option>
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1">
                                Question Text (English) *
                            </label>
                            <textarea
                                rows={3}
                                required
                                value={questionTextEn}
                                onChange={(e) => setQuestionTextEn(e.target.value)}
                                placeholder="Enter question in English..."
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-semibold text-slate-600 mb-1">
                                Question Text (Hindi — हिन्दी)
                            </label>
                            <textarea
                                rows={3}
                                value={questionTextHi}
                                onChange={(e) => setQuestionTextHi(e.target.value)}
                                placeholder="हिन्दी में प्रश्न लिखें (वैकल्पिक)..."
                                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            />
                        </div>
                    </div>

                    {/* Question Image Upload */}
                    <div className="flex flex-wrap items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <ImageIcon className="w-4 h-4 text-slate-500" />
                        <span className="text-xs font-medium text-slate-700">Question Image (Optional):</span>
                        <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleImageUpload(file, setQuestionImageUrl);
                            }}
                            className="text-xs"
                        />
                        {questionImageUrl && (
                            <span className="text-xs text-emerald-700 truncate max-w-xs">{questionImageUrl}</span>
                        )}
                    </div>

                    {/* Options */}
                    <div className="space-y-3">
                        <label className="block text-xs font-semibold text-slate-600">
                            Options (Select the radio button for the single correct answer) *
                        </label>
                        {options.map((opt, idx) => (
                            <div key={idx} className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                                <div className="md:col-span-1 flex items-center gap-2">
                                    <input
                                        type="radio"
                                        name="correctOption"
                                        checked={opt.isCorrect}
                                        onChange={() =>
                                            setOptions(options.map((o, i) => ({ ...o, isCorrect: i === idx })))
                                        }
                                    />
                                    <span className="text-xs font-bold">{String.fromCharCode(65 + idx)}</span>
                                </div>
                                <input
                                    type="text"
                                    required
                                    placeholder={`Option ${String.fromCharCode(65 + idx)} (English)`}
                                    value={opt.optionTextEn}
                                    onChange={(e) =>
                                        setOptions(
                                            options.map((o, i) =>
                                                i === idx ? { ...o, optionTextEn: e.target.value } : o
                                            )
                                        )
                                    }
                                    className="md:col-span-5 px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                />
                                <input
                                    type="text"
                                    placeholder={`Option ${String.fromCharCode(65 + idx)} (Hindi)`}
                                    value={opt.optionTextHi}
                                    onChange={(e) =>
                                        setOptions(
                                            options.map((o, i) =>
                                                i === idx ? { ...o, optionTextHi: e.target.value } : o
                                            )
                                        )
                                    }
                                    className="md:col-span-6 px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                />
                            </div>
                        ))}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <textarea
                            rows={2}
                            placeholder="Explanation (English)"
                            value={explanationEn}
                            onChange={(e) => setExplanationEn(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                        <textarea
                            rows={2}
                            placeholder="व्याख्या (Hindi)"
                            value={explanationHi}
                            onChange={(e) => setExplanationHi(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100">
                        <div className="flex items-center gap-4">
                            <input
                                type="text"
                                placeholder="Source (e.g. CTET 2024)"
                                value={source}
                                onChange={(e) => setSource(e.target.value)}
                                className="px-3 py-2 border border-slate-300 rounded-lg text-sm w-56"
                            />
                            <label className="flex items-center gap-2 text-sm text-slate-700">
                                <input
                                    type="checkbox"
                                    checked={isPublished}
                                    onChange={(e) => setIsPublished(e.target.checked)}
                                />
                                Publish immediately
                            </label>
                        </div>
                        <button
                            type="submit"
                            disabled={submitting}
                            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold rounded-lg"
                        >
                            {submitting ? 'Saving...' : 'Save Question'}
                        </button>
                    </div>
                </form>
            )}

            {/* TAB 3: BULK CSV / EXCEL IMPORT */}
            {activeTab === 'import' && (
                <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                        <div>
                            <h2 className="font-semibold text-slate-900">Bulk Import Questions (CSV / Excel)</h2>
                            <p className="text-xs text-slate-500 mt-0.5">
                                Valid rows are imported as Drafts so you can verify and publish them.
                            </p>
                        </div>
                        <button
                            type="button"
                            onClick={downloadCsvTemplate}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg"
                        >
                            <Download className="w-4 h-4" /> Download Sample CSV Template
                        </button>
                    </div>

                    <form onSubmit={handleBulkImport} className="flex flex-wrap items-center gap-4 p-5 bg-slate-50 border border-dashed border-slate-300 rounded-xl">
                        <input
                            type="file"
                            accept=".csv,.xlsx,.xls"
                            onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                            className="text-sm"
                        />
                        <button
                            type="submit"
                            disabled={!importFile || submitting}
                            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white text-sm font-semibold rounded-lg"
                        >
                            {submitting ? 'Importing...' : 'Upload & Validate'}
                        </button>
                    </form>

                    {importReport && (
                        <div className="p-4 rounded-xl border border-slate-200 space-y-3">
                            <div className="flex flex-wrap gap-4 text-sm font-medium">
                                <span>File: {importReport.fileName}</span>
                                <span className="text-slate-600">Total: {importReport.totalRows}</span>
                                <span className="text-emerald-700">Imported: {importReport.successfulRows}</span>
                                <span className="text-red-600">Failed: {importReport.failedRows}</span>
                            </div>
                            {importReport.errorLog.length > 0 && (
                                <div className="bg-red-50 border border-red-200 rounded-lg p-3 space-y-1 max-h-56 overflow-y-auto">
                                    <p className="text-xs font-bold text-red-800">Row Validation Errors:</p>
                                    {importReport.errorLog.map((e, i) => (
                                        <p key={i} className="text-xs text-red-700">
                                            Row {e.row} ({e.field}): {e.message}
                                        </p>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};