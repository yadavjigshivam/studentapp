import React, { useEffect, useState } from 'react';
import { Save, Shield, History } from 'lucide-react';
import { api } from '../services/api';

interface AdminAccount {
    id: string;
    email: string;
    displayName: string | null;
    role: string;
    isActive: boolean;
}

interface AuditLogRecord {
    id: string;
    action: string;
    entityType: string;
    entityId: string | null;
    ipAddress: string | null;
    createdAt: string;
    adminUser: { email: string; name: string | null } | null;
}

export const SettingsPage: React.FC = () => {
    const [config, setConfig] = useState({
        min_app_version: '1.0.0',
        latest_app_version: '1.0.0',
        force_update: false,
        maintenance_mode: false,
        maintenance_message: '',
        support_email: 'support@studyplatform.in',
    });

    const [admins, setAdmins] = useState<AdminAccount[]>([]);
    const [logs, setLogs] = useState<AuditLogRecord[]>([]);
    const [newAdmin, setNewAdmin] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        role: 'content_admin',
    });
    const [notice, setNotice] = useState<string | null>(null);

    const loadAll = async () => {
        const [cfgRes, admRes, logRes] = await Promise.all([
            api.get('/app/config'),
            api.get('/admin/admin-users'),
            api.get('/admin/audit-logs?page=1&limit=25'),
        ]);
        const c = cfgRes.data.data;
        setConfig({
            min_app_version: c.minAppVersion || '1.0.0',
            latest_app_version: c.latestAppVersion || '1.0.0',
            force_update: Boolean(c.forceUpdate),
            maintenance_mode: Boolean(c.maintenanceMode),
            maintenance_message: c.maintenanceMessage || '',
            support_email: c.supportEmail || 'support@studyplatform.in',
        });
        setAdmins(admRes.data.data);
        setLogs(logRes.data.data);
    };

    useEffect(() => {
        loadAll();
    }, []);

    const handleSaveConfig = async (e: React.FormEvent) => {
        e.preventDefault();
        await api.put('/admin/app-config', config);
        setNotice('App configuration saved successfully!');
        setTimeout(() => setNotice(null), 4000);
        await loadAll();
    };

    const handleCreateAdmin = async (e: React.FormEvent) => {
        e.preventDefault();
        await api.post('/admin/admin-users', newAdmin);
        setNewAdmin({ firstName: '', lastName: '', email: '', password: '', role: 'content_admin' });
        setNotice('New admin user created!');
        setTimeout(() => setNotice(null), 4000);
        await loadAll();
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Settings, Admin Users &amp; Audit Logs</h1>
                <p className="text-sm text-slate-500">
                    Control mobile Force Update flags, create role-based admins, and inspect audit history
                </p>
            </div>

            {notice && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm font-medium">
                    {notice}
                </div>
            )}

            {/* 1. Remote App Configuration */}
            <form onSubmit={handleSaveConfig} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                <h2 className="font-semibold text-slate-900">Mobile App Remote Config &amp; Force Update</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Min App Version</label>
                        <input
                            type="text"
                            value={config.min_app_version}
                            onChange={(e) => setConfig({ ...config, min_app_version: e.target.value })}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Latest App Version</label>
                        <input
                            type="text"
                            value={config.latest_app_version}
                            onChange={(e) => setConfig({ ...config, latest_app_version: e.target.value })}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Support Email</label>
                        <input
                            type="email"
                            value={config.support_email}
                            onChange={(e) => setConfig({ ...config, support_email: e.target.value })}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                </div>

                <div className="flex flex-wrap gap-6">
                    <label className="flex items-center gap-2 text-sm font-medium text-slate-700">
                        <input
                            type="checkbox"
                            checked={config.force_update}
                            onChange={(e) => setConfig({ ...config, force_update: e.target.checked })}
                        />
                        Enable Force Update Popup
                    </label>
                    <label className="flex items-center gap-2 text-sm font-medium text-slate-700">
                        <input
                            type="checkbox"
                            checked={config.maintenance_mode}
                            onChange={(e) => setConfig({ ...config, maintenance_mode: e.target.checked })}
                        />
                        Enable Maintenance Mode
                    </label>
                </div>

                <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Maintenance Message</label>
                    <input
                        type="text"
                        value={config.maintenance_message}
                        onChange={(e) => setConfig({ ...config, maintenance_message: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    />
                </div>

                <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg"
                >
                    <Save className="w-4 h-4" /> Save App Config
                </button>
            </form>

            {/* 2. Admin Users */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                <h2 className="font-semibold text-slate-900 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-blue-600" /> Admin Team Members (RBAC)
                </h2>
                <form onSubmit={handleCreateAdmin} className="grid grid-cols-1 md:grid-cols-5 gap-3">
                    <input
                        type="text"
                        required
                        placeholder="First Name"
                        value={newAdmin.firstName}
                        onChange={(e) => setNewAdmin({ ...newAdmin, firstName: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    />
                    <input
                        type="email"
                        required
                        placeholder="Email"
                        value={newAdmin.email}
                        onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    />
                    <input
                        type="password"
                        required
                        placeholder="Password"
                        value={newAdmin.password}
                        onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    />
                    <select
                        value={newAdmin.role}
                        onChange={(e) => setNewAdmin({ ...newAdmin, role: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    >
                        <option value="content_admin">Content Admin</option>
                        <option value="question_manager">Question Manager</option>
                        <option value="student_support">Student Support</option>
                        <option value="super_admin">Super Admin</option>
                    </select>
                    <button
                        type="submit"
                        className="bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium px-4 py-2 rounded-lg"
                    >
                        Add Admin
                    </button>
                </form>

                <div className="divide-y divide-slate-100">
                    {admins.map((a) => (
                        <div key={a.id} className="py-2.5 flex items-center justify-between text-sm">
                            <div>
                                <span className="font-medium text-slate-900">{a.displayName || a.email}</span>
                                <span className="ml-2 text-xs text-slate-500">{a.email}</span>
                            </div>
                            <span className="px-2 py-0.5 text-xs uppercase bg-blue-50 text-blue-700 font-semibold rounded">
                                {a.role.replace('_', ' ')}
                            </span>
                        </div>
                    ))}
                </div>
            </div>

            {/* 3. Audit Logs */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-200 flex items-center gap-2">
                    <History className="w-5 h-5 text-blue-600" />
                    <h2 className="font-semibold text-slate-900">Recent Admin Audit Logs</h2>
                </div>
                <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                    {logs.length === 0 ? (
                        <p className="p-6 text-center text-sm text-slate-500">No audit logs recorded yet.</p>
                    ) : (
                        logs.map((l) => (
                            <div key={l.id} className="px-5 py-3 flex items-center justify-between text-xs">
                                <div>
                                    <span className="font-semibold text-slate-900">
                                        {l.adminUser?.name || l.adminUser?.email || 'System'}
                                    </span>{' '}
                                    performed{' '}
                                    <span className="px-1.5 py-0.5 bg-slate-100 rounded font-medium">{l.action}</span>{' '}
                                    on <span className="font-medium text-blue-700">{l.entityType}</span>
                                </div>
                                <span className="text-slate-400">{new Date(l.createdAt).toLocaleString()}</span>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};