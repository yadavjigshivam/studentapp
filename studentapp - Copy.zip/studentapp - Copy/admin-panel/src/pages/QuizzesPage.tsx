import React, { useEffect, useState } from 'react';
import { Plus, ClipboardList, Clock, CheckSquare } from 'lucide-react';
import { api } from '../services/api';

interface Exam {
    id: string;
    name: string;
}

interface Subject {
    id: string;
    name: string;
}

interface QuestionSummary {
    id: string;
    questionTextEn: string;
    difficultyLevel: string;
    isPublished: boolean;
    subject?: { id: string; name: string };
}

interface QuizRecord {
    id: string;
    title: string;
    description: string | null;
    quizType: string;
    totalQuestions: number;
    durationMinutes: number | null;
    marksPerQuestion: number;
    negativeMarksPerQuestion: number;
    examination?: { name: string };
    subject?: { name: string } | null;
}

type TestCategory = 'FULL_TEST' | 'SHORT_TEST' | 'MINI_TEST' | 'SECTIONAL_TEST';

const TEST_PRESETS: Array<{
    key: TestCategory;
    label: string;
    hours: number;
    minutes: number;
    marks: string;
    negMarks: string;
    badgeClass: string;
}> = [
        {
            key: 'FULL_TEST',
            label: 'Full Test (2 Hrs)',
            hours: 2,
            minutes: 0,
            marks: '1',
            negMarks: '0.25',
            badgeClass: 'bg-indigo-100 text-indigo-700',
        },
        {
            key: 'SHORT_TEST',
            label: 'Short Test (30 Min)',
            hours: 0,
            minutes: 30,
            marks: '1',
            negMarks: '0.25',
            badgeClass: 'bg-sky-100 text-sky-700',
        },
        {
            key: 'MINI_TEST',
            label: 'Mini Test (15 Min)',
            hours: 0,
            minutes: 15,
            marks: '1',
            negMarks: '0',
            badgeClass: 'bg-emerald-100 text-emerald-700',
        },
        {
            key: 'SECTIONAL_TEST',
            label: 'Sectional Test (45 Min)',
            hours: 0,
            minutes: 45,
            marks: '1',
            negMarks: '0.25',
            badgeClass: 'bg-purple-100 text-purple-700',
        },
    ];

function extractTestBadge(description: string | null, durationMinutes: number | null) {
    const raw = description || '';
    const match = raw.match(/^\[(FULL_TEST|SHORT_TEST|MINI_TEST|SECTIONAL_TEST)\]\s*/);
    const tag = match ? (match[1] as TestCategory) : null;
    const cleanDesc = match ? raw.replace(match[0], '') : raw;

    if (tag) {
        const preset = TEST_PRESETS.find((p) => p.key === tag);
        return {
            label: preset ? preset.label.split(' (')[0] : 'Mock Test',
            badgeClass: preset?.badgeClass || 'bg-slate-100 text-slate-700',
            cleanDesc,
        };
    }

    if ((durationMinutes || 0) >= 90) {
        return { label: 'Full Test', badgeClass: 'bg-indigo-100 text-indigo-700', cleanDesc };
    }
    if ((durationMinutes || 0) <= 20) {
        return { label: 'Mini Test', badgeClass: 'bg-emerald-100 text-emerald-700', cleanDesc };
    }
    return { label: 'Short Test', badgeClass: 'bg-sky-100 text-sky-700', cleanDesc };
}

function formatDurationLabel(totalMinutes: number | null): string {
    const mins = totalMinutes || 0;
    if (mins <= 0) return 'Untimed';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    if (h === 0) return `${m} min`;
    if (m === 0) return `${h} hr${h > 1 ? 's' : ''}`;
    return `${h}h ${m}m`;
}

export const QuizzesPage: React.FC = () => {
    const [exams, setExams] = useState<Exam[]>([]);
    const [subjects, setSubjects] = useState<Subject[]>([]);
    const [questions, setQuestions] = useState<QuestionSummary[]>([]);
    const [quizzes, setQuizzes] = useState<QuizRecord[]>([]);

    const [examId, setExamId] = useState('');
    const [subjectId, setSubjectId] = useState('');
    const [filterSubjectId, setFilterSubjectId] = useState('');
    const [testCategory, setTestCategory] = useState<TestCategory>('FULL_TEST');

    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [durationHours, setDurationHours] = useState('2');
    const [durationMins, setDurationMins] = useState('0');
    const [marksPerQuestion, setMarksPerQuestion] = useState('1');
    const [negativeMarks, setNegativeMarks] = useState('0.25');
    const [selectedQuestionIds, setSelectedQuestionIds] = useState<string[]>([]);
    const [notice, setNotice] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const loadQuizzes = async () => {
        const res = await api.get('/quizzes?page=1&limit=50');
        setQuizzes(res.data.data);
    };

    useEffect(() => {
        api.get('/admin/examinations').then((res) => {
            const list: Exam[] = res.data.data;
            setExams(list);
            if (list.length > 0) setExamId(list[0].id);
        });
        loadQuizzes();
    }, []);

    useEffect(() => {
        if (!examId) return;
        api.get(`/admin/subjects?examinationId=${examId}`).then((res) => {
            setSubjects(res.data.data);
            setSubjectId('');
            setFilterSubjectId('');
        });
        api.get(`/admin/questions?examinationId=${examId}&limit=100`).then((res) => {
            setQuestions(res.data.data);
            setSelectedQuestionIds([]);
        });
    }, [examId]);

    const applyPreset = (preset: (typeof TEST_PRESETS)[number]) => {
        setTestCategory(preset.key);
        setDurationHours(String(preset.hours));
        setDurationMins(String(preset.minutes));
        setMarksPerQuestion(preset.marks);
        setNegativeMarks(preset.negMarks);
    };

    const visibleQuestions = filterSubjectId
        ? questions.filter((q) => q.subject?.id === filterSubjectId)
        : questions;

    const toggleQuestion = (id: string) => {
        setSelectedQuestionIds((prev) =>
            prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
        );
    };

    const selectAllVisible = () => {
        const ids = visibleQuestions.map((q) => q.id);
        setSelectedQuestionIds((prev) => Array.from(new Set([...prev, ...ids])));
    };

    const clearSelection = () => setSelectedQuestionIds([]);

    const totalDurationMinutes =
        (Number(durationHours) || 0) * 60 + (Number(durationMins) || 0);

    const handleCreateQuiz = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        if (!examId || !title.trim() || selectedQuestionIds.length === 0) {
            setError('Exam, Test Title aur kam se kam 1 question select karein.');
            return;
        }
        if (totalDurationMinutes <= 0) {
            setError('Duration kam se kam 1 minute honi chahiye.');
            return;
        }

        const taggedDescription = `[${testCategory}] ${description.trim()}`.trim();

        await api.post('/admin/quizzes', {
            title: title.trim(),
            description: taggedDescription,
            examinationId: examId,
            subjectId: subjectId || undefined,
            quizType: subjectId ? 'subject_wise' : 'topic_wise',
            durationMinutes: totalDurationMinutes,
            marksPerQuestion: Number(marksPerQuestion) || 1,
            negativeMarksPerQuestion: Number(negativeMarks) || 0,
            isTimed: true,
            isPublished: true,
            questionIds: selectedQuestionIds,
        });

        setTitle('');
        setDescription('');
        setSelectedQuestionIds([]);
        await loadQuizzes();
        setNotice('Test Series successfully create aur publish ho gaya!');
        setTimeout(() => setNotice(null), 4000);
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Test Series &amp; Mock Test Builder</h1>
                <p className="text-sm text-slate-500">
                    Create Testbook-style Full Tests (2 hrs+), Short Tests, Mini Tests &amp; Sectional Tests
                </p>
            </div>

            {notice && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm font-medium">
                    {notice}
                </div>
            )}
            {error && (
                <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm font-medium">
                    {error}
                </div>
            )}

            {/* Create Test Form */}
            <form
                onSubmit={handleCreateQuiz}
                className="bg-white rounded-xl border border-slate-200 p-5 space-y-5"
            >
                <div className="flex flex-wrap items-center justify-between gap-2">
                    <h2 className="font-semibold text-slate-900 flex items-center gap-2">
                        <Plus className="w-4 h-4 text-blue-600" /> Create New Exam Test
                    </h2>
                    <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> Total Time: {formatDurationLabel(totalDurationMinutes)}
                    </span>
                </div>

                {/* Preset Type Selector */}
                <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-2">
                        1. Test Type Preset (Time &amp; Marking auto-fill hoga, aap neeche edit bhi kar sakte hain)
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                        {TEST_PRESETS.map((preset) => {
                            const active = testCategory === preset.key;
                            return (
                                <button
                                    key={preset.key}
                                    type="button"
                                    onClick={() => applyPreset(preset)}
                                    className={`px-3 py-2.5 rounded-lg border text-left text-sm font-semibold transition-colors ${active
                                            ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                                        }`}
                                >
                                    {preset.label}
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* Exam, Title, Subject */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Target Exam *</label>
                        <select
                            value={examId}
                            onChange={(e) => setExamId(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        >
                            {exams.map((ex) => (
                                <option key={ex.id} value={ex.id}>
                                    {ex.name}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Test Title *</label>
                        <input
                            type="text"
                            required
                            placeholder="e.g. UP Super TET Full Mock Test 01"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">
                            Subject (Full Test ke liye All Subjects rakhein)
                        </label>
                        <select
                            value={subjectId}
                            onChange={(e) => setSubjectId(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        >
                            <option value="">All Subjects (Full / Mixed Test)</option>
                            {subjects.map((s) => (
                                <option key={s.id} value={s.id}>
                                    {s.name}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Duration (Hours + Minutes) & Marking Scheme */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Hours (Ghante)</label>
                        <input
                            type="number"
                            min={0}
                            max={6}
                            value={durationHours}
                            onChange={(e) => setDurationHours(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Minutes</label>
                        <input
                            type="number"
                            min={0}
                            max={59}
                            value={durationMins}
                            onChange={(e) => setDurationMins(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Marks / Question</label>
                        <input
                            type="number"
                            step="0.25"
                            min="0.25"
                            value={marksPerQuestion}
                            onChange={(e) => setMarksPerQuestion(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Negative Marking</label>
                        <input
                            type="number"
                            step="0.25"
                            min="0"
                            value={negativeMarks}
                            onChange={(e) => setNegativeMarks(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Instructions</label>
                        <input
                            type="text"
                            placeholder="e.g. Latest pattern 2026"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        />
                    </div>
                </div>

                {/* Question Selection with Subject Filter & Select All */}
                <div className="space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="text-xs font-semibold text-slate-700">
                            Select Questions ({selectedQuestionIds.length} selected / {visibleQuestions.length} shown)
                        </p>
                        <div className="flex flex-wrap items-center gap-2">
                            <select
                                value={filterSubjectId}
                                onChange={(e) => setFilterSubjectId(e.target.value)}
                                className="px-2.5 py-1 border border-slate-300 rounded-lg text-xs"
                            >
                                <option value="">Filter: All Subjects</option>
                                {subjects.map((s) => (
                                    <option key={s.id} value={s.id}>
                                        {s.name}
                                    </option>
                                ))}
                            </select>
                            <button
                                type="button"
                                onClick={selectAllVisible}
                                className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-semibold hover:bg-blue-100"
                            >
                                <CheckSquare className="w-3.5 h-3.5" /> Select All Shown
                            </button>
                            {selectedQuestionIds.length > 0 && (
                                <button
                                    type="button"
                                    onClick={clearSelection}
                                    className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-semibold hover:bg-slate-200"
                                >
                                    Clear
                                </button>
                            )}
                        </div>
                    </div>

                    <div className="max-h-60 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">
                        {visibleQuestions.length === 0 ? (
                            <p className="p-4 text-xs text-slate-400">
                                No questions available for this exam/subject. Question Bank se pehle questions add karein.
                            </p>
                        ) : (
                            visibleQuestions.map((q) => (
                                <label
                                    key={q.id}
                                    className="flex items-start gap-2.5 p-2.5 hover:bg-slate-50 cursor-pointer text-sm"
                                >
                                    <input
                                        type="checkbox"
                                        checked={selectedQuestionIds.includes(q.id)}
                                        onChange={() => toggleQuestion(q.id)}
                                        className="mt-0.5"
                                    />
                                    <div className="flex-1 min-w-0">
                                        <span className="text-slate-800">{q.questionTextEn}</span>
                                        {q.subject && (
                                            <span className="ml-2 text-[11px] text-blue-600 font-medium">
                                                [{q.subject.name}]
                                            </span>
                                        )}
                                    </div>
                                    <span className="text-[11px] uppercase px-1.5 py-0.5 bg-slate-100 rounded text-slate-500">
                                        {q.difficultyLevel}
                                    </span>
                                </label>
                            ))
                        )}
                    </div>
                </div>

                <button
                    type="submit"
                    disabled={selectedQuestionIds.length === 0}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-sm font-semibold rounded-lg"
                >
                    Publish Test ({selectedQuestionIds.length} Qs • {formatDurationLabel(totalDurationMinutes)})
                </button>
            </form>

            {/* Published Tests */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-200 flex items-center gap-2">
                    <ClipboardList className="w-5 h-5 text-blue-600" />
                    <h2 className="font-semibold text-slate-900">Published Test Series ({quizzes.length})</h2>
                </div>
                {quizzes.length === 0 ? (
                    <div className="p-8 text-center text-sm text-slate-500">No tests created yet.</div>
                ) : (
                    <div className="divide-y divide-slate-100">
                        {quizzes.map((qz) => {
                            const badge = extractTestBadge(qz.description, qz.durationMinutes);
                            return (
                                <div key={qz.id} className="px-5 py-4 flex items-center justify-between gap-4 text-sm">
                                    <div>
                                        <div className="flex flex-wrap items-center gap-2">
                                            <span className={`px-2 py-0.5 rounded text-xs font-bold ${badge.badgeClass}`}>
                                                {badge.label}
                                            </span>
                                            <p className="font-semibold text-slate-900">{qz.title}</p>
                                        </div>
                                        <p className="text-xs text-slate-500 mt-1">
                                            {qz.examination?.name} {qz.subject ? `• ${qz.subject.name}` : '• All Subjects'} •{' '}
                                            {qz.totalQuestions} Qs • {formatDurationLabel(qz.durationMinutes)} • +
                                            {qz.marksPerQuestion} / -{qz.negativeMarksPerQuestion}
                                        </p>
                                    </div>
                                    <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 text-xs font-medium rounded-full shrink-0">
                                        Live
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};