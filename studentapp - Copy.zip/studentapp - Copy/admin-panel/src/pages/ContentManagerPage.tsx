import React, { useEffect, useState } from 'react';
import { Plus, Trash2, CheckCircle2, XCircle, Upload } from 'lucide-react';
import { api } from '../services/api';

interface Exam {
    id: string;
    name: string;
    slug: string;
    category: string | null;
    language: string;
    isActive: boolean;
    _count?: { subjects: number; questions: number; userExaminations: number };
}

interface Subject {
    id: string;
    examinationId: string;
    name: string;
    slug: string;
    isActive: boolean;
    _count?: { chapters: number; questions: number };
}

interface Chapter {
    id: string;
    subjectId: string;
    name: string;
    slug: string;
    _count?: { topics: number; questions: number };
}

interface Topic {
    id: string;
    chapterId: string;
    name: string;
    slug: string;
    estimatedStudyTimeMinutes: number | null;
    _count?: { studyNotes: number; questions: number };
}

interface StudyNote {
    id: string;
    topicId: string;
    title: string;
    summary: string | null;
    contentEn: string | null;
    contentHi: string | null;
    isPublished: boolean;
}

const slugify = (val: string) =>
    val
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '');

export const ContentManagerPage: React.FC = () => {
    const [exams, setExams] = useState<Exam[]>([]);
    const [subjects, setSubjects] = useState<Subject[]>([]);
    const [chapters, setChapters] = useState<Chapter[]>([]);
    const [topics, setTopics] = useState<Topic[]>([]);
    const [notes, setNotes] = useState<StudyNote[]>([]);

    const [selectedExamId, setSelectedExamId] = useState<string>('');
    const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');
    const [selectedChapterId, setSelectedChapterId] = useState<string>('');
    const [selectedTopicId, setSelectedTopicId] = useState<string>('');

    const [message, setMessage] = useState<string | null>(null);

    // Forms
    const [examForm, setExamForm] = useState({ name: '', category: 'Teaching', description: '' });
    const [subjectName, setSubjectName] = useState('');
    const [chapterName, setChapterName] = useState('');
    const [topicForm, setTopicForm] = useState({ name: '', estimatedStudyTimeMinutes: '30' });
    const [noteForm, setNoteForm] = useState({
        title: '',
        summary: '',
        contentEn: '',
        contentHi: '',
        isPublished: true,
    });
    const [syllabusVersion, setSyllabusVersion] = useState('2026.2');
    const [syllabusPdfFile, setSyllabusPdfFile] = useState<File | null>(null);

    const showNotice = (text: string) => {
        setMessage(text);
        setTimeout(() => setMessage(null), 4000);
    };

    const loadExams = async () => {
        const res = await api.get('/admin/examinations');
        const list: Exam[] = res.data.data;
        setExams(list);
        if (!selectedExamId && list.length > 0) {
            setSelectedExamId(list[0].id);
        }
    };

    const loadSubjects = async (examId: string) => {
        if (!examId) return setSubjects([]);
        const res = await api.get(`/admin/subjects?examinationId=${examId}`);
        const list: Subject[] = res.data.data;
        setSubjects(list);
        setSelectedSubjectId(list[0]?.id || '');
    };

    const loadChapters = async (subjectId: string) => {
        if (!subjectId) return setChapters([]);
        const res = await api.get(`/admin/chapters?subjectId=${subjectId}`);
        const list: Chapter[] = res.data.data;
        setChapters(list);
        setSelectedChapterId(list[0]?.id || '');
    };

    const loadTopics = async (chapterId: string) => {
        if (!chapterId) return setTopics([]);
        const res = await api.get(`/admin/topics?chapterId=${chapterId}`);
        const list: Topic[] = res.data.data;
        setTopics(list);
        setSelectedTopicId(list[0]?.id || '');
    };

    const loadNotes = async (topicId: string) => {
        if (!topicId) return setNotes([]);
        const res = await api.get(`/admin/notes?topicId=${topicId}`);
        setNotes(res.data.data);
    };

    useEffect(() => {
        loadExams();
    }, []);

    useEffect(() => {
        loadSubjects(selectedExamId);
    }, [selectedExamId]);

    useEffect(() => {
        loadChapters(selectedSubjectId);
    }, [selectedSubjectId]);

    useEffect(() => {
        loadTopics(selectedChapterId);
    }, [selectedChapterId]);

    useEffect(() => {
        loadNotes(selectedTopicId);
    }, [selectedTopicId]);

    const handleCreateExam = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!examForm.name.trim()) return;
        await api.post('/admin/examinations', {
            name: examForm.name,
            slug: slugify(examForm.name),
            category: examForm.category,
            description: examForm.description,
            isActive: true,
        });
        setExamForm({ name: '', category: 'Teaching', description: '' });
        await loadExams();
        showNotice('Examination created successfully.');
    };

    const handleToggleExam = async (exam: Exam) => {
        await api.put(`/admin/examinations/${exam.id}`, { isActive: !exam.isActive });
        await loadExams();
    };

    const handleUploadSyllabusPdf = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedExamId || !syllabusPdfFile) return;
        const fd = new FormData();
        fd.append('file', syllabusPdfFile);
        fd.append('folder', 'syllabus');
        const up = await api.post('/uploads', fd, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        await api.post('/admin/syllabus', {
            examinationId: selectedExamId,
            versionCode: syllabusVersion,
            title: `Official Syllabus ${syllabusVersion}`,
            fileUrl: up.data.data.url,
            isActive: true,
        });
        setSyllabusPdfFile(null);
        showNotice('Syllabus PDF uploaded and version published.');
    };

    const handleCreateSubject = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedExamId || !subjectName.trim()) return;
        await api.post('/admin/subjects', {
            examinationId: selectedExamId,
            name: subjectName,
            slug: slugify(subjectName),
        });
        setSubjectName('');
        await loadSubjects(selectedExamId);
        showNotice('Subject added.');
    };

    const handleCreateChapter = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedSubjectId || !chapterName.trim()) return;
        await api.post('/admin/chapters', {
            subjectId: selectedSubjectId,
            name: chapterName,
            slug: slugify(chapterName),
        });
        setChapterName('');
        await loadChapters(selectedSubjectId);
        showNotice('Chapter added.');
    };

    const handleCreateTopic = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedChapterId || !topicForm.name.trim()) return;
        await api.post('/admin/topics', {
            chapterId: selectedChapterId,
            name: topicForm.name,
            slug: slugify(topicForm.name),
            estimatedStudyTimeMinutes: Number(topicForm.estimatedStudyTimeMinutes) || 30,
        });
        setTopicForm({ name: '', estimatedStudyTimeMinutes: '30' });
        await loadTopics(selectedChapterId);
        showNotice('Topic added.');
    };

    const handleCreateNote = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedTopicId || !noteForm.title.trim()) return;
        await api.post('/admin/notes', {
            topicId: selectedTopicId,
            ...noteForm,
        });
        setNoteForm({ title: '', summary: '', contentEn: '', contentHi: '', isPublished: true });
        await loadNotes(selectedTopicId);
        showNotice('Study note saved.');
    };

    const handleDeleteNote = async (id: string) => {
        await api.delete(`/admin/notes/${id}`);
        await loadNotes(selectedTopicId);
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Examinations, Syllabus &amp; Study Notes</h1>
                <p className="text-sm text-slate-500">
                    Manage your dynamic Exam → Subject → Chapter → Topic → Study Notes hierarchy
                </p>
            </div>

            {message && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm font-medium">
                    {message}
                </div>
            )}

            {/* 1. Examinations */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                <h2 className="font-semibold text-slate-900">1. Examinations</h2>
                <form onSubmit={handleCreateExam} className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <input
                        type="text"
                        placeholder="Exam Name (e.g. SSC CGL)"
                        value={examForm.name}
                        onChange={(e) => setExamForm({ ...examForm, name: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                        required
                    />
                    <input
                        type="text"
                        placeholder="Category (e.g. SSC, Teaching)"
                        value={examForm.category}
                        onChange={(e) => setExamForm({ ...examForm, category: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    />
                    <input
                        type="text"
                        placeholder="Short description"
                        value={examForm.description}
                        onChange={(e) => setExamForm({ ...examForm, description: e.target.value })}
                        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                    />
                    <button
                        type="submit"
                        className="inline-flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg"
                    >
                        <Plus className="w-4 h-4" /> Add Exam
                    </button>
                </form>

                <div className="flex flex-wrap gap-2">
                    {exams.map((exam) => (
                        <div
                            key={exam.id}
                            onClick={() => setSelectedExamId(exam.id)}
                            className={`cursor-pointer px-3.5 py-2 rounded-lg border text-sm flex items-center gap-2 ${selectedExamId === exam.id
                                    ? 'bg-blue-50 border-blue-500 text-blue-800 font-semibold'
                                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                                }`}
                        >
                            <span>{exam.name}</span>
                            <span className="text-xs text-slate-400">({exam._count?.subjects ?? 0} subj)</span>
                            <button
                                type="button"
                                title={exam.isActive ? 'Deactivate' : 'Activate'}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    handleToggleExam(exam);
                                }}
                            >
                                {exam.isActive ? (
                                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                ) : (
                                    <XCircle className="w-4 h-4 text-slate-400" />
                                )}
                            </button>
                        </div>
                    ))}
                </div>

                {selectedExamId && (
                    <form onSubmit={handleUploadSyllabusPdf} className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3">
                        <span className="text-xs font-semibold text-slate-600 uppercase">Upload Syllabus PDF:</span>
                        <input
                            type="text"
                            value={syllabusVersion}
                            onChange={(e) => setSyllabusVersion(e.target.value)}
                            placeholder="Version e.g. 2026.2"
                            className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs w-32"
                        />
                        <input
                            type="file"
                            accept="application/pdf"
                            onChange={(e) => setSyllabusPdfFile(e.target.files?.[0] || null)}
                            className="text-xs"
                        />
                        <button
                            type="submit"
                            disabled={!syllabusPdfFile}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 disabled:opacity-40 text-white text-xs font-medium rounded-lg"
                        >
                            <Upload className="w-3.5 h-3.5" /> Publish PDF
                        </button>
                    </form>
                )}
            </div>

            {/* 2. Subjects -> Chapters -> Topics Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Subjects */}
                <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
                    <h3 className="font-semibold text-slate-900">2. Subjects</h3>
                    <form onSubmit={handleCreateSubject} className="flex gap-2">
                        <input
                            type="text"
                            placeholder="Add subject..."
                            value={subjectName}
                            onChange={(e) => setSubjectName(e.target.value)}
                            className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
                            disabled={!selectedExamId}
                        />
                        <button
                            type="submit"
                            disabled={!selectedExamId}
                            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium disabled:opacity-40"
                        >
                            Add
                        </button>
                    </form>
                    <div className="space-y-1.5 max-h-64 overflow-y-auto">
                        {subjects.map((s) => (
                            <div
                                key={s.id}
                                onClick={() => setSelectedSubjectId(s.id)}
                                className={`cursor-pointer px-3 py-2 rounded-lg text-sm flex justify-between items-center ${selectedSubjectId === s.id
                                        ? 'bg-blue-50 text-blue-800 font-medium border border-blue-200'
                                        : 'hover:bg-slate-50 border border-transparent'
                                    }`}
                            >
                                <span>{s.name}</span>
                                <span className="text-xs text-slate-400">{s._count?.chapters ?? 0} ch</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Chapters */}
                <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
                    <h3 className="font-semibold text-slate-900">3. Chapters</h3>
                    <form onSubmit={handleCreateChapter} className="flex gap-2">
                        <input
                            type="text"
                            placeholder="Add chapter..."
                            value={chapterName}
                            onChange={(e) => setChapterName(e.target.value)}
                            className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
                            disabled={!selectedSubjectId}
                        />
                        <button
                            type="submit"
                            disabled={!selectedSubjectId}
                            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium disabled:opacity-40"
                        >
                            Add
                        </button>
                    </form>
                    <div className="space-y-1.5 max-h-64 overflow-y-auto">
                        {chapters.map((c) => (
                            <div
                                key={c.id}
                                onClick={() => setSelectedChapterId(c.id)}
                                className={`cursor-pointer px-3 py-2 rounded-lg text-sm flex justify-between items-center ${selectedChapterId === c.id
                                        ? 'bg-blue-50 text-blue-800 font-medium border border-blue-200'
                                        : 'hover:bg-slate-50 border border-transparent'
                                    }`}
                            >
                                <span>{c.name}</span>
                                <span className="text-xs text-slate-400">{c._count?.topics ?? 0} topics</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Topics */}
                <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
                    <h3 className="font-semibold text-slate-900">4. Topics</h3>
                    <form onSubmit={handleCreateTopic} className="flex gap-2">
                        <input
                            type="text"
                            placeholder="Add topic..."
                            value={topicForm.name}
                            onChange={(e) => setTopicForm({ ...topicForm, name: e.target.value })}
                            className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
                            disabled={!selectedChapterId}
                        />
                        <input
                            type="number"
                            placeholder="Min"
                            value={topicForm.estimatedStudyTimeMinutes}
                            onChange={(e) =>
                                setTopicForm({ ...topicForm, estimatedStudyTimeMinutes: e.target.value })
                            }
                            className="w-16 px-2 py-1.5 border border-slate-300 rounded-lg text-sm"
                            disabled={!selectedChapterId}
                        />
                        <button
                            type="submit"
                            disabled={!selectedChapterId}
                            className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium disabled:opacity-40"
                        >
                            Add
                        </button>
                    </form>
                    <div className="space-y-1.5 max-h-64 overflow-y-auto">
                        {topics.map((t) => (
                            <div
                                key={t.id}
                                onClick={() => setSelectedTopicId(t.id)}
                                className={`cursor-pointer px-3 py-2 rounded-lg text-sm flex justify-between items-center ${selectedTopicId === t.id
                                        ? 'bg-blue-50 text-blue-800 font-medium border border-blue-200'
                                        : 'hover:bg-slate-50 border border-transparent'
                                    }`}
                            >
                                <span>{t.name}</span>
                                <span className="text-xs text-slate-400">{t.estimatedStudyTimeMinutes ?? 30}m</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* 5. Study Notes for Selected Topic */}
            {selectedTopicId && (
                <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                    <h2 className="font-semibold text-slate-900">5. Bilingual Study Notes (Selected Topic)</h2>
                    <form onSubmit={handleCreateNote} className="space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <input
                                type="text"
                                placeholder="Note Title"
                                value={noteForm.title}
                                onChange={(e) => setNoteForm({ ...noteForm, title: e.target.value })}
                                className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                required
                            />
                            <input
                                type="text"
                                placeholder="Brief Summary"
                                value={noteForm.summary}
                                onChange={(e) => setNoteForm({ ...noteForm, summary: e.target.value })}
                                className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <textarea
                                rows={4}
                                placeholder="Content in English (Markdown supported)..."
                                value={noteForm.contentEn}
                                onChange={(e) => setNoteForm({ ...noteForm, contentEn: e.target.value })}
                                className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            />
                            <textarea
                                rows={4}
                                placeholder="Content in Hindi (हिन्दी में नोट्स)..."
                                value={noteForm.contentHi}
                                onChange={(e) => setNoteForm({ ...noteForm, contentHi: e.target.value })}
                                className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            />
                        </div>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg"
                        >
                            Save &amp; Publish Note
                        </button>
                    </form>

                    <div className="divide-y divide-slate-100">
                        {notes.map((n) => (
                            <div key={n.id} className="py-3 flex items-start justify-between gap-4">
                                <div>
                                    <p className="font-medium text-slate-900 text-sm">{n.title}</p>
                                    {n.summary && <p className="text-xs text-slate-500 mt-0.5">{n.summary}</p>}
                                </div>
                                <button
                                    type="button"
                                    onClick={() => handleDeleteNote(n.id)}
                                    className="text-red-500 hover:text-red-700 p-1"
                                >
                                    <Trash2 className="w-4 h-4" />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};