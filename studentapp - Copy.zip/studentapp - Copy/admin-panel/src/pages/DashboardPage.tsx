import React, { useEffect, useState } from 'react';
import {
    Users,
    BookOpen,
    Layers,
    FileText,
    HelpCircle,
    ClipboardList,
    Activity,
    RefreshCw,
} from 'lucide-react';
import { api } from '../services/api';

interface DashboardData {
    summaryCounts: {
        totalStudents: number;
        activeStudentsPast30Days: number;
        totalExaminations: number;
        totalSubjects: number;
        totalTopics: number;
        totalQuestions: number;
        totalStudyNotes: number;
        totalQuizzes: number;
        pendingImportJobs: number;
    };
    recentActivity: Array<{
        id: string;
        type: string;
        studentName: string;
        timestamp: string;
    }>;
}

export const DashboardPage: React.FC = () => {
    const [data, setData] = useState<DashboardData | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchDashboard = async () => {
        setLoading(true);
        setError(null);
        try {
            const res = await api.get('/admin/dashboard');
            setData(res.data.data);
        } catch {
            setError('Failed to load dashboard statistics.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchDashboard();
    }, []);

    if (loading) {
        return (
            <div className="flex items-center justify-center py-20 text-slate-500">
                Loading dashboard metrics...
            </div>
        );
    }

    if (error || !data) {
        return (
            <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-center justify-between">
                <span>{error || 'No data available'}</span>
                <button
                    type="button"
                    onClick={fetchDashboard}
                    className="px-3 py-1.5 bg-red-600 text-white text-sm rounded-lg"
                >
                    Retry
                </button>
            </div>
        );
    }

    const c = data.summaryCounts;
    const stats = [
        { label: 'Total Students', value: c.totalStudents, sub: `${c.activeStudentsPast30Days} active (30d)`, icon: <Users className="w-5 h-5 text-blue-600" />, bg: 'bg-blue-50' },
        { label: 'Examinations', value: c.totalExaminations, sub: `${c.totalSubjects} subjects`, icon: <BookOpen className="w-5 h-5 text-indigo-600" />, bg: 'bg-indigo-50' },
        { label: 'Total Topics', value: c.totalTopics, sub: `${c.totalStudyNotes} study notes`, icon: <Layers className="w-5 h-5 text-emerald-600" />, bg: 'bg-emerald-50' },
        { label: 'Question Bank', value: c.totalQuestions, sub: 'Published & draft', icon: <HelpCircle className="w-5 h-5 text-amber-600" />, bg: 'bg-amber-50' },
        { label: 'Quizzes', value: c.totalQuizzes, sub: 'Topic & subject quizzes', icon: <ClipboardList className="w-5 h-5 text-purple-600" />, bg: 'bg-purple-50' },
        { label: 'Pending Imports', value: c.pendingImportJobs, sub: 'CSV/Excel queue', icon: <FileText className="w-5 h-5 text-rose-600" />, bg: 'bg-rose-50' },
    ];

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Dashboard Overview</h1>
                    <p className="text-sm text-slate-500">Live platform metrics from PostgreSQL</p>
                </div>
                <button
                    type="button"
                    onClick={fetchDashboard}
                    className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                >
                    <RefreshCw className="w-4 h-4" />
                    Refresh
                </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {stats.map((s) => (
                    <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-5 flex items-start justify-between">
                        <div>
                            <p className="text-sm font-medium text-slate-500">{s.label}</p>
                            <p className="text-3xl font-bold text-slate-900 mt-1">{s.value}</p>
                            <p className="text-xs text-slate-400 mt-1">{s.sub}</p>
                        </div>
                        <div className={`p-3 rounded-xl ${s.bg}`}>{s.icon}</div>
                    </div>
                ))}
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-200 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-600" />
                    <h2 className="font-semibold text-slate-900">Recent Student Activity</h2>
                </div>
                {data.recentActivity.length === 0 ? (
                    <div className="p-8 text-center text-sm text-slate-500">
                        No student activity recorded yet.
                    </div>
                ) : (
                    <div className="divide-y divide-slate-100">
                        {data.recentActivity.map((act) => (
                            <div key={act.id} className="px-5 py-3.5 flex items-center justify-between text-sm">
                                <div>
                                    <span className="font-medium text-slate-900">{act.studentName}</span>
                                    <span className="mx-2 text-slate-300">•</span>
                                    <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-xs font-medium">
                                        {act.type}
                                    </span>
                                </div>
                                <span className="text-xs text-slate-400">
                                    {new Date(act.timestamp).toLocaleString()}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};