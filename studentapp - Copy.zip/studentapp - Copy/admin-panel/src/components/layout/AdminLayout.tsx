import React, { useState } from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
    LayoutDashboard,
    BookOpen,
    HelpCircle,
    ClipboardList,
    Users,
    Settings,
    LogOut,
    Menu,
    X,
    ShieldCheck,
} from 'lucide-react';
import { useAuthStore, AdminUser } from '../../store/authStore';

interface NavItem {
    label: string;
    path: string;
    icon: React.ReactNode;
    roles: AdminUser['role'][];
}

const NAV_ITEMS: NavItem[] = [
    {
        label: 'Dashboard',
        path: '/dashboard',
        icon: <LayoutDashboard className="w-5 h-5" />,
        roles: ['super_admin', 'content_admin', 'question_manager', 'student_support'],
    },
    {
        label: 'Exams & Syllabus',
        path: '/content',
        icon: <BookOpen className="w-5 h-5" />,
        roles: ['super_admin', 'content_admin', 'question_manager'],
    },
    {
        label: 'Question Bank',
        path: '/questions',
        icon: <HelpCircle className="w-5 h-5" />,
        roles: ['super_admin', 'content_admin', 'question_manager'],
    },
    {
        label: 'Quizzes',
        path: '/quizzes',
        icon: <ClipboardList className="w-5 h-5" />,
        roles: ['super_admin', 'content_admin', 'question_manager'],
    },
    {
        label: 'Students',
        path: '/students',
        icon: <Users className="w-5 h-5" />,
        roles: ['super_admin', 'student_support'],
    },
    {
        label: 'Settings & Logs',
        path: '/settings',
        icon: <Settings className="w-5 h-5" />,
        roles: ['super_admin'],
    },
];

export const AdminLayout: React.FC = () => {
    const { user, logout } = useAuthStore();
    const location = useLocation();
    const navigate = useNavigate();
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const visibleItems = NAV_ITEMS.filter((item) => user && item.roles.includes(user.role));

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    return (
        <div className="min-h-screen flex bg-slate-50">
            {/* Mobile Sidebar Overlay */}
            {sidebarOpen && (
                <div
                    className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden"
                    onClick={() => setSidebarOpen(false)}
                />
            )}

            {/* Sidebar */}
            <aside
                className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-slate-900 text-slate-100 flex flex-col transition-transform duration-200 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
                    }`}
            >
                <div className="h-16 flex items-center justify-between px-5 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                        <ShieldCheck className="w-6 h-6 text-blue-400" />
                        <span className="font-bold text-lg tracking-tight">StudyApp Admin</span>
                    </div>
                    <button
                        type="button"
                        onClick={() => setSidebarOpen(false)}
                        className="lg:hidden text-slate-400 hover:text-white"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
                    {visibleItems.map((item) => {
                        const active = location.pathname.startsWith(item.path);
                        return (
                            <Link
                                key={item.path}
                                to={item.path}
                                onClick={() => setSidebarOpen(false)}
                                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${active
                                        ? 'bg-blue-600 text-white shadow-sm'
                                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                                    }`}
                            >
                                {item.icon}
                                <span>{item.label}</span>
                            </Link>
                        );
                    })}
                </nav>

                <div className="p-4 border-t border-slate-800">
                    <div className="mb-3 px-2">
                        <p className="text-sm font-semibold text-white truncate">
                            {user?.displayName || user?.firstName || 'Admin'}
                        </p>
                        <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                        <span className="inline-block mt-1 px-2 py-0.5 text-[11px] font-medium uppercase tracking-wider bg-slate-800 text-blue-300 rounded">
                            {user?.role.replace('_', ' ')}
                        </span>
                    </div>
                    <button
                        type="button"
                        onClick={handleLogout}
                        className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-red-300 bg-slate-800 hover:bg-red-600 hover:text-white rounded-lg transition-colors"
                    >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out</span>
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <div className="flex-1 flex flex-col min-w-0">
                <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-20">
                    <button
                        type="button"
                        onClick={() => setSidebarOpen(true)}
                        className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
                    >
                        <Menu className="w-5 h-5" />
                    </button>
                    <div className="text-sm text-slate-500 hidden sm:block">
                        Multi-Exam Study, Practice &amp; Productivity Platform
                    </div>
                    <div className="text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
                        API Connected
                    </div>
                </header>

                <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto">
                    <Outlet />
                </main>
            </div>
        </div>
    );
};