import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api/v1';

export const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

interface RetryableRequestConfig extends InternalAxiosRequestConfig {
    _retry?: boolean;
}

api.interceptors.request.use((config) => {
    const token = localStorage.getItem('admin_access_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

api.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
        const originalRequest = error.config as RetryableRequestConfig | undefined;

        if (
            error.response?.status === 401 &&
            originalRequest &&
            !originalRequest._retry &&
            !originalRequest.url?.includes('/auth/login') &&
            !originalRequest.url?.includes('/auth/refresh-token')
        ) {
            originalRequest._retry = true;
            const refreshToken = localStorage.getItem('admin_refresh_token');

            if (refreshToken) {
                try {
                    const res = await axios.post(`${API_URL}/auth/refresh-token`, { refreshToken });
                    const { accessToken, refreshToken: newRefreshToken } = res.data.data;

                    localStorage.setItem('admin_access_token', accessToken);
                    localStorage.setItem('admin_refresh_token', newRefreshToken);

                    originalRequest.headers.Authorization = `Bearer ${accessToken}`;
                    return api(originalRequest);
                } catch {
                    localStorage.removeItem('admin_access_token');
                    localStorage.removeItem('admin_refresh_token');
                    localStorage.removeItem('admin_user');
                    window.location.href = '/login';
                }
            }
        }

        return Promise.reject(error);
    }
);